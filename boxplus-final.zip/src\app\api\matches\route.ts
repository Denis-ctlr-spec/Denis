import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const competition = searchParams.get('competition');
    const status = searchParams.get('status');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');

    let sql = `
      SELECT m.id, 
             m.scheduled_at as match_date, 
             m.status, 
             m.home_score, 
             m.away_score, 
             COALESCE(m.hls_url, '') as stream_url,
             m.replay_url,
             NOT m.is_free as is_premium,
             ht.id as home_team_id, ht.name as home_team_name, ht.logo_url as home_team_logo,
             at.id as away_team_id, at.name as away_team_name, at.logo_url as away_team_logo,
             c.id as competition_id, c.name as competition_name, c.logo_url as competition_logo
      FROM matches m
      JOIN teams ht ON ht.id = m.home_team_id
      JOIN teams at ON at.id = m.away_team_id
      JOIN competitions c ON c.id = m.competition_id
      WHERE 1=1
    `;
    const params: any[] = [];
    let paramIdx = 1;

    if (competition) {
      sql += ` AND m.competition_id = $${paramIdx++}`;
      params.push(competition);
    }
    if (status) {
      sql += ` AND m.status = $${paramIdx++}`;
      params.push(status);
    }

    sql += ` ORDER BY m.scheduled_at DESC LIMIT $${paramIdx++} OFFSET $${paramIdx++}`;
    params.push(limit, offset);

    const result = await query(sql, params);

    const matches = result.rows.map(row => ({
      id: row.id,
      matchDate: row.match_date,
      status: row.status,
      homeScore: row.home_score,
      awayScore: row.away_score,
      streamUrl: row.stream_url,
      replayUrl: row.replay_url,
      isPremium: row.is_premium,
      homeTeam: { id: row.home_team_id, name: row.home_team_name, logoUrl: row.home_team_logo },
      awayTeam: { id: row.away_team_id, name: row.away_team_name, logoUrl: row.away_team_logo },
      competition: { id: row.competition_id, name: row.competition_name, logoUrl: row.competition_logo },
    }));

    return NextResponse.json({ matches, total: result.rows.length });
  } catch (error) {
    console.error('Get matches error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
