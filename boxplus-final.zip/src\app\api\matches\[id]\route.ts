import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const result = await query(`
      SELECT m.id, 
             m.scheduled_at as match_date,
             m.status,
             m.home_score,
             m.away_score,
             m.minute,
             COALESCE(m.hls_url, '') as stream_url,
             m.replay_url,
             m.thumbnail_url,
             NOT m.is_free as is_premium,
             m.is_free,
             m.matchday as round,
             ht.id as home_team_id, ht.name as home_team_name, ht.logo_url as home_team_logo,
             at.id as away_team_id, at.name as away_team_name, at.logo_url as away_team_logo,
             c.id as competition_id, c.name as competition_name, c.logo_url as competition_logo
      FROM matches m
      JOIN teams ht ON ht.id = m.home_team_id
      JOIN teams at ON at.id = m.away_team_id
      JOIN competitions c ON c.id = m.competition_id
      WHERE m.id = $1
    `, [params.id]);

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Match non trouvé' }, { status: 404 });
    }

    const row = result.rows[0];

    let events: any[] = [];
    try {
      const eventsResult = await query(
        `SELECT me.*, t.name as team_name 
         FROM match_events me
         LEFT JOIN teams t ON t.id = me.team_id
         WHERE me.match_id = $1 ORDER BY me.minute ASC`,
        [params.id]
      );
      events = eventsResult.rows;
    } catch (e) {
      events = [];
    }

    const match = {
      id: row.id,
      matchDate: row.match_date,
      status: row.status,
      homeScore: row.home_score,
      awayScore: row.away_score,
      minute: row.minute,
      streamUrl: row.stream_url,
      replayUrl: row.replay_url,
      thumbnailUrl: row.thumbnail_url,
      isPremium: row.is_premium,
      round: row.round,
      homeTeam: { id: row.home_team_id, name: row.home_team_name, logoUrl: row.home_team_logo },
      awayTeam: { id: row.away_team_id, name: row.away_team_name, logoUrl: row.away_team_logo },
      competition: { id: row.competition_id, name: row.competition_name, logoUrl: row.competition_logo },
      events,
    };

    return NextResponse.json({ match });
  } catch (error) {
    console.error('Get match error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
