import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAdmin } from '@/lib/server/auth-helpers';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await requireAdmin(req);
    let streamUrl = null;
    try {
      const body = await req.json();
      streamUrl = body.streamUrl || body.hlsUrl || null;
    } catch {
      // Body might be empty
    }

    if (streamUrl) {
      await query(
        "UPDATE matches SET status = 'live', hls_url = $1, started_at = NOW(), updated_at = NOW() WHERE id = $2",
        [streamUrl, params.id]
      );
    } else {
      await query(
        "UPDATE matches SET status = 'live', started_at = NOW(), updated_at = NOW() WHERE id = $1",
        [params.id]
      );
    }

    return NextResponse.json({ success: true, message: 'Direct démarré avec succès' });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
