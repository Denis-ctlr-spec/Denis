import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAdmin } from '@/lib/server/auth-helpers';

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);
    const { searchParams } = new URL(req.url);
    const search = searchParams.get('search')?.toLowerCase().trim();

    let sql = `
      SELECT u.id, u.email, u.full_name, u.phone, u.role, u.is_active, u.created_at, u.last_login_at as last_login,
             s.status as subscription_status, s.expires_at as subscription_expires,
             sp.name as plan_name
      FROM users u
      LEFT JOIN subscriptions s ON s.user_id = u.id AND s.status = 'active' AND s.expires_at > NOW()
      LEFT JOIN subscription_plans sp ON sp.id = s.plan_id
      WHERE 1=1
    `;
    const params: any[] = [];
    if (search) {
      sql += ' AND (LOWER(u.email) LIKE $1 OR LOWER(u.full_name) LIKE $1)';
      params.push(`%${search}%`);
    }

    sql += ' ORDER BY u.created_at DESC LIMIT 100';

    const result = await query(sql, params);
    return NextResponse.json({ users: result.rows });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    console.error('Admin get users error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
