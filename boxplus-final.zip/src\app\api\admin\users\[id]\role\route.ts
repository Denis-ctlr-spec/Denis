import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAdmin } from '@/lib/server/auth-helpers';

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await requireAdmin(req);
    const { role } = await req.json();

    if (!role || !['admin', 'moderator', 'viewer'].includes(role)) {
      return NextResponse.json({ error: 'Rôle invalide' }, { status: 400 });
    }

    await query('UPDATE users SET role = $1 WHERE id = $2', [role, params.id]);
    return NextResponse.json({ success: true });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
