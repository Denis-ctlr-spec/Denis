import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const result = await query(`
      SELECT s.*, t.name as team_name, t.logo_url as team_logo, t.short_name
      FROM standings s
      JOIN teams t ON t.id = s.team_id
      WHERE s.competition_id = $1
      ORDER BY s.points DESC, s.goal_difference DESC, s.goals_for DESC
    `, [params.id]);

    return NextResponse.json({ standings: result.rows });
  } catch (error) {
    console.error('Get standings error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
