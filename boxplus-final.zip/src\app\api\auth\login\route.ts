import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { comparePassword } from '@/lib/server/password';
import { signAccessToken, signRefreshToken } from '@/lib/server/auth-helpers';

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json();

    if (!email || !password) {
      return NextResponse.json({ error: 'Email et mot de passe requis' }, { status: 400 });
    }

    const result = await query(
      'SELECT id, email, full_name, phone, role, password_hash, is_active FROM users WHERE email = $1',
      [email.toLowerCase().trim()]
    );

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Email ou mot de passe incorrect' }, { status: 401 });
    }

    const user = result.rows[0];

    if (user.is_active === false) {
      return NextResponse.json({ error: 'Compte désactivé. Contactez le support.' }, { status: 403 });
    }

    const validPassword = await comparePassword(password, user.password_hash);
    if (!validPassword) {
      return NextResponse.json({ error: 'Email ou mot de passe incorrect' }, { status: 401 });
    }

    try {
      await query('UPDATE users SET last_login_at = NOW() WHERE id = $1', [user.id]);
    } catch (e) {
      // Ignore if last_login_at is missing
    }

    const payload = { userId: user.id, email: user.email, role: user.role };
    const accessToken = signAccessToken(payload);
    const refreshToken = signRefreshToken(payload);

    try {
      await query(
        `INSERT INTO refresh_tokens (user_id, token_hash, expires_at) 
         VALUES ($1, $2, NOW() + INTERVAL '7 days')`,
        [user.id, refreshToken]
      );
    } catch (e) {
      console.warn('Could not store refresh token:', e);
    }

    const response = NextResponse.json({
      success: true,
      user: { id: user.id, email: user.email, fullName: user.full_name, phone: user.phone, role: user.role },
      accessToken,
    });

    response.cookies.set('access_token', accessToken, {
      httpOnly: false,
      secure: true,
      sameSite: 'lax',
      maxAge: 60 * 15,
      path: '/',
    });
    response.cookies.set('refresh_token', refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7,
      path: '/',
    });

    return response;
  } catch (error: any) {
    console.error('Login error:', error);
    return NextResponse.json({ error: error.message || 'Erreur serveur lors de la connexion' }, { status: 500 });
  }
}
