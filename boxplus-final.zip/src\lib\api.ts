import axios from 'axios';
import Cookies from 'js-cookie';

const API_URL = '/api';

export const api = axios.create({
  baseURL: API_URL,
  withCredentials: true,
  headers: { 'Content-Type': 'application/json' },
});

// Intercepteur : ajouter le Bearer token
api.interceptors.request.use((config) => {
  const token = Cookies.get('access_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Intercepteur : refresh automatique si 401
let isRefreshing = false;
let failedQueue: Array<{ resolve: (v: any) => void; reject: (e: any) => void }> = [];

function processQueue(error: any, token: string | null) {
  failedQueue.forEach(({ resolve, reject }) => (error ? reject(error) : resolve(token)));
  failedQueue = [];
}

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    if (error.response?.status !== 401 || originalRequest._retry) {
      return Promise.reject(error);
    }

    if (isRefreshing) {
      return new Promise((resolve, reject) => {
        failedQueue.push({ resolve, reject });
      }).then((token) => {
        originalRequest.headers.Authorization = `Bearer ${token}`;
        return api(originalRequest);
      });
    }

    originalRequest._retry = true;
    isRefreshing = true;

    try {
      const { data } = await axios.post(`${API_URL}/auth/refresh`, {}, { withCredentials: true });
      const { accessToken } = data;
      Cookies.set('access_token', accessToken, { expires: 1 / 96, secure: true, sameSite: 'Lax' });
      processQueue(null, accessToken);
      originalRequest.headers.Authorization = `Bearer ${accessToken}`;
      return api(originalRequest);
    } catch (err) {
      processQueue(err, null);
      Cookies.remove('access_token');
      if (typeof window !== 'undefined') window.location.href = '/login';
      return Promise.reject(err);
    } finally {
      isRefreshing = false;
    }
  }
);

// Auth API calls
export const authApi = {
  register: (data: { email: string; phone?: string; password: string; fullName: string }) =>
    api.post('/auth/register', data),
  login: (data: { email: string; password: string }) =>
    api.post('/auth/login', data),
  logout: () => api.post('/auth/logout'),
  refresh: () => api.post('/auth/refresh'),
  forgotPassword: (email: string) =>
    api.post('/auth/forgot-password', { email }),
  resetPassword: (token: string, password: string) =>
    api.post('/auth/reset-password', { token, password }),
  verifyEmail: (token: string) =>
    api.get(`/auth/verify-email?token=${token}`),
  me: () => api.get('/auth/me'),
};

// Matches API calls
export const matchesApi = {
  getAll: (params?: any) => api.get('/matches', { params }),
  getById: (id: string) => api.get(`/matches/${id}`),
  getUpcoming: () => api.get('/matches/upcoming'),
  getReplays: () => api.get('/matches/replays'),
};

// Competitions API calls
export const competitionsApi = {
  getAll: () => api.get('/competitions'),
  getById: (id: string) => api.get(`/competitions/${id}`),
  getStandings: (id: string) => api.get(`/competitions/${id}/standings`),
};

// Teams API calls
export const teamsApi = {
  getAll: () => api.get('/teams'),
  getById: (id: string) => api.get(`/teams/${id}`),
};

// Admin API calls
export const adminApi = {
  getDashboard: () => api.get('/admin/dashboard'),
  getUsers: () => api.get('/admin/users'),
  getMatches: () => api.get('/admin/matches'),
  createMatch: (data: any) => api.post('/admin/matches', data),
  updateScore: (id: string, data: any) => api.patch(`/admin/matches/${id}/score`, data),
  addEvent: (id: string, data: any) => api.post(`/admin/matches/${id}/events`, data),
  startLive: (id: string) => api.post(`/admin/matches/${id}/start-live`),
  stopLive: (id: string) => api.post(`/admin/matches/${id}/stop-live`),
  getTeams: () => api.get('/admin/teams'),
  createTeam: (data: any) => api.post('/admin/teams', data),
  getCompetitions: () => api.get('/admin/competitions'),
  createCompetition: (data: any) => api.post('/admin/competitions', data),
  getPlans: () => api.get('/admin/plans'),
  getSeasons: () => api.get('/admin/seasons'),
  createSeason: (data: any) => api.post('/admin/seasons', data),
};

// Payments API calls
export const paymentsApi = {
  checkout: (data: any) => api.post('/payments/checkout', data),
  getStatus: (id: string) => api.get(`/payments/${id}/status`),
  getHistory: () => api.get('/payments/history'),
  simulateSandbox: (id: string) => api.post(`/payments/${id}/simulate-sandbox`),
};

// Stream API calls
export const streamApi = {
  getAccess: (matchId: string) => api.post('/stream/access', { matchId }),
};
