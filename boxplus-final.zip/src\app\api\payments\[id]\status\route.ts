import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAuth } from '@/lib/server/auth-helpers';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await requireAuth(req);

    const result = await query(`
      SELECT p.*, sp.name as plan_name, sp.duration_days
      FROM payments p
      LEFT JOIN subscription_plans sp ON sp.id = p.plan_id
      WHERE p.id = $1 AND p.user_id = $2
    `, [params.id, user.userId]);

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Paiement non trouvé' }, { status: 404 });
    }

    return NextResponse.json({ payment: result.rows[0] });
  } catch (error: any) {
    if (error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 401 });
    }
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
