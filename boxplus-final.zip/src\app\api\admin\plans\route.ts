import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';

export async function GET(req: NextRequest) {
  try {
    const result = await query(`
      SELECT id, name, slug, description, price, currency, duration_days, features, is_active
      FROM subscription_plans
      WHERE is_active = true
      ORDER BY sort_order ASC, price ASC
    `);
    return NextResponse.json({ plans: result.rows });
  } catch (error) {
    console.error('Get plans error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
