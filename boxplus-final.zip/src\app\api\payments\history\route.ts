import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAuth } from '@/lib/server/auth-helpers';

export async function GET(req: NextRequest) {
  try {
    const user = await requireAuth(req);

    const result = await query(`
      SELECT p.id, p.amount, p.currency, p.status, p.payment_method, p.created_at, p.paid_at as completed_at,
             sp.name as plan_name
      FROM payments p
      LEFT JOIN subscription_plans sp ON sp.id = p.plan_id
      WHERE p.user_id = $1
      ORDER BY p.created_at DESC
      LIMIT 20
    `, [user.userId]);

    return NextResponse.json({ payments: result.rows });
  } catch (error: any) {
    if (error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 401 });
    }
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
