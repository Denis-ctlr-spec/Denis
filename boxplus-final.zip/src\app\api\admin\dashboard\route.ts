import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAdmin } from '@/lib/server/auth-helpers';

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);

    const [usersRes, matchesRes, activeSubsRes, revenueRes, liveMatchRes] = await Promise.all([
      query('SELECT COUNT(*) as count FROM users'),
      query('SELECT COUNT(*) as count FROM matches'),
      query("SELECT COUNT(*) as count FROM subscriptions WHERE status = 'active' AND expires_at > NOW()"),
      query("SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE status = 'approved'"),
      query("SELECT COUNT(*) as count FROM matches WHERE status = 'live'"),
    ]);

    return NextResponse.json({
      stats: {
        totalUsers: parseInt(usersRes.rows[0].count),
        totalMatches: parseInt(matchesRes.rows[0].count),
        activeSubscriptions: parseInt(activeSubsRes.rows[0].count),
        totalRevenue: parseFloat(revenueRes.rows[0].total),
        liveMatches: parseInt(liveMatchRes.rows[0].count),
      }
    });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    console.error('Admin dashboard error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
