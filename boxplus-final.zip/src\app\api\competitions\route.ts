import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';

export async function GET(req: NextRequest) {
  try {
    const result = await query(`
      SELECT c.id, c.name, c.slug, c.description, c.logo_url, c.country, c.format,
             c.is_active, c.created_at,
             COUNT(m.id) as match_count
      FROM competitions c
      LEFT JOIN matches m ON m.competition_id = c.id
      WHERE c.is_active = true
      GROUP BY c.id
      ORDER BY c.sort_order ASC, c.created_at DESC
    `);

    return NextResponse.json({ competitions: result.rows });
  } catch (error) {
    console.error('Get competitions error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
