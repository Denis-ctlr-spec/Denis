import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { verifyRefreshToken, signAccessToken, signRefreshToken, getRefreshTokenFromRequest } from '@/lib/server/auth-helpers';

export async function POST(req: NextRequest) {
  try {
    const refreshToken = getRefreshTokenFromRequest(req);
    if (!refreshToken) {
      return NextResponse.json({ error: 'Refresh token manquant' }, { status: 401 });
    }

    let payload;
    try {
      payload = verifyRefreshToken(refreshToken);
    } catch {
      return NextResponse.json({ error: 'Token expiré ou invalide' }, { status: 401 });
    }

    try {
      const tokenResult = await query(
        'SELECT id FROM refresh_tokens WHERE token_hash = $1 AND expires_at > NOW()',
        [refreshToken]
      );
      if (tokenResult.rows.length === 0) {
        return NextResponse.json({ error: 'Session expirée' }, { status: 401 });
      }
      await query('DELETE FROM refresh_tokens WHERE token_hash = $1', [refreshToken]);
    } catch (e) {
      // If table query fails, continue using valid JWT payload
    }

    const newPayload = { userId: payload.userId, email: payload.email, role: payload.role };
    const newAccessToken = signAccessToken(newPayload);
    const newRefreshToken = signRefreshToken(newPayload);

    try {
      await query(
        "INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES ($1, $2, NOW() + INTERVAL '7 days')",
        [payload.userId, newRefreshToken]
      );
    } catch (e) {
      // Ignore
    }

    const response = NextResponse.json({ success: true, accessToken: newAccessToken });
    response.cookies.set('access_token', newAccessToken, {
      httpOnly: false, secure: true, sameSite: 'lax', maxAge: 60 * 15, path: '/',
    });
    response.cookies.set('refresh_token', newRefreshToken, {
      httpOnly: true, secure: true, sameSite: 'lax', maxAge: 60 * 60 * 24 * 7, path: '/',
    });

    return response;
  } catch (error) {
    console.error('Refresh error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
