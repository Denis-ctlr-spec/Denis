import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const teamResult = await query('SELECT * FROM teams WHERE id = $1', [params.id]);
    if (teamResult.rows.length === 0) {
      return NextResponse.json({ error: 'Équipe non trouvée' }, { status: 404 });
    }

    const team = teamResult.rows[0];

    let recentMatches: any[] = [];
    try {
      const matchesResult = await query(`
        SELECT m.id, m.scheduled_at as match_date, m.status, m.home_score, m.away_score,
               ht.name as home_team_name, at.name as away_team_name,
               c.name as competition_name
        FROM matches m
        JOIN teams ht ON ht.id = m.home_team_id
        JOIN teams at ON at.id = m.away_team_id
        JOIN competitions c ON c.id = m.competition_id
        WHERE m.home_team_id = $1 OR m.away_team_id = $1
        ORDER BY m.scheduled_at DESC
        LIMIT 5
      `, [params.id]);
      recentMatches = matchesResult.rows;
    } catch (e) {
      recentMatches = [];
    }

    return NextResponse.json({
      team: {
        id: team.id,
        name: team.name,
        shortName: team.short_name,
        logoUrl: team.logo_url,
        city: team.city,
        stadium: team.stadium,
        foundedYear: team.founded_year,
        description: team.description,
      },
      recentMatches,
    });
  } catch (error) {
    console.error('Get team error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
