import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAdmin } from '@/lib/server/auth-helpers';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await requireAdmin(req);
    const { type, minute, teamId, playerId, description } = await req.json();

    if (!type || minute === undefined) {
      return NextResponse.json({ error: 'Type et minute sont requis' }, { status: 400 });
    }

    // Créer la table match_events si elle n'existe pas encore
    await query(`
      CREATE TABLE IF NOT EXISTS match_events (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        match_id UUID NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
        team_id UUID REFERENCES teams(id) ON DELETE SET NULL,
        player_id UUID,
        type VARCHAR(50) NOT NULL,
        minute INT NOT NULL,
        description TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    const result = await query(`
      INSERT INTO match_events (match_id, team_id, player_id, type, minute, description)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id
    `, [params.id, teamId || null, playerId || null, type, minute, description || null]);

    return NextResponse.json({ success: true, eventId: result.rows[0].id });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    console.error('Match event error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
