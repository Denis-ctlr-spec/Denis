import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';

export async function GET(req: NextRequest) {
  try {
    const result = await query(`
      SELECT m.id, 
             m.scheduled_at as match_date, 
             m.status, 
             NOT m.is_free as is_premium,
             ht.id as home_team_id, ht.name as home_team_name, ht.logo_url as home_team_logo,
             at.id as away_team_id, at.name as away_team_name, at.logo_url as away_team_logo,
             c.id as competition_id, c.name as competition_name
      FROM matches m
      JOIN teams ht ON ht.id = m.home_team_id
      JOIN teams at ON at.id = m.away_team_id
      JOIN competitions c ON c.id = m.competition_id
      WHERE m.scheduled_at > NOW() AND m.status = 'scheduled'
      ORDER BY m.scheduled_at ASC
      LIMIT 10
    `);

    const matches = result.rows.map(row => ({
      id: row.id,
      matchDate: row.match_date,
      status: row.status,
      isPremium: row.is_premium,
      homeTeam: { id: row.home_team_id, name: row.home_team_name, logoUrl: row.home_team_logo },
      awayTeam: { id: row.away_team_id, name: row.away_team_name, logoUrl: row.away_team_logo },
      competition: { id: row.competition_id, name: row.competition_name },
    }));

    return NextResponse.json({ matches });
  } catch (error) {
    console.error('Get upcoming matches error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
