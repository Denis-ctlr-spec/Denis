import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { hashPassword } from '@/lib/server/password';

export async function POST(req: NextRequest) {
  try {
    const { token, password } = await req.json();
    if (!token || !password) {
      return NextResponse.json({ error: 'Token et mot de passe requis' }, { status: 400 });
    }
    if (password.length < 8) {
      return NextResponse.json({ error: 'Le mot de passe doit contenir au moins 8 caractères' }, { status: 400 });
    }

    const result = await query(
      'SELECT user_id FROM password_reset_tokens WHERE token = $1 AND expires_at > NOW()',
      [token]
    );

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Token invalide ou expiré' }, { status: 400 });
    }

    const { user_id } = result.rows[0];
    const passwordHash = await hashPassword(password);

    await query('UPDATE users SET password_hash = $1 WHERE id = $2', [passwordHash, user_id]);
    await query('DELETE FROM password_reset_tokens WHERE user_id = $1', [user_id]);
    await query('DELETE FROM refresh_tokens WHERE user_id = $1', [user_id]);

    return NextResponse.json({ success: true, message: 'Mot de passe réinitialisé avec succès' });
  } catch (error) {
    console.error('Reset password error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
