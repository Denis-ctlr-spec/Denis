import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAuth } from '@/lib/server/auth-helpers';

export async function GET(req: NextRequest) {
  try {
    const payload = await requireAuth(req);

    const result = await query(
      `SELECT u.id, u.email, u.full_name, u.phone, u.role, u.avatar_url, u.created_at,
              s.status as subscription_status, s.expires_at as subscription_expires,
              sp.name as plan_name
       FROM users u
       LEFT JOIN subscriptions s ON s.user_id = u.id AND s.status = 'active' AND s.expires_at > NOW()
       LEFT JOIN subscription_plans sp ON sp.id = s.plan_id
       WHERE u.id = $1`,
      [payload.userId]
    );

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Utilisateur non trouvé' }, { status: 404 });
    }

    const user = result.rows[0];
    return NextResponse.json({
      id: user.id,
      email: user.email,
      fullName: user.full_name,
      phone: user.phone,
      role: user.role,
      avatarUrl: user.avatar_url,
      subscription: user.subscription_status ? {
        status: user.subscription_status,
        expiresAt: user.subscription_expires,
        planName: user.plan_name,
      } : null,
    });
  } catch (error: any) {
    if (error.message === 'Non authentifié' || error.message === 'Token invalide ou expiré') {
      return NextResponse.json({ error: error.message }, { status: 401 });
    }
    console.error('Me error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
