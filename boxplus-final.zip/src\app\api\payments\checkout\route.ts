import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAuth } from '@/lib/server/auth-helpers';

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth(req);
    const { planId, phoneNumber, paymentMethod } = await req.json();

    if (!planId || !phoneNumber || !paymentMethod) {
      return NextResponse.json({ error: 'Plan, numéro de téléphone et méthode de paiement requis' }, { status: 400 });
    }

    const planResult = await query(
      'SELECT * FROM subscription_plans WHERE id = $1 AND is_active = true',
      [planId]
    );
    if (planResult.rows.length === 0) {
      return NextResponse.json({ error: 'Plan non trouvé' }, { status: 404 });
    }

    const plan = planResult.rows[0];
    const amount = plan.price;

    // Normaliser la méthode de paiement ('tmoney', 'flooz')
    const methodClean = paymentMethod.toLowerCase().includes('tmoney') ? 'tmoney' : 'flooz';

    // Créer la transaction en base
    const paymentResult = await query(`
      INSERT INTO payments (user_id, plan_id, amount, currency, payment_method, status, phone_number, created_at)
      VALUES ($1, $2, $3, 'XOF', $4, 'pending', $5, NOW())
      RETURNING id
    `, [user.userId, planId, amount, methodClean, phoneNumber]);

    const paymentId = paymentResult.rows[0].id;

    // FedaPay API
    const fedapayKey = process.env.FEDAPAY_SECRET_KEY;
    const fedapayEnv = process.env.FEDAPAY_ENV || 'sandbox';
    const fedapayBaseUrl = fedapayEnv === 'live' 
      ? 'https://api.fedapay.com/v1' 
      : 'https://sandbox-api.fedapay.com/v1';

    let fedapayResponse = null;
    let externalId = null;

    if (fedapayKey && !fedapayKey.includes('your_') && !fedapayKey.includes('dummy')) {
      try {
        const response = await fetch(`${fedapayBaseUrl}/transactions`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${fedapayKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            description: `BOX+ - Abonnement ${plan.name}`,
            amount: amount,
            currency: { iso: 'XOF' },
            callback_url: `${process.env.NEXT_PUBLIC_SITE_URL || 'https://bplus-bay.vercel.app'}/api/payments/webhook`,
            customer: {
              email: user.email,
              phone_number: {
                number: phoneNumber,
                country: 'TG',
              }
            }
          }),
        });

        if (response.ok) {
          fedapayResponse = await response.json();
          externalId = fedapayResponse?.v1?.transaction?.id?.toString();

          if (externalId) {
            await query('UPDATE payments SET fedapay_transaction_id = $1 WHERE id = $2', [externalId, paymentId]);
          }
        }
      } catch (fedapayError) {
        console.error('FedaPay API error:', fedapayError);
      }
    }

    return NextResponse.json({
      success: true,
      paymentId,
      externalId,
      amount,
      currency: 'XOF',
      status: 'pending',
      message: fedapayEnv === 'sandbox' 
        ? 'Paiement initié (mode sandbox). Cliquez sur "Simuler le paiement" pour activer l\'abonnement immédiatement.'
        : 'Paiement initié. Veuillez confirmer l\'opération sur votre téléphone.',
    });
  } catch (error: any) {
    if (error.message?.includes('authentifié') || error.message?.includes('Token')) {
      return NextResponse.json({ error: error.message }, { status: 401 });
    }
    console.error('Checkout error:', error);
    return NextResponse.json({ error: error.message || 'Erreur lors de l\'initiation du paiement' }, { status: 500 });
  }
}
