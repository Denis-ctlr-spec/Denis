import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAdmin } from '@/lib/server/auth-helpers';

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await requireAdmin(req);
    const { homeScore, awayScore, minute } = await req.json();

    if (minute !== undefined) {
      await query(
        'UPDATE matches SET home_score = $1, away_score = $2, minute = $3, updated_at = NOW() WHERE id = $4',
        [homeScore ?? 0, awayScore ?? 0, minute, params.id]
      );
    } else {
      await query(
        'UPDATE matches SET home_score = $1, away_score = $2, updated_at = NOW() WHERE id = $3',
        [homeScore ?? 0, awayScore ?? 0, params.id]
      );
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
