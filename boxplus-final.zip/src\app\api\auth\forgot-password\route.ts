import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import crypto from 'crypto';

export async function POST(req: NextRequest) {
  try {
    const { email } = await req.json();
    if (!email) {
      return NextResponse.json({ error: 'Email requis' }, { status: 400 });
    }

    const result = await query('SELECT id, email, full_name FROM users WHERE email = $1', [email.toLowerCase()]);

    // Toujours retourner succès pour ne pas révéler si l'email existe
    if (result.rows.length === 0) {
      return NextResponse.json({ success: true, message: 'Si cet email existe, vous recevrez un lien de réinitialisation.' });
    }

    const user = result.rows[0];
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 heure

    await query(
      `INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES ($1, $2, $3)
       ON CONFLICT (user_id) DO UPDATE SET token = $2, expires_at = $3`,
      [user.id, token, expiresAt]
    );

    // En production, envoyer un vrai email. Pour l'instant, logger le lien.
    const resetUrl = `${process.env.NEXT_PUBLIC_SITE_URL || 'https://bplus-bay.vercel.app'}/reset-password?token=${token}`;
    console.log(`Reset URL for ${user.email}: ${resetUrl}`);

    return NextResponse.json({ success: true, message: 'Si cet email existe, vous recevrez un lien de réinitialisation.' });
  } catch (error) {
    console.error('Forgot password error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
