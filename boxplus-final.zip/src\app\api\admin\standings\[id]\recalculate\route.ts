import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAdmin } from '@/lib/server/auth-helpers';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await requireAdmin(req);
    const competitionId = params.id;

    // Récupérer tous les matchs terminés de la compétition
    const matchesRes = await query(
      "SELECT home_team_id, away_team_id, home_score, away_score FROM matches WHERE competition_id = $1 AND status = 'finished'",
      [competitionId]
    );

    // Calculer les points et stats par équipe
    const stats: Record<string, { played: number; won: number; drawn: number; lost: number; gf: number; ga: number; points: number }> = {};

    for (const m of matchesRes.rows) {
      if (!stats[m.home_team_id]) {
        stats[m.home_team_id] = { played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, points: 0 };
      }
      if (!stats[m.away_team_id]) {
        stats[m.away_team_id] = { played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, points: 0 };
      }

      const h = stats[m.home_team_id];
      const a = stats[m.away_team_id];

      h.played++;
      a.played++;
      h.gf += m.home_score;
      h.ga += m.away_score;
      a.gf += m.away_score;
      a.ga += m.home_score;

      if (m.home_score > m.away_score) {
        h.won++;
        h.points += 3;
        a.lost++;
      } else if (m.home_score < m.away_score) {
        a.won++;
        a.points += 3;
        h.lost++;
      } else {
        h.drawn++;
        a.drawn++;
        h.points += 1;
        a.points += 1;
      }
    }

    // Mettre à jour la table standings
    for (const [teamId, s] of Object.entries(stats)) {
      await query(`
        INSERT INTO standings (competition_id, team_id, played, won, drawn, lost, goals_for, goals_against, points, updated_at)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())
        ON CONFLICT (competition_id, team_id) DO UPDATE SET
          played = $3, won = $4, drawn = $5, lost = $6, goals_for = $7, goals_against = $8, points = $9, updated_at = NOW()
      `, [competitionId, teamId, s.played, s.won, s.drawn, s.lost, s.gf, s.ga, s.points]);
    }

    return NextResponse.json({ success: true, message: 'Classement recalculé avec succès' });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    console.error('Recalculate error:', error);
    return NextResponse.json({ error: 'Erreur lors du recalcul' }, { status: 500 });
  }
}
