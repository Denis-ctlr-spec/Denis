import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAdmin } from '@/lib/server/auth-helpers';

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);

    const result = await query(`
      SELECT m.id, 
             m.scheduled_at as match_date, 
             m.status, 
             m.home_score, 
             m.away_score, 
             NOT m.is_free as is_premium,
             COALESCE(m.hls_url, '') as stream_url, 
             m.matchday as round,
             ht.name as home_team_name, at.name as away_team_name,
             c.name as competition_name
      FROM matches m
      JOIN teams ht ON ht.id = m.home_team_id
      JOIN teams at ON at.id = m.away_team_id
      JOIN competitions c ON c.id = m.competition_id
      ORDER BY m.scheduled_at DESC
      LIMIT 50
    `);

    return NextResponse.json({ matches: result.rows });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    console.error('Admin get matches error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireAdmin(req);
    const body = await req.json();

    const homeTeamId = body.homeTeamId;
    const awayTeamId = body.awayTeamId;
    const competitionId = body.competitionId;
    const scheduledAt = body.scheduledAt || body.matchDate;
    const isFree = body.isFree !== undefined ? Boolean(body.isFree) : (body.isPremium !== undefined ? !body.isPremium : true);
    const hlsUrl = body.hlsUrl || body.streamUrl || null;
    const matchday = body.matchday ? parseInt(body.matchday) : (body.round ? parseInt(body.round) : 1);
    const isFeatured = Boolean(body.isFeatured);
    
    // Obtenir une saison par défaut si non fournie
    let seasonId = body.seasonId;
    if (!seasonId) {
      const seasonRes = await query('SELECT id FROM seasons WHERE is_current = true LIMIT 1');
      if (seasonRes.rows.length > 0) {
        seasonId = seasonRes.rows[0].id;
      }
    }

    if (!homeTeamId || !awayTeamId || !competitionId || !scheduledAt) {
      return NextResponse.json({ error: 'Équipes, compétition et date sont requis' }, { status: 400 });
    }

    if (homeTeamId === awayTeamId) {
      return NextResponse.json({ error: 'Les deux équipes doivent être différentes' }, { status: 400 });
    }

    const result = await query(`
      INSERT INTO matches (home_team_id, away_team_id, competition_id, season_id, scheduled_at, matchday, is_free, is_featured, hls_url, status)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'scheduled')
      RETURNING id
    `, [homeTeamId, awayTeamId, competitionId, seasonId || null, scheduledAt, matchday, isFree, isFeatured, hlsUrl]);

    return NextResponse.json({ success: true, matchId: result.rows[0].id }, { status: 201 });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    console.error('Admin create match error:', error);
    return NextResponse.json({ error: error.message || 'Erreur lors de la création du match' }, { status: 500 });
  }
}
