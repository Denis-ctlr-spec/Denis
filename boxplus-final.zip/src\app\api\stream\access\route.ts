import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAuth } from '@/lib/server/auth-helpers';
import crypto from 'crypto';

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth(req);
    const { matchId } = await req.json();

    if (!matchId) {
      return NextResponse.json({ error: 'matchId requis' }, { status: 400 });
    }

    const matchResult = await query(
      "SELECT id, is_free, hls_url, status FROM matches WHERE id = $1",
      [matchId]
    );

    if (matchResult.rows.length === 0) {
      return NextResponse.json({ error: 'Match non trouvé' }, { status: 404 });
    }

    const match = matchResult.rows[0];

    // Si le match est payant (!is_free), vérifier si l'utilisateur a un abonnement actif
    if (!match.is_free) {
      const subResult = await query(
        "SELECT id FROM subscriptions WHERE user_id = $1 AND status = 'active' AND expires_at > NOW()",
        [user.userId]
      );
      if (subResult.rows.length === 0) {
        return NextResponse.json({
          error: 'Abonnement requis pour accéder à ce match premium',
          requireSubscription: true,
        }, { status: 403 });
      }
    }

    const streamSecret = process.env.STREAM_TOKEN_SECRET || 'boxplus_stream_secret_2026';
    const expiresAt = Math.floor(Date.now() / 1000) + 3600; // 1 heure
    const tokenData = `${matchId}:${user.userId}:${expiresAt}`;
    const signature = crypto.createHmac('sha256', streamSecret).update(tokenData).digest('hex');
    const streamToken = Buffer.from(`${tokenData}:${signature}`).toString('base64url');

    return NextResponse.json({
      streamUrl: match.hls_url,
      token: streamToken,
      expiresAt,
    });
  } catch (error: any) {
    if (error.message?.includes('authentifié') || error.message?.includes('Token')) {
      return NextResponse.json({ error: error.message }, { status: 401 });
    }
    console.error('Stream access error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
