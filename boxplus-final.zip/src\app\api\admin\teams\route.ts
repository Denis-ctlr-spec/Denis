import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAdmin } from '@/lib/server/auth-helpers';

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);
    const result = await query('SELECT * FROM teams ORDER BY name ASC');
    return NextResponse.json({ teams: result.rows });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireAdmin(req);
    const body = await req.json();
    const name = body.name?.trim();
    const shortName = body.shortName?.trim() || null;
    const city = body.city?.trim() || 'Lomé';
    const stadium = body.stadium?.trim() || null;
    const logoUrl = body.logoUrl || null;
    const foundedYear = body.foundedYear ? parseInt(body.foundedYear) : null;
    const description = body.description?.trim() || null;
    const competitionId = body.competitionId || null;

    if (!name) {
      return NextResponse.json({ error: 'Le nom de l\'équipe est requis' }, { status: 400 });
    }

    const result = await query(`
      INSERT INTO teams (name, short_name, city, stadium, logo_url, founded_year, description, competition_id, is_active)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true)
      RETURNING id, name
    `, [name, shortName, city, stadium, logoUrl, foundedYear, description, competitionId]);

    return NextResponse.json({ success: true, team: result.rows[0] }, { status: 201 });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    console.error('Admin create team error:', error);
    return NextResponse.json({ error: error.message || 'Erreur lors de la création de l\'équipe' }, { status: 500 });
  }
}
