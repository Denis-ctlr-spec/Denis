import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { hashPassword } from '@/lib/server/password';
import { signAccessToken, signRefreshToken } from '@/lib/server/auth-helpers';

export async function POST(req: NextRequest) {
  try {
    const { email, password, fullName, phone } = await req.json();

    if (!email || !password || !fullName) {
      return NextResponse.json({ error: 'Email, mot de passe et nom sont requis' }, { status: 400 });
    }

    if (password.length < 6) {
      return NextResponse.json({ error: 'Le mot de passe doit contenir au moins 6 caractères' }, { status: 400 });
    }

    const existing = await query('SELECT id FROM users WHERE email = $1', [email.toLowerCase().trim()]);
    if (existing.rows.length > 0) {
      return NextResponse.json({ error: 'Cet email est déjà utilisé' }, { status: 409 });
    }

    const passwordHash = await hashPassword(password);

    const result = await query(
      `INSERT INTO users (email, password_hash, full_name, phone, role, email_verified, is_active, created_at)
       VALUES ($1, $2, $3, $4, 'spectator', true, true, NOW())
       RETURNING id, email, full_name, phone, role, created_at`,
      [email.toLowerCase().trim(), passwordHash, fullName.trim(), phone?.trim() || null]
    );

    const user = result.rows[0];
    const payload = { userId: user.id, email: user.email, role: user.role };
    const accessToken = signAccessToken(payload);
    const refreshToken = signRefreshToken(payload);

    try {
      await query(
        `INSERT INTO refresh_tokens (user_id, token_hash, expires_at)
         VALUES ($1, $2, NOW() + INTERVAL '7 days')`,
        [user.id, refreshToken]
      );
    } catch (e) {
      console.warn('Could not store refresh token:', e);
    }

    const response = NextResponse.json({
      success: true,
      message: 'Compte créé avec succès',
      user: { id: user.id, email: user.email, fullName: user.full_name, phone: user.phone, role: user.role },
      accessToken,
    }, { status: 201 });

    response.cookies.set('access_token', accessToken, {
      httpOnly: false,
      secure: true,
      sameSite: 'lax',
      maxAge: 60 * 15,
      path: '/',
    });
    response.cookies.set('refresh_token', refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7,
      path: '/',
    });

    return response;
  } catch (error: any) {
    console.error('Register error:', error);
    return NextResponse.json({ error: error.message || 'Erreur serveur lors de la création du compte' }, { status: 500 });
  }
}
