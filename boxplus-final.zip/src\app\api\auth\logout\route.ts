import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { getRefreshTokenFromRequest } from '@/lib/server/auth-helpers';

export async function POST(req: NextRequest) {
  try {
    const refreshToken = getRefreshTokenFromRequest(req);
    if (refreshToken) {
      try {
        await query('DELETE FROM refresh_tokens WHERE token_hash = $1', [refreshToken]);
      } catch (e) {
        // Ignore
      }
    }

    const response = NextResponse.json({ success: true, message: 'Déconnecté avec succès' });
    response.cookies.delete('access_token');
    response.cookies.delete('refresh_token');
    return response;
  } catch (error) {
    console.error('Logout error:', error);
    return NextResponse.json({ error: 'Erreur lors de la déconnexion' }, { status: 500 });
  }
}
