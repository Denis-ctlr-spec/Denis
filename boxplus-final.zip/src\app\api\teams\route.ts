import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';

export async function GET(req: NextRequest) {
  try {
    const result = await query(`
      SELECT id, name, short_name, logo_url, city, stadium, founded_year, description
      FROM teams
      WHERE is_active = true
      ORDER BY name ASC
    `);
    return NextResponse.json({ teams: result.rows });
  } catch (error) {
    console.error('Get teams error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
