import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAdmin } from '@/lib/server/auth-helpers';

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);
    const result = await query('SELECT * FROM competitions ORDER BY created_at DESC');
    return NextResponse.json({ competitions: result.rows });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireAdmin(req);
    const body = await req.json();
    const name = body.name?.trim();
    const rawFormat = body.format || body.type || 'league';
    const format = ['league', 'cup', 'group_stage'].includes(rawFormat) ? rawFormat : 'league';
    const country = body.country?.trim() || 'Togo';
    const description = body.description?.trim() || null;
    const logoUrl = body.logoUrl || null;
    
    // Auto-générer le slug si non fourni
    const rawSlug = body.slug || name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const slug = rawSlug || `comp-${Date.now()}`;

    if (!name) {
      return NextResponse.json({ error: 'Le nom de la compétition est requis' }, { status: 400 });
    }

    const result = await query(`
      INSERT INTO competitions (name, slug, format, country, description, logo_url, is_active)
      VALUES ($1, $2, $3, $4, $5, $6, true)
      RETURNING id, name, slug
    `, [name, slug, format, country, description, logoUrl]);

    return NextResponse.json({ success: true, competition: result.rows[0] }, { status: 201 });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    console.error('Admin create competition error:', error);
    return NextResponse.json({ error: error.message || 'Erreur lors de la création de la compétition' }, { status: 500 });
  }
}
