import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAdmin } from '@/lib/server/auth-helpers';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await requireAdmin(req);

    await query(
      "UPDATE matches SET status = 'finished', ended_at = NOW(), updated_at = NOW() WHERE id = $1",
      [params.id]
    );

    return NextResponse.json({ success: true, message: 'Direct arrêté et match archivé' });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
