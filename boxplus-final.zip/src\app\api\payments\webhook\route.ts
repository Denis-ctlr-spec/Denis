import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    console.log('FedaPay webhook received:', JSON.stringify(body));

    const event = body?.name;
    const transaction = body?.data?.object;

    if (!transaction) {
      return NextResponse.json({ received: true });
    }

    const externalId = transaction.id?.toString();
    const fedapayStatus = transaction.status;

    const paymentResult = await query('SELECT * FROM payments WHERE fedapay_transaction_id = $1', [externalId]);
    if (paymentResult.rows.length === 0) {
      return NextResponse.json({ received: true });
    }

    const payment = paymentResult.rows[0];

    if (fedapayStatus === 'approved' || event === 'transaction.approved') {
      await query("UPDATE payments SET status = 'approved', paid_at = NOW(), updated_at = NOW() WHERE id = $1", [payment.id]);

      const planResult = await query('SELECT * FROM subscription_plans WHERE id = $1', [payment.plan_id]);
      if (planResult.rows.length > 0) {
        const plan = planResult.rows[0];
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + (plan.duration_days || 30));

        await query("UPDATE subscriptions SET status = 'expired' WHERE user_id = $1 AND status = 'active'", [payment.user_id]);

        await query(`
          INSERT INTO subscriptions (user_id, plan_id, status, starts_at, expires_at)
          VALUES ($1, $2, 'active', NOW(), $3)
        `, [payment.user_id, payment.plan_id, expiresAt]);
      }
    } else if (fedapayStatus === 'declined' || fedapayStatus === 'cancelled' || event === 'transaction.declined') {
      await query("UPDATE payments SET status = 'declined', updated_at = NOW() WHERE id = $1", [payment.id]);
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    return NextResponse.json({ error: 'Webhook error' }, { status: 500 });
  }
}
