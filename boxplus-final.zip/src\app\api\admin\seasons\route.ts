import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAdmin } from '@/lib/server/auth-helpers';

export async function GET(req: NextRequest) {
  try {
    const result = await query('SELECT id, name, year_start, year_end, is_current FROM seasons ORDER BY year_start DESC');
    return NextResponse.json({ seasons: result.rows });
  } catch (error: any) {
    console.error('Get seasons error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireAdmin(req);
    const { name, yearStart, yearEnd, isCurrent } = await req.json();

    if (!name || !yearStart || !yearEnd) {
      return NextResponse.json({ error: 'Nom et années requis' }, { status: 400 });
    }

    if (isCurrent) {
      await query('UPDATE seasons SET is_current = false');
    }

    const result = await query(`
      INSERT INTO seasons (name, year_start, year_end, is_current)
      VALUES ($1, $2, $3, $4)
      RETURNING id, name
    `, [name, yearStart, yearEnd, Boolean(isCurrent)]);

    return NextResponse.json({ success: true, season: result.rows[0] }, { status: 201 });
  } catch (error: any) {
    if (error.message?.includes('admin') || error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 403 });
    }
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
