import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/server/db';
import { requireAuth } from '@/lib/server/auth-helpers';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await requireAuth(req);

    if (process.env.FEDAPAY_ENV === 'live') {
      return NextResponse.json({ error: 'Simulation non disponible en production' }, { status: 403 });
    }

    const paymentResult = await query(
      "SELECT * FROM payments WHERE id = $1 AND user_id = $2 AND status = 'pending'",
      [params.id, user.userId]
    );

    if (paymentResult.rows.length === 0) {
      return NextResponse.json({ error: 'Paiement non trouvé ou déjà traité' }, { status: 404 });
    }

    const payment = paymentResult.rows[0];

    // Marquer le paiement comme approuvé
    await query("UPDATE payments SET status = 'approved', paid_at = NOW(), updated_at = NOW() WHERE id = $1", [payment.id]);

    const planResult = await query('SELECT * FROM subscription_plans WHERE id = $1', [payment.plan_id]);
    if (planResult.rows.length > 0) {
      const plan = planResult.rows[0];
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + (plan.duration_days || 30));

      await query("UPDATE subscriptions SET status = 'expired' WHERE user_id = $1 AND status = 'active'", [user.userId]);

      await query(`
        INSERT INTO subscriptions (user_id, plan_id, status, starts_at, expires_at)
        VALUES ($1, $2, 'active', NOW(), $3)
      `, [user.userId, payment.plan_id, expiresAt]);
    }

    return NextResponse.json({ success: true, message: 'Paiement simulé avec succès ! Abonnement activé.' });
  } catch (error: any) {
    if (error.message?.includes('authentifié')) {
      return NextResponse.json({ error: error.message }, { status: 401 });
    }
    console.error('Simulate error:', error);
    return NextResponse.json({ error: error.message || 'Erreur serveur' }, { status: 500 });
  }
}
