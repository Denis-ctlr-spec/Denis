import jwt from 'jsonwebtoken';
import { NextRequest } from 'next/server';

const ACCESS_SECRET = process.env.JWT_ACCESS_SECRET || 'boxplus_secret_2026_jwt_access';
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'boxplus_secret_2026_jwt_refresh';

export interface JwtPayload {
  userId: string;
  email: string;
  role: string;
}

export function signAccessToken(payload: JwtPayload): string {
  return jwt.sign(payload, ACCESS_SECRET, { expiresIn: '15m' });
}

export function signRefreshToken(payload: JwtPayload): string {
  return jwt.sign(payload, REFRESH_SECRET, { expiresIn: '7d' });
}

export function verifyAccessToken(token: string): JwtPayload {
  return jwt.verify(token, ACCESS_SECRET) as JwtPayload;
}

export function verifyRefreshToken(token: string): JwtPayload {
  return jwt.verify(token, REFRESH_SECRET) as JwtPayload;
}

export function getTokenFromRequest(req: NextRequest): string | null {
  const authHeader = req.headers.get('authorization');
  if (authHeader?.startsWith('Bearer ')) {
    return authHeader.substring(7);
  }
  const cookie = req.cookies.get('access_token');
  return cookie?.value || null;
}

export function getRefreshTokenFromRequest(req: NextRequest): string | null {
  const cookie = req.cookies.get('refresh_token');
  return cookie?.value || null;
}

export async function requireAuth(req: NextRequest): Promise<JwtPayload> {
  const token = getTokenFromRequest(req);
  if (!token) {
    throw new Error('Non authentifié');
  }
  try {
    return verifyAccessToken(token);
  } catch {
    throw new Error('Token invalide ou expiré');
  }
}

export async function requireAdmin(req: NextRequest): Promise<JwtPayload> {
  const payload = await requireAuth(req);
  if (payload.role !== 'admin') {
    throw new Error('Accès réservé aux administrateurs');
  }
  return payload;
}
