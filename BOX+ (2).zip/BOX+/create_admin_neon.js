﻿const { Client } = require('pg');
const bcrypt = require('bcryptjs');

const client = new Client({
  connectionString: 'postgresql://neondb_owner:npg_TqPG3QvaFd7L@ep-red-math-b4d16x4k-pooler.c-6.us-east-2.aws.neon.tech/Boxplus?sslmode=require',
  ssl: { rejectUnauthorized: false }
});

async function run() {
  await client.connect();
  const hash = await bcrypt.hash('Admin@2026', 10);
  await client.query(`
    INSERT INTO users (email, password_hash, full_name, role, email_verified, is_active)
    VALUES ('admin@boxplus.tg', $1, 'Super Administrateur', 'admin', true, true)
    ON CONFLICT (email) DO UPDATE SET role = 'admin', password_hash = $1
  `, [hash]);
  console.log('Compte admin créé/mis à jour avec succès');
  await client.end();
}
run().catch(console.error);
