#!/bin/bash
# ============================================================
# BOX+ — Script de déploiement initial
# Usage : bash infra/scripts/setup.sh
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔══════════════════════════════════════╗${NC}"
echo -e "${BLUE}║      BOX+ — Installation initiale    ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════╝${NC}"

# 1. Vérifier les prérequis
echo -e "\n${YELLOW}[1/6] Vérification des prérequis...${NC}"
command -v docker >/dev/null 2>&1 || { echo -e "${RED}Docker non installé.${NC}"; exit 1; }
command -v docker-compose >/dev/null 2>&1 || { echo -e "${RED}Docker Compose non installé.${NC}"; exit 1; }
echo -e "${GREEN}✓ Docker et Docker Compose présents${NC}"

# 2. Copier .env
echo -e "\n${YELLOW}[2/6] Configuration de l'environnement...${NC}"
if [ ! -f .env ]; then
  cp .env.example .env
  echo -e "${YELLOW}⚠ Fichier .env créé depuis .env.example${NC}"
  echo -e "${RED}  → Éditez .env avec vos vraies valeurs avant de continuer !${NC}"
  echo -e "  Notamment : JWT_ACCESS_SECRET, JWT_REFRESH_SECRET, STREAM_TOKEN_SECRET"
  read -p "  Appuyez sur Entrée quand c'est fait..." 
else
  echo -e "${GREEN}✓ .env déjà présent${NC}"
fi

# 3. Générer des secrets forts si vides
echo -e "\n${YELLOW}[3/6] Génération des secrets...${NC}"
generate_secret() {
  openssl rand -hex 32
}

# Remplacer les placeholders dans .env
if grep -q "CHANGE_ME" .env; then
  echo "Génération automatique des secrets..."
  sed -i "s/CHANGE_ME_access_secret_min_32_chars/$(generate_secret)/g" .env
  sed -i "s/CHANGE_ME_refresh_secret_min_32_chars/$(generate_secret)/g" .env
  sed -i "s/CHANGE_ME_stream_token_secret_32/$(generate_secret)/g" .env
  sed -i "s/CHANGE_ME_srs_secret/$(generate_secret | head -c 20)/g" .env
  echo -e "${GREEN}✓ Secrets générés automatiquement${NC}"
fi

# 4. Pull images Docker
echo -e "\n${YELLOW}[4/6] Téléchargement des images Docker...${NC}"
docker-compose pull postgres redis minio srs nginx

# 5. Démarrer les services
echo -e "\n${YELLOW}[5/6] Démarrage des conteneurs...${NC}"
docker-compose up -d postgres redis minio

echo "Attente que PostgreSQL soit prêt..."
until docker-compose exec -T postgres pg_isready -U boxplus >/dev/null 2>&1; do
  sleep 2
done
echo -e "${GREEN}✓ PostgreSQL prêt${NC}"

# 6. Build et démarrage de l'API + Web
echo -e "\n${YELLOW}[6/6] Build et démarrage de l'application...${NC}"
docker-compose up -d --build api web nginx srs

echo -e "\n${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  BOX+ démarré avec succès ! 🚀           ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo -e ""
echo -e "  🌐 Site web    : http://localhost"
echo -e "  🔧 API         : http://localhost/api"
echo -e "  📦 MinIO UI   : http://localhost:9001"
echo -e "  📡 SRS HLS    : http://localhost:8080"
echo -e ""
echo -e "  Pour les logs : ${YELLOW}docker-compose logs -f api${NC}"
echo -e "  Pour stopper  : ${YELLOW}docker-compose down${NC}"
