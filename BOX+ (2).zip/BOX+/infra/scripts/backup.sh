#!/bin/bash
# ==============================================================================
# BOX+ — Script de sauvegarde automatique BDD & Médias
# Cron recommandé : Tous les jours à 03h00 du matin
# 0 3 * * * /opt/boxplus/infra/scripts/backup.sh >> /var/log/boxplus_backup.log 2>&1
# ==============================================================================

set -e

BACKUP_DIR="/var/backups/boxplus"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=14

mkdir -p "$BACKUP_DIR"

echo "================================================="
echo "[$(date)] Démarrage de la sauvegarde BOX+..."
echo "================================================="

# 1. Sauvegarde de la base de données PostgreSQL
echo "-> Export PostgreSQL en cours..."
docker exec -t boxplus_postgres pg_dump -U boxplus -d boxplus_db -F c > "$BACKUP_DIR/db_boxplus_$DATE.dump"
gzip "$BACKUP_DIR/db_boxplus_$DATE.dump"
echo "✔ Base de données sauvegardée : db_boxplus_$DATE.dump.gz"

# 2. Nettoyage des anciennes sauvegardes (+ de 14 jours)
echo "-> Nettoyage des sauvegardes datant de plus de $RETENTION_DAYS jours..."
find "$BACKUP_DIR" -type f -name "*.gz" -mtime +$RETENTION_DAYS -delete
echo "✔ Nettoyage terminé."

echo "[$(date)] Sauvegarde terminée avec succès !"
