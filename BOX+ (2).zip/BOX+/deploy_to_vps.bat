@echo off
REM ==============================================================================
REM BOX+ — Script de déploiement automatique vers votre VPS distant
REM Usage : deploy_to_vps.bat IP_DU_VPS (ex: deploy_to_vps.bat 194.163.150.20)
REM ==============================================================================

setlocal enabledelayedexpansion

if "%~1"=="" (
    echo.
    echo [ERREUR] Veuillez renseigner l'adresse IP de votre serveur VPS.
    echo Exemple : deploy_to_vps.bat 194.163.150.20
    echo.
    exit /b 1
)

set VPS_IP=%~1
set VPS_USER=root
set REMOTE_DIR=/opt/boxplus

echo ==============================================================================
echo           BOX+ -- Deploiement de la plateforme sur le serveur VPS
echo ==============================================================================
echo VPS Cible : %VPS_USER%@%VPS_IP%
echo Dossier distant : %REMOTE_DIR%
echo.

echo [1/4] Creation du repertoire distant sur le VPS...
ssh %VPS_USER%@%VPS_IP% "mkdir -p %REMOTE_DIR%"
if %ERRORLEVEL% NEQ 0 (
    echo [ERREUR] Impossible de se connecter en SSH au serveur. Verifiez vos identifiants.
    exit /b 1
)

echo.
echo [2/4] Copie des fichiers BOX+ vers le VPS en cours...
scp -r "E:\BOX+\*" %VPS_USER%@%VPS_IP%:%REMOTE_DIR%/

echo.
echo [3/4] Installation automatique de Docker sur le VPS et configuration...
ssh %VPS_USER%@%VPS_IP% "bash -s" << 'EOF'
set -e
if ! command -v docker &> /dev/null; then
    echo "Installation de Docker sur le serveur..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
fi

cd /opt/boxplus
if [ ! -f .env ]; then
    cp .env.example .env
fi

echo "Ouverture des ports sur le pare-feu (UFW)..."
if command -v ufw &> /dev/null; then
    ufw allow 80/tcp
    ufw allow 443/tcp
    ufw allow 1935/tcp
fi
EOF

echo.
echo [4/4] Lancement des conteneurs BOX+ (Docker Compose)...
ssh %VPS_USER%@%VPS_IP% "cd %REMOTE_DIR% && docker compose up -d --build"

echo.
echo ==============================================================================
echo           SUCCES ! BOX+ est desormais en cours d'execution sur votre VPS
echo ==============================================================================
echo Site Web : http://%VPS_IP%
echo API REST : http://%VPS_IP%/api
echo Flux RTMP : rtmp://%VPS_IP%:1935/live
echo ==============================================================================
pause
