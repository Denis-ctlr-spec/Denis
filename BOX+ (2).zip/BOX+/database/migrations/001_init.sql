-- ============================================================
-- BOX+ — Migrations complètes (ordre d'exécution)
-- Exécutez ce fichier en premier au démarrage de postgres
-- ============================================================

-- 001 Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";

-- 002 Enums
CREATE TYPE user_role AS ENUM ('spectator', 'moderator', 'operator', 'admin');
CREATE TYPE match_status AS ENUM ('scheduled','live','finished','cancelled','postponed');
CREATE TYPE match_event_type AS ENUM (
  'goal','own_goal','penalty_goal',
  'yellow_card','red_card','second_yellow',
  'substitution','injury','kickoff','halftime','fulltime'
);
CREATE TYPE competition_format AS ENUM ('league','cup','group_stage');
CREATE TYPE subscription_type AS ENUM ('match','monthly','season');
CREATE TYPE subscription_status AS ENUM ('active','expired','cancelled','pending','suspended');
CREATE TYPE payment_status AS ENUM ('pending','approved','declined','cancelled','refunded','partial_refund');
CREATE TYPE payment_method AS ENUM ('tmoney','flooz','card','transfer');
CREATE TYPE discount_type AS ENUM ('percentage','fixed');

-- 003 Fonction updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

-- 004 Users
CREATE TABLE users (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email          CITEXT UNIQUE NOT NULL,
  phone          VARCHAR(20) UNIQUE,
  password_hash  TEXT NOT NULL,
  full_name      VARCHAR(255) NOT NULL,
  avatar_url     TEXT,
  role           user_role NOT NULL DEFAULT 'spectator',
  email_verified BOOLEAN NOT NULL DEFAULT FALSE,
  phone_verified BOOLEAN NOT NULL DEFAULT FALSE,
  is_active      BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at  TIMESTAMP WITH TIME ZONE,
  created_at     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_users_role ON users(role);
CREATE TRIGGER users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 005 Tokens auth
CREATE TABLE refresh_tokens (
  id                 UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id            UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash         TEXT UNIQUE NOT NULL,
  device_fingerprint TEXT,
  user_agent         TEXT,
  ip_address         INET,
  expires_at         TIMESTAMP WITH TIME ZONE NOT NULL,
  created_at         TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_refresh_tokens_user_id ON refresh_tokens(user_id);
CREATE INDEX idx_refresh_tokens_expires_at ON refresh_tokens(expires_at);

CREATE TABLE verification_tokens (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token      TEXT UNIQUE NOT NULL,
  type       VARCHAR(50) NOT NULL,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  used_at    TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_verification_tokens_user ON verification_tokens(user_id);
CREATE INDEX idx_verification_tokens_token ON verification_tokens(token);

-- 006 Saisons & Compétitions
CREATE TABLE seasons (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name       VARCHAR(100) NOT NULL,
  year_start INTEGER NOT NULL,
  year_end   INTEGER NOT NULL,
  is_current BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX idx_seasons_current ON seasons(is_current) WHERE is_current = TRUE;

CREATE TABLE competitions (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        VARCHAR(255) NOT NULL,
  slug        VARCHAR(100) UNIQUE NOT NULL,
  description TEXT,
  logo_url    TEXT,
  banner_url  TEXT,
  country     VARCHAR(100) NOT NULL DEFAULT 'Togo',
  region      VARCHAR(100),
  format      competition_format NOT NULL DEFAULT 'league',
  season_id   UUID REFERENCES seasons(id) ON DELETE SET NULL,
  is_active   BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_competitions_season ON competitions(season_id);
CREATE TRIGGER competitions_updated_at BEFORE UPDATE ON competitions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TABLE teams (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name           VARCHAR(255) NOT NULL,
  short_name     VARCHAR(10),
  logo_url       TEXT,
  city           VARCHAR(100),
  stadium        VARCHAR(255),
  founded_year   INTEGER,
  description    TEXT,
  competition_id UUID REFERENCES competitions(id) ON DELETE SET NULL,
  is_active      BOOLEAN NOT NULL DEFAULT TRUE,
  created_at     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_teams_competition ON teams(competition_id);
CREATE TRIGGER teams_updated_at BEFORE UPDATE ON teams FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 007 Matchs
CREATE TABLE matches (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  competition_id UUID NOT NULL REFERENCES competitions(id) ON DELETE CASCADE,
  season_id      UUID REFERENCES seasons(id) ON DELETE SET NULL,
  home_team_id   UUID NOT NULL REFERENCES teams(id),
  away_team_id   UUID NOT NULL REFERENCES teams(id),
  matchday       INTEGER,
  scheduled_at   TIMESTAMP WITH TIME ZONE NOT NULL,
  status         match_status NOT NULL DEFAULT 'scheduled',
  home_score     INTEGER NOT NULL DEFAULT 0,
  away_score     INTEGER NOT NULL DEFAULT 0,
  minute         INTEGER,
  stream_key     VARCHAR(100) UNIQUE,
  hls_url        TEXT,
  replay_url     TEXT,
  thumbnail_url  TEXT,
  is_free        BOOLEAN NOT NULL DEFAULT FALSE,
  is_featured    BOOLEAN NOT NULL DEFAULT FALSE,
  started_at     TIMESTAMP WITH TIME ZONE,
  ended_at       TIMESTAMP WITH TIME ZONE,
  created_at     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  CONSTRAINT different_teams CHECK (home_team_id != away_team_id)
);
CREATE INDEX idx_matches_competition ON matches(competition_id);
CREATE INDEX idx_matches_season ON matches(season_id);
CREATE INDEX idx_matches_scheduled ON matches(scheduled_at);
CREATE INDEX idx_matches_status ON matches(status);
CREATE INDEX idx_matches_featured ON matches(is_featured, scheduled_at);
CREATE INDEX idx_matches_stream_key ON matches(stream_key);
CREATE TRIGGER matches_updated_at BEFORE UPDATE ON matches FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TABLE match_events (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  match_id    UUID NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  type        match_event_type NOT NULL,
  minute      INTEGER NOT NULL,
  extra_time  INTEGER,
  player_name VARCHAR(255),
  team_id     UUID REFERENCES teams(id),
  description TEXT,
  created_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_match_events_match ON match_events(match_id);

-- 008 Classements
CREATE TABLE standings (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  competition_id  UUID NOT NULL REFERENCES competitions(id) ON DELETE CASCADE,
  season_id       UUID NOT NULL REFERENCES seasons(id) ON DELETE CASCADE,
  team_id         UUID NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  played          INTEGER NOT NULL DEFAULT 0,
  won             INTEGER NOT NULL DEFAULT 0,
  drawn           INTEGER NOT NULL DEFAULT 0,
  lost            INTEGER NOT NULL DEFAULT 0,
  goals_for       INTEGER NOT NULL DEFAULT 0,
  goals_against   INTEGER NOT NULL DEFAULT 0,
  goal_difference INTEGER GENERATED ALWAYS AS (goals_for - goals_against) STORED,
  points          INTEGER NOT NULL DEFAULT 0,
  updated_at      TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  UNIQUE(competition_id, season_id, team_id)
);
CREATE INDEX idx_standings_competition_season ON standings(competition_id, season_id);

-- 009 Abonnements
CREATE TABLE subscription_plans (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(100) NOT NULL,
  slug          VARCHAR(50) UNIQUE NOT NULL,
  description   TEXT,
  type          subscription_type NOT NULL,
  price         DECIMAL(10,2) NOT NULL,
  currency      VARCHAR(3) NOT NULL DEFAULT 'XOF',
  duration_days INTEGER NOT NULL,
  features      JSONB NOT NULL DEFAULT '[]',
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order    INTEGER NOT NULL DEFAULT 0,
  created_at    TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE TRIGGER plans_updated_at BEFORE UPDATE ON subscription_plans FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

INSERT INTO subscription_plans (name, slug, type, price, duration_days, sort_order, features) VALUES
  ('Pass Match', 'pass-match', 'match', 500, 1, 1,
   '["Accès à 1 match", "Qualité jusqu''à 720p", "Compatible mobile"]'),
  ('Pass Mensuel', 'mensuel', 'monthly', 2500, 30, 2,
   '["Matchs illimités", "Replays inclus", "Qualité jusqu''à 1080p", "2 appareils simultanés"]'),
  ('Pass Saison', 'saison', 'season', 15000, 180, 3,
   '["Tous les matchs de la saison", "Replays et résumés", "Qualité 1080p", "3 appareils simultanés"]');

CREATE TABLE subscriptions (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_id          UUID NOT NULL REFERENCES subscription_plans(id),
  status           subscription_status NOT NULL DEFAULT 'pending',
  starts_at        TIMESTAMP WITH TIME ZONE,
  expires_at       TIMESTAMP WITH TIME ZONE,
  auto_renew       BOOLEAN NOT NULL DEFAULT FALSE,
  match_id         UUID REFERENCES matches(id) ON DELETE SET NULL,
  promo_code       VARCHAR(50),
  discount_applied DECIMAL(10,2) DEFAULT 0,
  created_at       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_subscriptions_user ON subscriptions(user_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);
CREATE INDEX idx_subscriptions_expires ON subscriptions(expires_at);
CREATE TRIGGER subscriptions_updated_at BEFORE UPDATE ON subscriptions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 010 Paiements
CREATE TABLE payments (
  id                     UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id                UUID NOT NULL REFERENCES users(id),
  subscription_id        UUID REFERENCES subscriptions(id),
  plan_id                UUID NOT NULL REFERENCES subscription_plans(id),
  fedapay_transaction_id VARCHAR(255) UNIQUE,
  fedapay_reference      VARCHAR(255),
  amount                 DECIMAL(10,2) NOT NULL,
  currency               VARCHAR(3) NOT NULL DEFAULT 'XOF',
  status                 payment_status NOT NULL DEFAULT 'pending',
  payment_method         payment_method,
  phone_number           VARCHAR(20),
  webhook_payload        JSONB,
  failure_reason         TEXT,
  paid_at                TIMESTAMP WITH TIME ZONE,
  created_at             TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at             TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_payments_user ON payments(user_id);
CREATE INDEX idx_payments_fedapay_id ON payments(fedapay_transaction_id);
CREATE INDEX idx_payments_status ON payments(status);
CREATE TRIGGER payments_updated_at BEFORE UPDATE ON payments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TABLE promo_codes (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code             VARCHAR(50) UNIQUE NOT NULL,
  discount_type    discount_type NOT NULL,
  discount_value   DECIMAL(10,2) NOT NULL,
  max_uses         INTEGER,
  current_uses     INTEGER NOT NULL DEFAULT 0,
  valid_from       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  valid_until      TIMESTAMP WITH TIME ZONE,
  applicable_plans UUID[],
  is_active        BOOLEAN NOT NULL DEFAULT TRUE,
  created_at       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 011 Streaming
CREATE TABLE stream_tokens (
  id                 UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id            UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  match_id           UUID NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  token              TEXT UNIQUE NOT NULL,
  device_fingerprint TEXT NOT NULL,
  ip_address         INET,
  expires_at         TIMESTAMP WITH TIME ZONE NOT NULL,
  is_revoked         BOOLEAN NOT NULL DEFAULT FALSE,
  last_used_at       TIMESTAMP WITH TIME ZONE,
  created_at         TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_stream_tokens_token ON stream_tokens(token);
CREATE INDEX idx_stream_tokens_expires ON stream_tokens(expires_at);

CREATE TABLE watch_sessions (
  id                 UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id            UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  match_id           UUID NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  stream_token_id    UUID REFERENCES stream_tokens(id),
  device_fingerprint TEXT NOT NULL,
  ip_address         INET,
  user_agent         TEXT,
  last_ping          TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  is_active          BOOLEAN NOT NULL DEFAULT TRUE,
  created_at         TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_watch_sessions_user ON watch_sessions(user_id);
CREATE INDEX idx_watch_sessions_active ON watch_sessions(user_id, is_active) WHERE is_active = TRUE;

-- 012 Admin logs
CREATE TABLE admin_logs (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
  action      VARCHAR(100) NOT NULL,
  entity_type VARCHAR(50),
  entity_id   UUID,
  old_data    JSONB,
  new_data    JSONB,
  ip_address  INET,
  created_at  TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_admin_logs_entity ON admin_logs(entity_type, entity_id);
CREATE INDEX idx_admin_logs_created ON admin_logs(created_at DESC);

CREATE TABLE scheduled_notifications (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subscription_id  UUID REFERENCES subscriptions(id) ON DELETE CASCADE,
  type             VARCHAR(50) NOT NULL,
  scheduled_at     TIMESTAMP WITH TIME ZONE NOT NULL,
  sent_at          TIMESTAMP WITH TIME ZONE,
  is_sent          BOOLEAN NOT NULL DEFAULT FALSE,
  created_at       TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- ============================================================
-- Données de démo : saison 2025-2026
-- ============================================================
INSERT INTO seasons (name, year_start, year_end, is_current) VALUES ('Saison 2025-2026', 2025, 2026, TRUE);
