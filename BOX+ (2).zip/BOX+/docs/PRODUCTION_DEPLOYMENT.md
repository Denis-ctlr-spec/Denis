# Guide Complet de Déploiement en Production — BOX+

Ce guide détaille pas-à-pas la mise en production de la plateforme de streaming **BOX+** sur un serveur VPS (Ubuntu 22.04 / 24.04 LTS).

---

## 1. Choix du VPS & Spécifications Conseillées

| Étape | Fournisseurs Recommandés | Configuration Minimale | Coût Estimé |
| :--- | :--- | :--- | :--- |
| **Lancement** (50 à 300 spectateurs) | Hetzner Cloud (CPX31 / CCX13) ou OVH | 4 vCPU / 8 Go RAM / 160 Go NVMe | ~15 à 30 € / mois |
| **Expansion** (300 à 1 500 spectateurs) | Hetzner Cloud (CPX51 / CCX23) | 8 vCPU / 16 Go RAM / 300 Go NVMe | ~50 à 80 € / mois |

> **Bande passante :** Choisissez un hébergeur proposant du trafic non mesuré ou généreux (ex : Hetzner 20 To inclus). Le transcodage multi-qualité (360p/720p) consomme environ 1,8 Mbps en moyenne par spectateur actif.

---

## 2. Préparation du Serveur (Ubuntu 22.04 / 24.04)

Connectez-vous en SSH à votre serveur :
```bash
ssh root@votre-ip-vps
```

### A. Mettre à jour le système
```bash
apt update && apt upgrade -y
apt install -y curl git ufw fail2ban
```

### B. Installer Docker & Docker Compose
```bash
# Installation officielle de Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Vérification
docker --version
docker compose version
```

### C. Configurer le Pare-feu UFW
```bash
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh           # Port 22 (ou votre port SSH personnalisé)
ufw allow http          # Port 80 (Certbot & Web)
ufw allow https         # Port 443 (Web & Flux HLS)
ufw allow 1935/tcp      # Port RTMP (Flux OBS / vMix des cameramen)
ufw enable
```

---

## 3. Déploiement du Projet BOX+

### A. Cloner le projet sur le serveur
```bash
mkdir -p /opt
cd /opt
# Cloner votre dépôt Git ou téléverser les fichiers de E:\BOX+
git clone <URL_DE_VOTRE_DEPOT_BOX+> boxplus
cd boxplus
```

### B. Configurer les variables de production
Copiez le modèle d'environnement et éditez les valeurs :
```bash
cp .env.example .env
nano .env
```

**Valeurs impératives à définir en production :**
- `NODE_ENV=production`
- `DOMAIN=boxplus.tg` (Votre nom de domaine)
- `POSTGRES_PASSWORD=votre_mot_de_passe_sql_ultra_robuste`
- `REDIS_PASSWORD=votre_mot_de_passe_redis`
- `JWT_ACCESS_SECRET=cle_secrete_jwt_32_caracteres_aleatoire`
- `JWT_REFRESH_SECRET=cle_secrete_refresh_32_caracteres_aleatoire`
- `STREAM_TOKEN_SECRET=cle_secrete_stream_32_caracteres_aleatoire`
- `FEDAPAY_SECRET_KEY=sk_live_...` (Clé de production FedaPay)
- `FEDAPAY_PUBLIC_KEY=pk_live_...`
- `FEDAPAY_WEBHOOK_SECRET=votre_secret_webhook_fedapay`
- `FEDAPAY_ENV=live`
- `SMTP_USER` & `SMTP_PASS` (Identifiants Brevo pour les e-mails)

---

## 4. Obtention du Certificat SSL Let's Encrypt (HTTPS)

Avant de lancer les conteneurs complets, générons le certificat SSL pour votre domaine :

```bash
# 1. Remplacer boxplus.tg par votre vrai domaine
DOMAIN="boxplus.tg"
EMAIL="admin@boxplus.tg"

# 2. Lancer temporairement Certbot pour émettre le certificat
docker run -it --rm --name certbot \
  -p 80:80 \
  -v "boxplus_certbot_certs:/etc/letsencrypt" \
  certbot/certbot certonly --standalone \
  -d $DOMAIN -d www.$DOMAIN \
  --email $EMAIL --agree-tos --no-eff-email
```

---

## 5. Démarrage de la Plateforme Complète

Une fois le certificat en place, lancez la totalité des services :

```bash
# Construction et lancement de l'infrastructure en arrière-plan
docker compose up -d --build
```

Vérifiez que tous les conteneurs sont sains et actifs :
```bash
docker compose ps
```

Vous devriez voir les 7 conteneurs avec le statut `Up` :
- `boxplus_postgres` (PostgreSQL 16)
- `boxplus_redis` (Redis 7)
- `boxplus_minio` (Stockage S3)
- `boxplus_srs` (Serveur RTMP/HLS)
- `boxplus_api` (API Node.js)
- `boxplus_web` (Frontend Next.js)
- `boxplus_nginx` (Reverse Proxy)

---

## 6. Automatisation des Sauvegardes Quotidiennes

Pour garantir la pérennité des données d'utilisateurs et de paiements :

```bash
chmod +x /opt/boxplus/infra/scripts/backup.sh

# Ajouter au Crontab pour une exécution tous les jours à 03h00
(crontab -l 2>/dev/null; echo "0 3 * * * /opt/boxplus/infra/scripts/backup.sh >> /var/log/boxplus_backup.log 2>&1") | crontab -
```

---

## 7. Procédure pour Diffuser un Match depuis le Terrain (OBS / vMix)

1. Connectez-vous à la console d'administration sur `https://boxplus.tg/admin/direct`.
2. Repérez le match programmé.
3. Récupérez les identifiants de diffusion :
   - **URL du serveur :** `rtmp://boxplus.tg:1935/live`
   - **Clé de stream :** `match_xxxxxxxxxxxx` (générée par le panneau)
4. Dans **OBS Studio** :
   - Allez dans **Paramètres** > **Flux**.
   - Service : **Personnalisé...**
   - Serveur : `rtmp://boxplus.tg:1935/live`
   - Clé de stream : collez la clé du match.
   - Encodeur recommandé : **x264** ou **NVENC** (profil 1080p ou 720p à 2500 kbps, intervalle de keyframes = 2s).
5. Cliquez sur **Commencer le streaming**. Le serveur SRS prend le relais, FFmpeg découpe le flux en direct et les spectateurs accèdent au match sur l'application.
