# Guide d'Intégration et Déploiement Production FedaPay — BOX+

Ce guide détaille le fonctionnement de l'agrégation de paiement Mobile Money pour le Togo et l'Afrique de l'Ouest dans **BOX+**.

---

## 1. Pourquoi FedaPay pour le Togo ?

| Critère | FedaPay | CinetPay | PayDunya |
| :--- | :--- | :--- | :--- |
| **Opérateurs Togo** | **T-Money (Togocom)** + **Flooz (Moov)** natifs | Couverture partielle | Axé Sénégal |
| **Agrément** | Agréé BCEAO | Agréé BCEAO | Agréé BCEAO |
| **Devises** | XOF (Franc CFA) | XOF | XOF |
| **Webhooks** | HMAC-SHA256 sécurisés | Webhooks classiques | Webhooks |
| **Sandbox** | Immédiate sans compte pro | Délai de validation | Validation requise |

---

## 2. Variables d'Environnement (.env)

Dans votre fichier `.env` sur le serveur :

```ini
# --- Environnement de TEST (Sandbox) ---
FEDAPAY_SECRET_KEY=sk_sandbox_XXXXXXXXXXXXXXXXXXXX
FEDAPAY_PUBLIC_KEY=pk_sandbox_XXXXXXXXXXXXXXXXXXXX
FEDAPAY_WEBHOOK_SECRET=votre_secret_webhook_ici
FEDAPAY_ENV=sandbox

# --- Passage en PRODUCTION (Live) ---
# 1. Créez un compte entreprise vérifié sur https://fedapay.com
# 2. Récupérez vos clés Live dans Paramètres > Clés API
# 3. Décommentez et remplacez les valeurs ci-dessous :
# FEDAPAY_SECRET_KEY=sk_live_YYYYYYYYYYYYYYYYYYYY
# FEDAPAY_PUBLIC_KEY=pk_live_YYYYYYYYYYYYYYYYYYYY
# FEDAPAY_WEBHOOK_SECRET=live_webhook_secret_ici
# FEDAPAY_ENV=live
```

---

## 3. Configuration du Webhook sur le Dashboard FedaPay

Pour que les abonnements s'activent instantanément après validation USSD sur le téléphone du client :

1. Connectez-vous à votre [Dashboard FedaPay](https://fedapay.com).
2. Rendez-vous dans **Développeurs** > **Webhooks**.
3. Cliquez sur **Ajouter un endpoint**.
4. Renseignez l'URL de votre serveur BOX+ :
   ```
   https://boxplus.tg/api/payments/webhook
   ```
5. Sélectionnez les événements à écouter :
   - `transaction.approved` (Validation du paiement et activation de l'accès)
   - `transaction.canceled` (Annulation par le spectateur)
   - `transaction.declined` (Solde insuffisant ou rejet opérateur)
6. Copiez le **Secret de signature** fourni par FedaPay et collez-le dans `FEDAPAY_WEBHOOK_SECRET` de votre fichier `.env`.

---

## 4. Flux de Paiement Spectateur

```
Spectateur                  Application BOX+                     FedaPay & Opérateur (T-Money/Flooz)
    |                              |                                              |
    |---- 1. Choisit Pass -------->|                                              |
    |     (ex: Mensuel 2500 XOF)   |                                              |
    |---- 2. Saisit numéro ------->|---- 3. Initialisation Transaction ---------->|
    |                              |<--- 4. Token FedaPay + URL de Checkout ------|
    |                              |                                              |
    |                              |                                       (Push USSD)
    |<-----------------------------|-------------------------------- 5. Saisie PIN Mobile
    |                              |                                              |
    |                              |<=== 6. Webhook 'transaction.approved' <======|
    |                              |     (Signature HMAC-SHA256 validée)          |
    |                              |     -> Activation abonnement en BDD          |
    |                              |     -> Email confirmation Brevo              |
    |                              |                                              |
    |<--- 7. Redirection confirmation                                             |
          (Accès direct débloqué)
```

---

## 5. Mode Démonstration / Sandbox Intégré

Pour tester immédiatement le parcours sans carte ni solde T-Money réel :
1. Cliquez sur une formule sur `/abonnement`.
2. L'application génère un paiement de test.
3. Sur la page de confirmation, un encart **« Mode Sandbox »** apparaît avec un bouton **« Simuler la confirmation opérateur »**.
4. Cliquez dessus : le serveur simule le webhook officiel, valide le paiement, active l'abonnement et débloque le flux vidéo en moins d'une seconde.
