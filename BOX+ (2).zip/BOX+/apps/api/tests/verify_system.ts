/**
 * Script de tests fonctionnels et de vérification d'intégrité BOX+
 * Exécution : tsx tests/verify_system.ts
 */

import { signAccessToken, verifyAccessToken } from '../src/utils/jwt';
import crypto from 'crypto';

async function runTests() {
  console.log('\x1b[34m====================================================\x1b[0m');
  console.log('\x1b[34m    BOX+ — SUITE DE TESTS D\'INTÉGRITÉ & SÉCURITÉ     \x1b[0m');
  console.log('\x1b[34m====================================================\x1b[0m\n');

  let passed = 0;
  let failed = 0;

  function assert(title: string, condition: boolean) {
    if (condition) {
      console.log(`\x1b[32m✔ [SUCCÈS]\x1b[0m ${title}`);
      passed++;
    } else {
      console.log(`\x1b[31m✖ [ÉCHEC]\x1b[0m ${title}`);
      failed++;
    }
  }

  // 1. TEST SÉCURITÉ JWT
  try {
    const dummyUser = { sub: 'usr_test_123', email: 'test@boxplus.tg', role: 'spectator' };
    const token = signAccessToken(dummyUser);
    const decoded = verifyAccessToken(token);
    assert('Signature et décodage JWT valides', decoded.sub === dummyUser.sub && decoded.email === dummyUser.email);
  } catch (err: any) {
    assert('Signature et décodage JWT valides', false);
  }

  // 2. TEST HASHAGE & TOKENS DE FLUX STREAM HMAC
  try {
    const secret = 'test_secret_stream_key_32_chars_ok';
    const streamPayload = 'usr_1:match_4:stream_key_88:dev_fp_chrome:1730000000';
    const sig1 = crypto.createHmac('sha256', secret).update(streamPayload).digest('hex');
    const sig2 = crypto.createHmac('sha256', secret).update(streamPayload).digest('hex');
    const fakeSig = crypto.createHmac('sha256', secret).update(streamPayload + '_fake').digest('hex');

    assert('Génération signature HMAC stream reproductible', sig1 === sig2);
    assert('Rejet immédiat d\'une fausse signature HMAC de stream', sig1 !== fakeSig);
  } catch (err) {
    assert('Vérification HMAC de stream', false);
  }

  // 3. TEST VÉRIFICATION SIGNATURE WEBHOOK FEDAPAY
  try {
    const webhookSecret = 'whsec_sample_secret';
    const rawPayload = JSON.stringify({ event: 'transaction.approved', entity: { id: 12345, status: 'approved' } });
    const validSignature = crypto.createHmac('sha256', webhookSecret).update(rawPayload).digest('hex');
    
    // Test validation conforme
    const isAuthentic = crypto.createHmac('sha256', webhookSecret).update(rawPayload).digest('hex') === validSignature;
    assert('Vérification signature Webhook FedaPay conforme', isAuthentic);
  } catch (err) {
    assert('Vérification signature Webhook FedaPay conforme', false);
  }

  // 4. TEST FORMATAGE ET PRIX FCFA (XOF)
  try {
    const price = 2500;
    const formatted = new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'XOF', minimumFractionDigits: 0 }).format(price);
    assert('Formatage monétaire Franc CFA (XOF) valide', formatted.includes('2') && formatted.includes('500'));
  } catch (err) {
    assert('Formatage monétaire Franc CFA (XOF) valide', false);
  }

  console.log('\n\x1b[34m----------------------------------------------------\x1b[0m');
  console.log(`Résultats des tests : \x1b[32m${passed} réussis\x1b[0m, \x1b[31m${failed} échoués\x1b[0m.`);
  console.log('\x1b[34m====================================================\x1b[0m\n');
}

runTests();
