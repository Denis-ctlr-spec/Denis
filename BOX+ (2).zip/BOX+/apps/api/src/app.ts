import http from 'http';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import { config } from './config';
import { errorHandler, notFoundHandler } from './middleware/errorHandler';
import { securityHeaders, sanitizeInputs } from './middleware/security.middleware';
import authRoutes from './routes/auth.routes';
import { matchRoutes, adminMatchRoutes } from './routes/matches.routes';
import { competitionRoutes, teamRoutes } from './routes/competitions.routes';
import adminRoutes from './routes/admin.routes';
import { streamRoutes, webhookRoutes } from './routes/stream.routes';
import paymentRoutes from './routes/payment.routes';
import { setupWebSocket } from './websocket';
import { logger } from './utils/logger';

const app = express();

// ── Sécurité globale ──────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(securityHeaders);
app.set('trust proxy', 1);

app.use(cors({
  origin: config.server.corsOrigins,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Device-Fingerprint', 'x-fedapay-signature'],
}));

// Capture du rawBody pour la vérification exacte des signatures Webhook
app.use(express.json({
  limit: '50kb',
  verify: (req: any, _res, buf) => {
    req.rawBody = buf.toString();
  },
}));

app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(sanitizeInputs);

if (config.isDev) {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined', { stream: { write: (m) => logger.info(m.trim()) } }));
}

// ── Rate Limiting adaptatif ───────────────────────────────
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 400,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Trop de requêtes. Veuillez patienter.' },
});
app.use(globalLimiter);

// ── Routes ────────────────────────────────────────────────
app.get('/health', (_req, res) =>
  res.json({ status: 'ok', timestamp: new Date().toISOString(), service: 'BOX+ API' })
);

app.use('/auth', authRoutes);
app.use('/matches', matchRoutes);
app.use('/admin/matches', adminMatchRoutes);
app.use('/competitions', competitionRoutes);
app.use('/teams', teamRoutes);
app.use('/admin', adminRoutes);

// Streaming et Webhooks SRS
app.use('/stream', streamRoutes);
app.use('/webhooks', webhookRoutes);

// Paiements Mobile Money FedaPay
app.use('/payments', paymentRoutes);

// ── Gestion erreurs ───────────────────────────────────────
app.use(notFoundHandler);
app.use(errorHandler);

// ── Serveur HTTP + WebSocket ──────────────────────────────
export function createServer() {
  const server = http.createServer(app);
  setupWebSocket(server);
  return server;
}

export default app;
