import { Request, Response, NextFunction } from 'express';
import { verifyAccessToken } from '../utils/jwt';
import { AppError } from './errorHandler';

export type UserRole = 'spectator' | 'moderator' | 'operator' | 'admin';

declare global {
  namespace Express {
    interface Request {
      user?: {
        sub: string;
        email: string;
        role: UserRole;
      };
    }
  }
}

/** Middleware : vérifie le Bearer token JWT */
export function authenticate(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return next(new AppError('Token d\'authentification manquant.', 401));
  }

  const token = authHeader.slice(7);
  try {
    const payload = verifyAccessToken(token);
    req.user = { sub: payload.sub, email: payload.email, role: payload.role as UserRole };
    next();
  } catch (err: any) {
    if (err.name === 'TokenExpiredError') {
      return next(new AppError('Session expirée. Reconnectez-vous.', 401));
    }
    return next(new AppError('Token invalide.', 401));
  }
}

/** Middleware : exige un rôle minimum */
export function requireRole(...roles: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) return next(new AppError('Non authentifié.', 401));
    if (!roles.includes(req.user.role)) {
      return next(new AppError('Accès refusé. Privilèges insuffisants.', 403));
    }
    next();
  };
}

/** Middleware optionnel : authentifie si token présent, sinon continue */
export function optionalAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) return next();

  const token = authHeader.slice(7);
  try {
    const payload = verifyAccessToken(token);
    req.user = { sub: payload.sub, email: payload.email, role: payload.role as UserRole };
  } catch {
    // Ignorer l'erreur pour les routes optionnelles
  }
  next();
}
