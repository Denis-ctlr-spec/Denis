import { Request, Response, NextFunction } from 'express';

/**
 * Middleware de durcissement de la sécurité HTTP
 * - Protection Clickjacking
 * - Protection MIME-Type sniffing
 * - Cross-Origin Resource Policy
 * - HSTS (Strict-Transport-Security)
 */
export function securityHeaders(req: Request, res: Response, next: NextFunction) {
  // Empêche l'intégration dans un iframe externe non autorisé
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');

  // Empêche le navigateur de deviner le type MIME
  res.setHeader('X-Content-Type-Options', 'nosniff');

  // Protection XSS standard
  res.setHeader('X-XSS-Protection', '1; mode=block');

  // Contrôle de référencement
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

  // Forcer HTTPS en production
  if (process.env.NODE_ENV === 'production') {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  }

  // Permissions Policy (Désactiver capteurs inutiles)
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');

  next();
}

/**
 * Nettoyage et assainissement des entrées pour bloquer les injections XSS
 */
export function sanitizeInputs(req: Request, res: Response, next: NextFunction) {
  const sanitize = (val: any): any => {
    if (typeof val === 'string') {
      return val.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '').trim();
    }
    if (val !== null && typeof val === 'object') {
      for (const k in val) {
        val[k] = sanitize(val[k]);
      }
    }
    return val;
  };

  if (req.body) req.body = sanitize(req.body);
  if (req.query) req.query = sanitize(req.query);

  next();
}
