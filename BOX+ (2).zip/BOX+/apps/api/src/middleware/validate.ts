import { Request, Response, NextFunction } from 'express';
import { validationResult } from 'express-validator';

/** Middleware qui intercepte les erreurs de validation express-validator */
export function validate(req: Request, res: Response, next: NextFunction) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      error: 'Données invalides.',
      details: errors.array().map((e) => ({ field: e.type === 'field' ? (e as any).path : 'unknown', message: e.msg })),
    });
  }
  next();
}
