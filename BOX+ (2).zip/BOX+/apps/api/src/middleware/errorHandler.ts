import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';

export class AppError extends Error {
  public readonly statusCode: number;
  public readonly isOperational: boolean;

  constructor(message: string, statusCode = 500, isOperational = true) {
    super(message);
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.isOperational = isOperational;
    Error.captureStackTrace(this, this.constructor);
  }
}

export function errorHandler(
  err: any,
  req: Request,
  res: Response,
  _next: NextFunction
) {
  // Erreur applicative connue
  if (err instanceof AppError) {
    if (err.statusCode >= 500) {
      logger.error(`[${err.statusCode}] ${err.message}`, { stack: err.stack, path: req.path });
    }
    return res.status(err.statusCode).json({
      success: false,
      error: err.message,
      code: err.statusCode,
    });
  }

  // Erreur de validation express-validator
  if (err.type === 'validation') {
    return res.status(422).json({
      success: false,
      error: 'Données invalides.',
      details: err.errors,
    });
  }

  // Erreur PostgreSQL
  if (err.code === '23505') {
    return res.status(409).json({
      success: false,
      error: 'Cette ressource existe déjà.',
    });
  }

  // Erreur JWT
  if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
    return res.status(401).json({
      success: false,
      error: 'Token invalide ou expiré.',
    });
  }

  // Erreur inconnue
  logger.error('Erreur non gérée', { err, path: req.path });
  res.status(500).json({
    success: false,
    error: process.env.NODE_ENV === 'production'
      ? 'Une erreur interne est survenue.'
      : err.message,
  });
}

export function notFoundHandler(req: Request, res: Response) {
  res.status(404).json({
    success: false,
    error: `Route introuvable : ${req.method} ${req.path}`,
  });
}
