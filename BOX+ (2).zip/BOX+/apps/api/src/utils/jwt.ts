import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { config } from '../config';

export interface AccessTokenPayload {
  sub: string;        // user ID
  email: string;
  role: string;
  type: 'access';
}

export interface RefreshTokenPayload {
  sub: string;
  jti: string;        // token unique ID (pour révocation)
  type: 'refresh';
}

/** Signer un access token (15 min) */
export function signAccessToken(payload: Omit<AccessTokenPayload, 'type'>): string {
  return jwt.sign(
    { ...payload, type: 'access' },
    config.jwt.accessSecret,
    { expiresIn: config.jwt.accessExpires, issuer: 'boxplus' }
  );
}

/** Signer un refresh token (30 jours) */
export function signRefreshToken(userId: string, jti: string): string {
  return jwt.sign(
    { sub: userId, jti, type: 'refresh' },
    config.jwt.refreshSecret,
    { expiresIn: config.jwt.refreshExpires, issuer: 'boxplus' }
  );
}

/** Vérifier un access token — lance une erreur si invalide */
export function verifyAccessToken(token: string): AccessTokenPayload {
  return jwt.verify(token, config.jwt.accessSecret, {
    issuer: 'boxplus',
  }) as AccessTokenPayload;
}

/** Vérifier un refresh token */
export function verifyRefreshToken(token: string): RefreshTokenPayload {
  return jwt.verify(token, config.jwt.refreshSecret, {
    issuer: 'boxplus',
  }) as RefreshTokenPayload;
}

/** Hasher un token pour le stocker en BDD (pas stocker en clair) */
export function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

/** Générer un token opaque sécurisé (reset password, vérif email) */
export function generateOpaqueToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString('hex');
}

/** Générer un UUID v4 */
export function generateUUID(): string {
  return crypto.randomUUID();
}
