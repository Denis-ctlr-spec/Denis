import { Router } from 'express';
import { body, query } from 'express-validator';
import { authController } from '../controllers/auth.controller';
import { authenticate } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate';

const router = Router();

// ── Règles de validation ──────────────────────────────────

const registerRules = [
  body('email').isEmail().normalizeEmail().withMessage('Email invalide.'),
  body('phone')
    .optional()
    .matches(/^\+?[0-9]{8,15}$/)
    .withMessage('Numéro de téléphone invalide.'),
  body('password')
    .isLength({ min: 8 })
    .withMessage('Le mot de passe doit contenir au moins 8 caractères.')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Le mot de passe doit contenir une majuscule, une minuscule et un chiffre.'),
  body('fullName')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Le nom doit contenir entre 2 et 100 caractères.'),
];

const loginRules = [
  body('email').isEmail().normalizeEmail().withMessage('Email invalide.'),
  body('password').notEmpty().withMessage('Mot de passe requis.'),
];

const forgotPasswordRules = [
  body('email').isEmail().normalizeEmail().withMessage('Email invalide.'),
];

const resetPasswordRules = [
  body('token').notEmpty().withMessage('Token requis.'),
  body('password')
    .isLength({ min: 8 })
    .withMessage('Le mot de passe doit contenir au moins 8 caractères.')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Le mot de passe doit contenir une majuscule, une minuscule et un chiffre.'),
];

// ── Routes ────────────────────────────────────────────────

/**
 * @route   POST /auth/register
 * @desc    Inscription
 * @access  Public
 */
router.post('/register', registerRules, validate, authController.register);

/**
 * @route   POST /auth/login
 * @desc    Connexion — retourne access token + pose cookie refresh
 * @access  Public
 */
router.post('/login', loginRules, validate, authController.login);

/**
 * @route   POST /auth/refresh
 * @desc    Rafraîchir l'access token via cookie refresh_token
 * @access  Public (cookie HttpOnly)
 */
router.post('/refresh', authController.refresh);

/**
 * @route   POST /auth/logout
 * @desc    Déconnexion + révocation refresh token
 * @access  Public
 */
router.post('/logout', authController.logout);

/**
 * @route   GET /auth/verify-email?token=xxx
 * @desc    Vérification email
 * @access  Public
 */
router.get('/verify-email', authController.verifyEmail);

/**
 * @route   POST /auth/forgot-password
 * @desc    Demande de réinitialisation mot de passe
 * @access  Public
 */
router.post('/forgot-password', forgotPasswordRules, validate, authController.forgotPassword);

/**
 * @route   POST /auth/reset-password
 * @desc    Réinitialisation du mot de passe avec token
 * @access  Public
 */
router.post('/reset-password', resetPasswordRules, validate, authController.resetPassword);

/**
 * @route   GET /auth/me
 * @desc    Profil de l'utilisateur connecté
 * @access  Privé
 */
router.get('/me', authenticate, authController.me);

export default router;
