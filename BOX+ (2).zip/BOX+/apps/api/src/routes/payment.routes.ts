import { Router } from 'express';
import { paymentController } from '../controllers/payment.controller';
import { authenticate } from '../middleware/auth.middleware';

const router = Router();

// Routes spectateur (authentifié)
router.post('/checkout', authenticate, paymentController.checkout);
router.get('/history', authenticate, paymentController.getHistory);
router.get('/:id/status', authenticate, paymentController.getStatus);

// Simulation Sandbox (Test dev)
router.post('/:id/simulate-sandbox', authenticate, paymentController.simulateSandbox);

// Webhook FedaPay (appelé par les serveurs de FedaPay avec signature HMAC)
router.post('/webhook', paymentController.webhook);

export default router;
