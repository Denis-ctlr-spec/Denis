import { Router } from 'express';
import { Request, Response, NextFunction } from 'express';
import { competitionService, teamService } from '../services/competitions.service';

const router = Router();

// ── Compétitions ──────────────────────────────────────────
router.get('/', async (_req, res, next) => {
  try {
    const competitions = await competitionService.listCompetitions(true);
    res.json({ success: true, competitions });
  } catch (err) { next(err); }
});

router.get('/:idOrSlug', async (req, res, next) => {
  try {
    const comp = await competitionService.getCompetition(req.params.idOrSlug);
    res.json({ success: true, competition: comp });
  } catch (err) { next(err); }
});

router.get('/:id/standings', async (req, res, next) => {
  try {
    const standings = await competitionService.getStandings(req.params.id, req.query.seasonId as string);
    res.json({ success: true, standings });
  } catch (err) { next(err); }
});

export const competitionRoutes = router;

// ── Équipes ───────────────────────────────────────────────
const teamRouter = Router();

teamRouter.get('/', async (req, res, next) => {
  try {
    const teams = await teamService.listTeams(req.query.competitionId as string);
    res.json({ success: true, teams });
  } catch (err) { next(err); }
});

teamRouter.get('/:id', async (req, res, next) => {
  try {
    const team = await teamService.getTeam(req.params.id);
    res.json({ success: true, team });
  } catch (err) { next(err); }
});

export const teamRoutes = teamRouter;
