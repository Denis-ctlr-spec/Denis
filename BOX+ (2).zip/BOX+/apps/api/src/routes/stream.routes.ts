import { Router } from 'express';
import { streamController } from '../controllers/stream.controller';
import { authenticate } from '../middleware/auth.middleware';

const router = Router();

// Routes protégées pour les spectateurs
router.post('/access', authenticate, streamController.getAccess);
router.post('/ping', authenticate, streamController.ping);
router.post('/leave', authenticate, streamController.leave);

// Route publique appelée par Nginx pour vérifier chaque requête de chunk HLS
router.get('/verify-token', streamController.verifySegmentAccess);

export const streamRoutes = router;

// Routes pour les webhooks SRS (appelées en interne par le conteneur SRS)
const webhookRouter = Router();
webhookRouter.post('/srs/on-publish', streamController.srsOnPublish);
webhookRouter.post('/srs/on-unpublish', streamController.srsOnUnpublish);

export const webhookRoutes = webhookRouter;
