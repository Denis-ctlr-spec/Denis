import { Router } from 'express';
import { adminController } from '../controllers/admin.controller';
import { authenticate, requireRole } from '../middleware/auth.middleware';

const router = Router();
router.use(authenticate, requireRole('admin', 'moderator', 'operator'));

// Dashboard
router.get('/dashboard', adminController.dashboard);

// Utilisateurs
router.get('/users', requireRole('admin', 'moderator'), adminController.listUsers);
router.patch('/users/:id/role', requireRole('admin'), adminController.setUserRole);
router.patch('/users/:id/active', requireRole('admin'), adminController.setUserActive);

// Plans d'abonnement
router.get('/plans', adminController.listPlans);
router.patch('/plans/:id', requireRole('admin'), adminController.updatePlan);

// Codes promo
router.get('/promo-codes', adminController.listPromoCodes);
router.post('/promo-codes', requireRole('admin'), adminController.createPromoCode);

// Paiements
router.get('/payments', adminController.listPayments);

// Abonnements
router.get('/subscriptions', adminController.listSubscriptions);

// Compétitions
router.get('/competitions', adminController.listCompetitions);
router.post('/competitions', requireRole('admin'), adminController.createCompetition);
router.patch('/competitions/:id', requireRole('admin'), adminController.updateCompetition);

// Équipes
router.get('/teams', adminController.listTeams);
router.post('/teams', requireRole('admin', 'moderator'), adminController.createTeam);
router.patch('/teams/:id', requireRole('admin', 'moderator'), adminController.updateTeam);

// Saisons
router.get('/seasons', adminController.listSeasons);
router.post('/seasons', requireRole('admin'), adminController.createSeason);

// Classements
router.get('/standings/:competitionId', adminController.getStandings);
router.post('/standings/:competitionId/recalculate', requireRole('admin'), adminController.recalculateStandings);

export default router;
