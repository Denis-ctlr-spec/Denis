import { Router } from 'express';
import { body, query } from 'express-validator';
import { matchController, adminMatchController } from '../controllers/matches.controller';
import { authenticate, requireRole, optionalAuth } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate';

const router = Router();

// ── Routes publiques ──────────────────────────────────────

/** GET /matches — liste des matchs */
router.get('/', matchController.list);

/** GET /matches/upcoming — prochains matchs */
router.get('/upcoming', matchController.upcoming);

/** GET /matches/replays — replays disponibles */
router.get('/replays', matchController.replays);

/** GET /matches/:id — détail d'un match */
router.get('/:id', optionalAuth, matchController.get);

// ── Routes admin ──────────────────────────────────────────

const adminRouter = Router();
adminRouter.use(authenticate, requireRole('admin', 'operator', 'moderator'));

const createMatchRules = [
  body('competitionId').isUUID(),
  body('homeTeamId').isUUID(),
  body('awayTeamId').isUUID(),
  body('scheduledAt').isISO8601(),
  body('matchday').optional().isInt({ min: 1 }),
];

adminRouter.post('/', createMatchRules, validate, adminMatchController.create);
adminRouter.patch('/:id', adminMatchController.update);
adminRouter.post('/:id/start-live', adminMatchController.startLive);
adminRouter.post('/:id/stop-live', adminMatchController.stopLive);
adminRouter.patch('/:id/score', [
  body('homeScore').isInt({ min: 0 }),
  body('awayScore').isInt({ min: 0 }),
  body('minute').optional().isInt({ min: 0, max: 120 }),
], validate, adminMatchController.updateScore);
adminRouter.post('/:id/events', adminMatchController.addEvent);
adminRouter.delete('/:id/events/:eventId', adminMatchController.deleteEvent);
adminRouter.post('/:id/regenerate-key', adminMatchController.regenerateKey);

export { router as matchRoutes, adminRouter as adminMatchRoutes };
