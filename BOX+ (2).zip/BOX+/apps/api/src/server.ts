import { createServer } from './app';
import { config } from './config';
import { connectDB } from './config/database';
import { connectRedis } from './config/redis';
import { logger } from './utils/logger';

async function bootstrap() {
  try {
    await connectDB();
    await connectRedis();

    const server = createServer();

    server.listen(config.server.port, () => {
      logger.info(`🚀 BOX+ API démarrée sur http://localhost:${config.server.port}`);
      logger.info(`   WebSocket : ws://localhost:${config.server.port}/ws`);
      logger.info(`   Environnement : ${config.env}`);
    });

    const shutdown = async (signal: string) => {
      logger.info(`Signal ${signal} reçu. Arrêt en cours...`);
      server.close(() => { logger.info('Serveur fermé.'); process.exit(0); });
      setTimeout(() => process.exit(1), 10_000);
    };

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT',  () => shutdown('SIGINT'));
    process.on('unhandledRejection', (r) => logger.error('Rejet non géré', r));

  } catch (err) {
    logger.error('Échec du démarrage', err);
    process.exit(1);
  }
}

bootstrap();
