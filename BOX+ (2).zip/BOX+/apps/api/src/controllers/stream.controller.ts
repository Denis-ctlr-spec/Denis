import { Request, Response, NextFunction } from 'express';
import { streamService } from '../services/stream.service';
import { logger } from '../utils/logger';

export const streamController = {

  /**
   * POST /stream/access
   * Demande d'accès au flux HLS sécurisé avec token HMAC
   */
  async getAccess(req: Request, res: Response, next: NextFunction) {
    try {
      const userId = (req as any).user.sub;
      const { matchId, deviceFingerprint } = req.body;

      if (!matchId || !deviceFingerprint) {
        return res.status(400).json({
          success: false,
          error: 'matchId et deviceFingerprint requis',
        });
      }

      const ipAddress = (req.headers['x-forwarded-for'] as string)?.split(',')[0] || req.ip;
      const userAgent = req.headers['user-agent'];

      const result = await streamService.getSecuredStreamUrl({
        userId,
        matchId,
        deviceFingerprint,
        ipAddress: ipAddress || undefined,
        userAgent,
      });

      res.json({
        success: true,
        ...result,
      });
    } catch (err) {
      next(err);
    }
  },

  /**
   * POST /stream/ping
   * Heartbeat envoyé toutes les 30s par le player
   */
  async ping(req: Request, res: Response, next: NextFunction) {
    try {
      const userId = (req as any).user.sub;
      const { matchId, deviceFingerprint } = req.body;

      if (matchId && deviceFingerprint) {
        await streamService.pingWatchSession(userId, matchId, deviceFingerprint);
      }

      res.json({ success: true, timestamp: Date.now() });
    } catch (err) {
      next(err);
    }
  },

  /**
   * POST /stream/leave
   * Fermeture immédiate de la session
   */
  async leave(req: Request, res: Response, next: NextFunction) {
    try {
      const userId = (req as any).user.sub;
      const { matchId, deviceFingerprint } = req.body;

      if (matchId && deviceFingerprint) {
        await streamService.closeWatchSession(userId, matchId, deviceFingerprint);
      }

      res.json({ success: true });
    } catch (err) {
      next(err);
    }
  },

  /**
   * GET /stream/verify-token
   * Utilisé par Nginx (auth_request) pour autoriser ou refuser l'accès aux segments HLS (.ts/.m3u8)
   */
  async verifySegmentAccess(req: Request, res: Response) {
    try {
      const token = req.query.token as string;
      const deviceFingerprint = req.query.dev as string;
      const streamName = req.query.stream as string;

      const ipAddress = (req.headers['x-forwarded-for'] as string)?.split(',')[0] || req.ip;

      const check = await streamService.validateStreamToken({
        token,
        deviceFingerprint,
        streamName,
        ipAddress: ipAddress || undefined,
      });

      if (check.valid) {
        return res.status(200).send('OK');
      }

      logger.warn(`Accès au segment HLS refusé : ${check.reason}`);
      return res.status(403).send(check.reason || 'Accès Refusé');
    } catch (err) {
      return res.status(403).send('Erreur d\'autorisation du flux');
    }
  },

  /**
   * POST /webhooks/srs/on-publish
   * Appelé par SRS quand OBS ou vMix tente d'envoyer un flux RTMP
   */
  async srsOnPublish(req: Request, res: Response) {
    try {
      const { stream, action } = req.body;
      logger.info(`Webhook SRS on_publish reçu pour stream: ${stream}, action: ${action}`);

      // stream correspond à la streamKey (ex: match_88a91c2b)
      const isAllowed = await streamService.authenticateRtmpPublish(stream);

      if (isAllowed) {
        // SRS attend le code HTTP 0 pour autoriser le flux
        return res.status(200).json({ code: 0, msg: 'Publishing autorise' });
      }

      // Rejet du flux RTMP
      return res.status(401).json({ code: 1, msg: 'Cle de stream invalide' });
    } catch (err) {
      logger.error('Erreur webhook SRS publish', err);
      return res.status(500).json({ code: 1, msg: 'Erreur interne' });
    }
  },

  /**
   * POST /webhooks/srs/on-unpublish
   * Appelé par SRS quand OBS coupe la diffusion
   */
  async srsOnUnpublish(req: Request, res: Response) {
    try {
      const { stream } = req.body;
      await streamService.onRtmpUnpublish(stream);
      return res.status(200).json({ code: 0, msg: 'Deconnexion traitee' });
    } catch (err) {
      return res.status(200).json({ code: 0 });
    }
  },
};
