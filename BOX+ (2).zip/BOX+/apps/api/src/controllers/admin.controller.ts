import { Request, Response, NextFunction } from 'express';
import { adminService } from '../services/admin.service';
import { competitionService, teamService, seasonService } from '../services/competitions.service';

export const adminController = {

  /** GET /admin/dashboard */
  async dashboard(req: Request, res: Response, next: NextFunction) {
    try {
      const [stats, chart] = await Promise.all([
        adminService.getDashboardStats(),
        adminService.getRevenueChart(),
      ]);
      res.json({ success: true, stats, revenueChart: chart });
    } catch (err) { next(err); }
  },

  /** GET /admin/users */
  async listUsers(req: Request, res: Response, next: NextFunction) {
    try {
      const result = await adminService.listUsers({
        search: req.query.search as string,
        role: req.query.role as string,
        limit: parseInt(req.query.limit as string) || 20,
        offset: parseInt(req.query.offset as string) || 0,
      });
      res.json({ success: true, ...result });
    } catch (err) { next(err); }
  },

  async setUserRole(req: Request, res: Response, next: NextFunction) {
    try {
      await adminService.setUserRole(req.params.id, req.body.role);
      res.json({ success: true });
    } catch (err) { next(err); }
  },

  async setUserActive(req: Request, res: Response, next: NextFunction) {
    try {
      await adminService.setUserActive(req.params.id, req.body.isActive);
      res.json({ success: true });
    } catch (err) { next(err); }
  },

  /** Plans */
  async listPlans(req: Request, res: Response, next: NextFunction) {
    try {
      const plans = await adminService.listPlans();
      res.json({ success: true, plans });
    } catch (err) { next(err); }
  },

  async updatePlan(req: Request, res: Response, next: NextFunction) {
    try {
      await adminService.updatePlan(req.params.id, req.body);
      res.json({ success: true });
    } catch (err) { next(err); }
  },

  /** Promo codes */
  async listPromoCodes(req: Request, res: Response, next: NextFunction) {
    try {
      const codes = await adminService.listPromoCodes();
      res.json({ success: true, codes });
    } catch (err) { next(err); }
  },

  async createPromoCode(req: Request, res: Response, next: NextFunction) {
    try {
      const id = await adminService.createPromoCode(req.body);
      res.status(201).json({ success: true, id });
    } catch (err) { next(err); }
  },

  /** Paiements */
  async listPayments(req: Request, res: Response, next: NextFunction) {
    try {
      const payments = await adminService.listPayments({
        status: req.query.status as string,
        limit: parseInt(req.query.limit as string) || 20,
        offset: parseInt(req.query.offset as string) || 0,
      });
      res.json({ success: true, payments });
    } catch (err) { next(err); }
  },

  /** Compétitions */
  async listCompetitions(req: Request, res: Response, next: NextFunction) {
    try {
      const comps = await competitionService.listCompetitions(false);
      res.json({ success: true, competitions: comps });
    } catch (err) { next(err); }
  },

  async createCompetition(req: Request, res: Response, next: NextFunction) {
    try {
      const id = await competitionService.createCompetition(req.body);
      res.status(201).json({ success: true, id });
    } catch (err) { next(err); }
  },

  async updateCompetition(req: Request, res: Response, next: NextFunction) {
    try {
      await competitionService.updateCompetition(req.params.id, req.body);
      res.json({ success: true });
    } catch (err) { next(err); }
  },

  /** Équipes */
  async listTeams(req: Request, res: Response, next: NextFunction) {
    try {
      const teams = await teamService.listTeams(req.query.competitionId as string);
      res.json({ success: true, teams });
    } catch (err) { next(err); }
  },

  async createTeam(req: Request, res: Response, next: NextFunction) {
    try {
      const id = await teamService.createTeam(req.body);
      res.status(201).json({ success: true, id });
    } catch (err) { next(err); }
  },

  async updateTeam(req: Request, res: Response, next: NextFunction) {
    try {
      await teamService.updateTeam(req.params.id, req.body);
      res.json({ success: true });
    } catch (err) { next(err); }
  },

  /** Saisons */
  async listSeasons(req: Request, res: Response, next: NextFunction) {
    try {
      const seasons = await seasonService.list();
      res.json({ success: true, seasons });
    } catch (err) { next(err); }
  },

  async createSeason(req: Request, res: Response, next: NextFunction) {
    try {
      const id = await seasonService.create(req.body);
      res.status(201).json({ success: true, id });
    } catch (err) { next(err); }
  },

  /** Classement */
  async getStandings(req: Request, res: Response, next: NextFunction) {
    try {
      const standings = await competitionService.getStandings(
        req.params.competitionId,
        req.query.seasonId as string,
      );
      res.json({ success: true, standings });
    } catch (err) { next(err); }
  },

  async recalculateStandings(req: Request, res: Response, next: NextFunction) {
    try {
      await competitionService.recalculateStandings(req.params.competitionId, req.body.seasonId);
      res.json({ success: true, message: 'Classement recalculé.' });
    } catch (err) { next(err); }
  },

  /** Abonnements */
  async listSubscriptions(req: Request, res: Response, next: NextFunction) {
    try {
      const subscriptions = await adminService.listSubscriptions({
        status: req.query.status as string,
        limit: parseInt(req.query.limit as string) || 20,
        offset: parseInt(req.query.offset as string) || 0,
      });
      res.json({ success: true, subscriptions });
    } catch (err) { next(err); }
  },
};
