import { Request, Response, NextFunction } from 'express';
import { authService } from '../services/auth.service';
import { AppError } from '../middleware/errorHandler';

// ── Helpers ───────────────────────────────────────────────

function setRefreshCookie(res: Response, token: string) {
  res.cookie('refresh_token', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 jours
    path: '/auth',
  });
}

function clearRefreshCookie(res: Response) {
  res.clearCookie('refresh_token', { path: '/auth' });
}

// ── Contrôleurs ───────────────────────────────────────────

export const authController = {

  /** POST /auth/register */
  async register(req: Request, res: Response, next: NextFunction) {
    try {
      const { email, phone, password, fullName } = req.body;
      const result = await authService.register({ email, phone, password, fullName });
      res.status(201).json({
        success: true,
        message: 'Compte créé. Vérifiez votre email pour l\'activer.',
        userId: result.userId,
      });
    } catch (err) {
      next(err);
    }
  },

  /** POST /auth/login */
  async login(req: Request, res: Response, next: NextFunction) {
    try {
      const { email, password, deviceFingerprint } = req.body;
      const ipAddress = (req.headers['x-forwarded-for'] as string)?.split(',')[0] || req.ip;
      const userAgent = req.headers['user-agent'];

      const result = await authService.login({
        email, password, deviceFingerprint,
        ipAddress: ipAddress || undefined,
        userAgent,
      });

      setRefreshCookie(res, result.refreshToken);

      res.json({
        success: true,
        accessToken: result.accessToken,
        expiresIn: result.expiresIn,
        user: result.user,
      });
    } catch (err) {
      next(err);
    }
  },

  /** POST /auth/refresh */
  async refresh(req: Request, res: Response, next: NextFunction) {
    try {
      const rawToken = req.cookies?.refresh_token || req.body?.refreshToken;
      if (!rawToken) throw new AppError('Token de rafraîchissement manquant.', 401);

      const tokens = await authService.refreshTokens(rawToken);
      setRefreshCookie(res, tokens.refreshToken);

      res.json({
        success: true,
        accessToken: tokens.accessToken,
        expiresIn: tokens.expiresIn,
      });
    } catch (err) {
      next(err);
    }
  },

  /** POST /auth/logout */
  async logout(req: Request, res: Response, next: NextFunction) {
    try {
      const rawToken = req.cookies?.refresh_token || req.body?.refreshToken;
      if (rawToken) await authService.logout(rawToken);
      clearRefreshCookie(res);
      res.json({ success: true, message: 'Déconnecté avec succès.' });
    } catch (err) {
      next(err);
    }
  },

  /** GET /auth/verify-email?token=xxx */
  async verifyEmail(req: Request, res: Response, next: NextFunction) {
    try {
      const { token } = req.query;
      if (!token || typeof token !== 'string') throw new AppError('Token manquant.', 400);
      await authService.verifyEmail(token);
      res.json({ success: true, message: 'Email vérifié avec succès.' });
    } catch (err) {
      next(err);
    }
  },

  /** POST /auth/forgot-password */
  async forgotPassword(req: Request, res: Response, next: NextFunction) {
    try {
      const { email } = req.body;
      await authService.forgotPassword(email);
      res.json({
        success: true,
        message: 'Si cet email est enregistré, vous recevrez un lien de réinitialisation.',
      });
    } catch (err) {
      next(err);
    }
  },

  /** POST /auth/reset-password */
  async resetPassword(req: Request, res: Response, next: NextFunction) {
    try {
      const { token, password } = req.body;
      if (!token) throw new AppError('Token manquant.', 400);
      await authService.resetPassword(token, password);
      res.json({ success: true, message: 'Mot de passe réinitialisé avec succès.' });
    } catch (err) {
      next(err);
    }
  },

  /** GET /auth/me */
  async me(req: Request, res: Response, next: NextFunction) {
    try {
      const userId = (req as any).user.sub;
      const profile = await authService.getProfile(userId);
      res.json({ success: true, user: profile });
    } catch (err) {
      next(err);
    }
  },
};
