import { Request, Response, NextFunction } from 'express';
import { paymentService } from '../services/payment.service';

export const paymentController = {

  /**
   * POST /payments/checkout
   * Initie une transaction Mobile Money (T-Money, Flooz) ou Carte
   */
  async checkout(req: Request, res: Response, next: NextFunction) {
    try {
      const userId = (req as any).user.sub;
      const { planId, paymentMethod, phoneNumber, matchId, promoCode } = req.body;

      if (!planId || !paymentMethod) {
        return res.status(400).json({
          success: false,
          error: 'planId et paymentMethod sont obligatoires.',
        });
      }

      const result = await paymentService.initializePayment({
        userId,
        planId,
        paymentMethod,
        phoneNumber,
        matchId,
        promoCode,
      });

      res.status(201).json({
        success: true,
        ...result,
      });
    } catch (err) {
      next(err);
    }
  },

  /**
   * GET /payments/:id/status
   * Vérifier l'état de la transaction (Pending, Approved, Declined)
   */
  async getStatus(req: Request, res: Response, next: NextFunction) {
    try {
      const payment = await paymentService.getPaymentStatus(req.params.id);
      res.json({
        success: true,
        payment,
      });
    } catch (err) {
      next(err);
    }
  },

  /**
   * POST /payments/webhook
   * Webhook FedaPay sécurisé par signature HMAC
   */
  async webhook(req: Request, res: Response, next: NextFunction) {
    try {
      const signature = req.headers['x-fedapay-signature'] as string;
      const rawBody = (req as any).rawBody || JSON.stringify(req.body);

      await paymentService.handleWebhook(rawBody, signature, req.body);

      // FedaPay attend un HTTP 200 pour considérer le webhook comme livré
      res.status(200).json({ received: true });
    } catch (err) {
      next(err);
    }
  },

  /**
   * POST /payments/:id/simulate-sandbox
   * Démonstration / Test : Valide instantanément le paiement sans attendre USSD
   */
  async simulateSandbox(req: Request, res: Response, next: NextFunction) {
    try {
      await paymentService.simulateSandboxApproval(req.params.id);
      res.json({
        success: true,
        message: 'Paiement sandbox validé. Abonnement activé !',
      });
    } catch (err) {
      next(err);
    }
  },

  /**
   * GET /payments/history
   * Historique personnel des factures et abonnements
   */
  async getHistory(req: Request, res: Response, next: NextFunction) {
    try {
      const userId = (req as any).user.sub;
      const history = await paymentService.getUserBillingHistory(userId);
      res.json({
        success: true,
        ...history,
      });
    } catch (err) {
      next(err);
    }
  },
};
