import { Request, Response, NextFunction } from 'express';
import { matchService } from '../services/matches.service';
import { broadcastMatchUpdate, broadcastMatchEvent, getLiveViewerCount } from '../websocket';

export const matchController = {

  /** GET /matches */
  async list(req: Request, res: Response, next: NextFunction) {
    try {
      const { status, competitionId, seasonId, limit, offset, featured } = req.query;
      const result = await matchService.listMatches({
        status: status as string,
        competitionId: competitionId as string,
        seasonId: seasonId as string,
        limit: limit ? parseInt(limit as string) : undefined,
        offset: offset ? parseInt(offset as string) : undefined,
        featured: featured === 'true',
      });
      res.json({ success: true, ...result });
    } catch (err) { next(err); }
  },

  /** GET /matches/:id */
  async get(req: Request, res: Response, next: NextFunction) {
    try {
      const match = await matchService.getMatch(req.params.id);
      const viewerCount = match.status === 'live' ? getLiveViewerCount(req.params.id) : 0;
      res.json({ success: true, match: { ...match, viewerCount } });
    } catch (err) { next(err); }
  },

  /** GET /matches/upcoming */
  async upcoming(req: Request, res: Response, next: NextFunction) {
    try {
      const matches = await matchService.getUpcoming(parseInt(req.query.limit as string) || 5);
      res.json({ success: true, matches });
    } catch (err) { next(err); }
  },

  /** GET /matches/replays */
  async replays(req: Request, res: Response, next: NextFunction) {
    try {
      const matches = await matchService.getReplays(
        parseInt(req.query.limit as string) || 12,
        parseInt(req.query.offset as string) || 0,
      );
      res.json({ success: true, matches });
    } catch (err) { next(err); }
  },
};

export const adminMatchController = {

  /** POST /admin/matches */
  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const id = await matchService.createMatch(req.body);
      res.status(201).json({ success: true, id });
    } catch (err) { next(err); }
  },

  /** PATCH /admin/matches/:id */
  async update(req: Request, res: Response, next: NextFunction) {
    try {
      await matchService.updateMatch(req.params.id, req.body);
      res.json({ success: true });
    } catch (err) { next(err); }
  },

  /** POST /admin/matches/:id/start-live */
  async startLive(req: Request, res: Response, next: NextFunction) {
    try {
      await matchService.startLive(req.params.id);
      broadcastMatchUpdate(req.params.id, { status: 'live', startedAt: new Date() });
      res.json({ success: true, message: 'Direct démarré.' });
    } catch (err) { next(err); }
  },

  /** POST /admin/matches/:id/stop-live */
  async stopLive(req: Request, res: Response, next: NextFunction) {
    try {
      await matchService.stopLive(req.params.id);
      broadcastMatchUpdate(req.params.id, { status: 'finished', endedAt: new Date() });
      res.json({ success: true, message: 'Direct arrêté.' });
    } catch (err) { next(err); }
  },

  /** PATCH /admin/matches/:id/score */
  async updateScore(req: Request, res: Response, next: NextFunction) {
    try {
      const { homeScore, awayScore, minute } = req.body;
      await matchService.updateScore(req.params.id, { homeScore, awayScore, minute });
      // Diffuser en temps réel à tous les spectateurs
      broadcastMatchUpdate(req.params.id, {
        score: { home: homeScore, away: awayScore },
        minute,
      });
      res.json({ success: true });
    } catch (err) { next(err); }
  },

  /** POST /admin/matches/:id/events */
  async addEvent(req: Request, res: Response, next: NextFunction) {
    try {
      const event = await matchService.addEvent(req.params.id, req.body);
      broadcastMatchEvent(req.params.id, event);
      res.status(201).json({ success: true, event });
    } catch (err) { next(err); }
  },

  /** DELETE /admin/matches/:id/events/:eventId */
  async deleteEvent(req: Request, res: Response, next: NextFunction) {
    try {
      await matchService.deleteEvent(req.params.eventId);
      broadcastMatchUpdate(req.params.id, { type: 'event_deleted', eventId: req.params.eventId });
      res.json({ success: true });
    } catch (err) { next(err); }
  },

  /** POST /admin/matches/:id/regenerate-key */
  async regenerateKey(req: Request, res: Response, next: NextFunction) {
    try {
      const key = await matchService.regenerateStreamKey(req.params.id);
      res.json({ success: true, streamKey: key });
    } catch (err) { next(err); }
  },
};
