import { Server as HttpServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { verifyAccessToken } from '../utils/jwt';
import { logger } from '../utils/logger';

interface Client {
  ws: WebSocket;
  userId?: string;
  subscriptions: Set<string>; // matchIds suivis
}

const clients = new Map<WebSocket, Client>();

export function setupWebSocket(server: HttpServer) {
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws, req) => {
    const client: Client = { ws, subscriptions: new Set() };
    clients.set(ws, client);

    // Authentification optionnelle via query param
    const url = new URL(req.url || '/', `http://localhost`);
    const token = url.searchParams.get('token');
    if (token) {
      try {
        const payload = verifyAccessToken(token);
        client.userId = payload.sub;
      } catch {}
    }

    logger.debug(`WS: nouveau client connecté (total: ${clients.size})`);

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        handleMessage(client, msg);
      } catch {}
    });

    ws.on('close', () => {
      clients.delete(ws);
      logger.debug(`WS: client déconnecté (total: ${clients.size})`);
    });

    ws.on('error', (err) => logger.error('WS erreur client', err));

    // Ping keepalive
    ws.send(JSON.stringify({ type: 'connected', message: 'BOX+ WebSocket' }));
  });

  // Ping périodique pour maintenir les connexions
  setInterval(() => {
    wss.clients.forEach((ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.ping();
      }
    });
  }, 30_000);

  logger.info('WebSocket initialisé sur /ws');
  return wss;
}

function handleMessage(client: Client, msg: any) {
  switch (msg.type) {
    case 'subscribe':
      // Le client veut suivre les mises à jour d'un match
      if (msg.matchId) client.subscriptions.add(msg.matchId);
      break;
    case 'unsubscribe':
      if (msg.matchId) client.subscriptions.delete(msg.matchId);
      break;
    case 'ping':
      client.ws.send(JSON.stringify({ type: 'pong' }));
      break;
  }
}

/** Diffuser une mise à jour de match à tous les clients abonnés */
export function broadcastMatchUpdate(matchId: string, payload: object) {
  const message = JSON.stringify({ type: 'match_update', matchId, ...payload });

  for (const [, client] of clients) {
    if (client.subscriptions.has(matchId) && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(message);
    }
  }
}

/** Diffuser un événement match (but, carton, etc.) */
export function broadcastMatchEvent(matchId: string, event: object) {
  const message = JSON.stringify({ type: 'match_event', matchId, event });

  for (const [, client] of clients) {
    if (client.subscriptions.has(matchId) && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(message);
    }
  }
}

/** Nombre de spectateurs actifs sur un match */
export function getLiveViewerCount(matchId: string): number {
  let count = 0;
  for (const [, client] of clients) {
    if (client.subscriptions.has(matchId)) count++;
  }
  return count;
}
