import dotenv from 'dotenv';
import path from 'path';

// Charger .env depuis la racine du monorepo
dotenv.config({ path: path.resolve(__dirname, '../../../.env') });

function required(key: string): string {
  const val = process.env[key];
  if (!val) throw new Error(`Variable d'environnement manquante : ${key}`);
  return val;
}

function optional(key: string, defaultValue: string): string {
  return process.env[key] || defaultValue;
}

export const config = {
  env: optional('NODE_ENV', 'development'),
  isDev: optional('NODE_ENV', 'development') === 'development',

  server: {
    port: parseInt(optional('API_PORT', '4000'), 10),
    apiUrl: optional('API_URL', 'http://localhost:4000'),
    webUrl: optional('WEB_URL', 'http://localhost:3000'),
    corsOrigins: optional('CORS_ORIGINS', 'http://localhost:3000').split(','),
  },

  db: {
    url: required('DATABASE_URL'),
    ssl: optional('NODE_ENV', 'development') === 'production',
  },

  redis: {
    url: optional('REDIS_URL', 'redis://localhost:6379'),
  },

  jwt: {
    accessSecret: required('JWT_ACCESS_SECRET'),
    refreshSecret: required('JWT_REFRESH_SECRET'),
    accessExpires: optional('JWT_ACCESS_EXPIRES', '15m'),
    refreshExpires: optional('JWT_REFRESH_EXPIRES', '30d'),
  },

  email: {
    host: optional('SMTP_HOST', 'smtp-relay.brevo.com'),
    port: parseInt(optional('SMTP_PORT', '587'), 10),
    user: optional('SMTP_USER', ''),
    pass: optional('SMTP_PASS', ''),
    from: optional('EMAIL_FROM', 'BOX+ <noreply@boxplus.tg>'),
  },

  fedapay: {
    secretKey: optional('FEDAPAY_SECRET_KEY', ''),
    publicKey: optional('FEDAPAY_PUBLIC_KEY', ''),
    webhookSecret: optional('FEDAPAY_WEBHOOK_SECRET', ''),
    env: optional('FEDAPAY_ENV', 'sandbox') as 'sandbox' | 'live',
  },

  minio: {
    endpoint: optional('MINIO_ENDPOINT', 'localhost'),
    port: parseInt(optional('MINIO_PORT', '9000'), 10),
    accessKey: optional('MINIO_ACCESS_KEY', 'minioadmin'),
    secretKey: optional('MINIO_SECRET_KEY', 'minioadmin123'),
    useSSL: optional('MINIO_USE_SSL', 'false') === 'true',
    bucketReplays: optional('MINIO_BUCKET_REPLAYS', 'replays'),
    bucketThumbnails: optional('MINIO_BUCKET_THUMBNAILS', 'thumbnails'),
  },

  stream: {
    tokenSecret: required('STREAM_TOKEN_SECRET'),
    tokenExpires: parseInt(optional('STREAM_TOKEN_EXPIRES', '3600'), 10),
    srsApiUrl: optional('SRS_API_URL', 'http://srs:1985'),
  },
};
