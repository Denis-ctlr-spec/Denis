import Redis from 'ioredis';
import { config } from '../config';
import { logger } from '../utils/logger';

export const redis = new Redis(config.redis.url, {
  maxRetriesPerRequest: 3,
  retryStrategy: (times) => Math.min(times * 50, 2000),
  lazyConnect: true,
});

redis.on('connect', () => logger.info('Redis connecté'));
redis.on('error', (err) => logger.error('Erreur Redis', err));

export async function connectRedis(): Promise<void> {
  await redis.connect();
}

// ── Helpers ───────────────────────────────────────────────

/** Stocker avec TTL en secondes */
export const redisSet = (key: string, value: string, ttl?: number) =>
  ttl ? redis.setex(key, ttl, value) : redis.set(key, value);

/** Rate-limit : compter les tentatives */
export async function checkRateLimit(
  key: string,
  max: number,
  windowSecs: number
): Promise<{ allowed: boolean; remaining: number }> {
  const current = await redis.incr(key);
  if (current === 1) await redis.expire(key, windowSecs);
  return { allowed: current <= max, remaining: Math.max(0, max - current) };
}

/** Blacklister un token de refresh révoqué */
export const blacklistToken = (tokenHash: string, ttlSecs: number) =>
  redis.setex(`blacklist:${tokenHash}`, ttlSecs, '1');

export const isTokenBlacklisted = async (tokenHash: string): Promise<boolean> =>
  (await redis.exists(`blacklist:${tokenHash}`)) === 1;

/** Sessions de visionnage actives par utilisateur */
export const setWatchSession = (userId: string, matchId: string, deviceFp: string, ttl = 60) =>
  redis.setex(`watch:${userId}:${matchId}:${deviceFp}`, ttl, Date.now().toString());

export const countWatchSessions = async (userId: string, matchId: string): Promise<number> => {
  const keys = await redis.keys(`watch:${userId}:${matchId}:*`);
  return keys.length;
};
