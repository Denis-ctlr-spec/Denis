import bcrypt from 'bcryptjs';
import { db } from '../config/database';
import { redis, checkRateLimit, blacklistToken, isTokenBlacklisted } from '../config/redis';
import {
  signAccessToken, signRefreshToken, verifyRefreshToken,
  hashToken, generateOpaqueToken, generateUUID
} from '../utils/jwt';
import { emailService } from './email.service';
import { config } from '../config';
import { logger } from '../utils/logger';
import { AppError } from '../middleware/errorHandler';

const BCRYPT_ROUNDS = 12;

// ── Types ─────────────────────────────────────────────────

export interface RegisterInput {
  email: string;
  phone?: string;
  password: string;
  fullName: string;
}

export interface LoginInput {
  email: string;
  password: string;
  deviceFingerprint?: string;
  ipAddress?: string;
  userAgent?: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

// ── Service ───────────────────────────────────────────────

export const authService = {

  /** ── Inscription ───────────────────────────────────── */
  async register(input: RegisterInput): Promise<{ userId: string }> {
    const { email, phone, password, fullName } = input;

    // Vérifier unicité email
    const existing = await db.query(
      'SELECT id FROM users WHERE email = $1 OR ($2::text IS NOT NULL AND phone = $2)',
      [email.toLowerCase(), phone || null]
    );
    if (existing.rows.length > 0) {
      throw new AppError('Un compte avec cet email ou ce téléphone existe déjà.', 409);
    }

    // Hash mot de passe
    const passwordHash = await bcrypt.hash(password, BCRYPT_ROUNDS);

    // Créer l'utilisateur
    const userResult = await db.query(
      `INSERT INTO users (email, phone, password_hash, full_name)
       VALUES ($1, $2, $3, $4) RETURNING id, email, full_name`,
      [email.toLowerCase(), phone || null, passwordHash, fullName]
    );
    const user = userResult.rows[0];

    // Générer token de vérification email (24h)
    const verifyToken = generateOpaqueToken();
    await db.query(
      `INSERT INTO verification_tokens (user_id, token, type, expires_at)
       VALUES ($1, $2, 'email_verify', NOW() + INTERVAL '24 hours')`,
      [user.id, verifyToken]
    );

    // Envoyer email de vérification
    const verifyUrl = `${config.server.webUrl}/verify-email?token=${verifyToken}`;
    try {
      await emailService.sendVerificationEmail(user.email, user.full_name, verifyUrl);
    } catch (err) {
      logger.warn(`Email de vérification non envoyé pour ${user.email}`, err);
    }

    logger.info(`Nouvel utilisateur enregistré : ${user.email}`);
    return { userId: user.id };
  },

  /** ── Vérification email ────────────────────────────── */
  async verifyEmail(token: string): Promise<void> {
    const result = await db.query(
      `SELECT vt.user_id, vt.expires_at, vt.used_at
       FROM verification_tokens vt
       WHERE vt.token = $1 AND vt.type = 'email_verify'`,
      [token]
    );

    if (result.rows.length === 0) throw new AppError('Lien de vérification invalide.', 400);

    const { user_id, expires_at, used_at } = result.rows[0];
    if (used_at) throw new AppError('Ce lien a déjà été utilisé.', 400);
    if (new Date(expires_at) < new Date()) throw new AppError('Lien expiré. Demandez-en un nouveau.', 400);

    await db.transaction(async (client) => {
      await client.query('UPDATE users SET email_verified = TRUE WHERE id = $1', [user_id]);
      await client.query(
        'UPDATE verification_tokens SET used_at = NOW() WHERE token = $1',
        [token]
      );
    });

    logger.info(`Email vérifié pour user ${user_id}`);
  },

  /** ── Connexion ─────────────────────────────────────── */
  async login(input: LoginInput): Promise<AuthTokens & { user: any }> {
    const { email, password, deviceFingerprint, ipAddress, userAgent } = input;

    // Rate limit par email (5 tentatives / 15 min)
    const rlKey = `auth:login:${email.toLowerCase()}`;
    const { allowed } = await checkRateLimit(rlKey, 5, 900);
    if (!allowed) {
      throw new AppError('Trop de tentatives de connexion. Réessayez dans 15 minutes.', 429);
    }

    // Trouver l'utilisateur
    const result = await db.query(
      'SELECT id, email, password_hash, full_name, role, is_active, email_verified FROM users WHERE email = $1',
      [email.toLowerCase()]
    );

    if (result.rows.length === 0) {
      // Délai constant pour éviter timing attacks
      await bcrypt.hash('dummy', BCRYPT_ROUNDS);
      throw new AppError('Email ou mot de passe incorrect.', 401);
    }

    const user = result.rows[0];

    if (!user.is_active) throw new AppError('Ce compte est désactivé. Contactez le support.', 403);

    const passwordValid = await bcrypt.compare(password, user.password_hash);
    if (!passwordValid) throw new AppError('Email ou mot de passe incorrect.', 401);

    // Réinitialiser rate limit après succès
    await redis.del(rlKey);

    // Générer tokens
    const jti = generateUUID();
    const accessToken = signAccessToken({ sub: user.id, email: user.email, role: user.role });
    const refreshToken = signRefreshToken(user.id, jti);
    const refreshHash = hashToken(refreshToken);

    // Stocker refresh token en BDD
    await db.query(
      `INSERT INTO refresh_tokens (user_id, token_hash, device_fingerprint, user_agent, ip_address, expires_at)
       VALUES ($1, $2, $3, $4, $5::inet, NOW() + INTERVAL '30 days')`,
      [user.id, refreshHash, deviceFingerprint || null, userAgent || null, ipAddress || null]
    );

    // Mise à jour last_login
    await db.query('UPDATE users SET last_login_at = NOW() WHERE id = $1', [user.id]);

    const { password_hash: _, ...safeUser } = user;
    return {
      accessToken,
      refreshToken,
      expiresIn: 15 * 60,
      user: safeUser,
    };
  },

  /** ── Refresh Token ─────────────────────────────────── */
  async refreshTokens(rawRefreshToken: string): Promise<AuthTokens> {
    let payload: ReturnType<typeof verifyRefreshToken>;
    try {
      payload = verifyRefreshToken(rawRefreshToken);
    } catch {
      throw new AppError('Token de rafraîchissement invalide ou expiré.', 401);
    }

    const tokenHash = hashToken(rawRefreshToken);

    // Vérifier blacklist
    if (await isTokenBlacklisted(tokenHash)) {
      throw new AppError('Token révoqué.', 401);
    }

    // Vérifier en BDD
    const result = await db.query(
      `SELECT rt.id, u.id as user_id, u.email, u.role, u.is_active
       FROM refresh_tokens rt
       JOIN users u ON u.id = rt.user_id
       WHERE rt.token_hash = $1 AND rt.expires_at > NOW()`,
      [tokenHash]
    );

    if (result.rows.length === 0) throw new AppError('Token invalide.', 401);

    const { id: tokenId, user_id, email, role, is_active } = result.rows[0];
    if (!is_active) throw new AppError('Compte désactivé.', 403);

    // Rotation : invalider l'ancien token
    await db.query('DELETE FROM refresh_tokens WHERE id = $1', [tokenId]);
    // Blacklister pour la durée restante (sécurité anti-rejeu)
    await blacklistToken(tokenHash, 30 * 24 * 3600);

    // Générer nouveaux tokens
    const jti = generateUUID();
    const newAccessToken = signAccessToken({ sub: user_id, email, role });
    const newRefreshToken = signRefreshToken(user_id, jti);
    const newRefreshHash = hashToken(newRefreshToken);

    await db.query(
      `INSERT INTO refresh_tokens (user_id, token_hash, expires_at)
       VALUES ($1, $2, NOW() + INTERVAL '30 days')`,
      [user_id, newRefreshHash]
    );

    return { accessToken: newAccessToken, refreshToken: newRefreshToken, expiresIn: 15 * 60 };
  },

  /** ── Déconnexion ───────────────────────────────────── */
  async logout(rawRefreshToken: string): Promise<void> {
    const tokenHash = hashToken(rawRefreshToken);
    await db.query('DELETE FROM refresh_tokens WHERE token_hash = $1', [tokenHash]);
    await blacklistToken(tokenHash, 30 * 24 * 3600);
  },

  /** ── Mot de passe oublié ───────────────────────────── */
  async forgotPassword(email: string): Promise<void> {
    const result = await db.query(
      'SELECT id, full_name FROM users WHERE email = $1 AND is_active = TRUE',
      [email.toLowerCase()]
    );

    // Toujours répondre 200 (ne pas divulguer si l'email existe)
    if (result.rows.length === 0) return;

    const user = result.rows[0];
    const resetToken = generateOpaqueToken();

    // Invalider les anciens tokens de reset
    await db.query(
      `UPDATE verification_tokens SET used_at = NOW()
       WHERE user_id = $1 AND type = 'password_reset' AND used_at IS NULL`,
      [user.id]
    );

    await db.query(
      `INSERT INTO verification_tokens (user_id, token, type, expires_at)
       VALUES ($1, $2, 'password_reset', NOW() + INTERVAL '1 hour')`,
      [user.id, resetToken]
    );

    const resetUrl = `${config.server.webUrl}/reset-password?token=${resetToken}`;
    await emailService.sendPasswordReset(email, user.full_name, resetUrl);
  },

  /** ── Réinitialisation mot de passe ────────────────── */
  async resetPassword(token: string, newPassword: string): Promise<void> {
    const result = await db.query(
      `SELECT user_id, expires_at, used_at
       FROM verification_tokens
       WHERE token = $1 AND type = 'password_reset'`,
      [token]
    );

    if (result.rows.length === 0) throw new AppError('Lien invalide ou expiré.', 400);

    const { user_id, expires_at, used_at } = result.rows[0];
    if (used_at) throw new AppError('Ce lien a déjà été utilisé.', 400);
    if (new Date(expires_at) < new Date()) throw new AppError('Lien expiré.', 400);

    const passwordHash = await bcrypt.hash(newPassword, BCRYPT_ROUNDS);

    await db.transaction(async (client) => {
      await client.query('UPDATE users SET password_hash = $1 WHERE id = $2', [passwordHash, user_id]);
      await client.query(
        'UPDATE verification_tokens SET used_at = NOW() WHERE token = $1',
        [token]
      );
      // Révoquer tous les refresh tokens (sécurité)
      await client.query('DELETE FROM refresh_tokens WHERE user_id = $1', [user_id]);
    });

    logger.info(`Mot de passe réinitialisé pour user ${user_id}`);
  },

  /** ── Profil utilisateur ────────────────────────────── */
  async getProfile(userId: string) {
    const result = await db.query(
      `SELECT u.id, u.email, u.phone, u.full_name, u.avatar_url, u.role,
              u.email_verified, u.created_at,
              s.status as sub_status, sp.name as sub_plan, s.expires_at as sub_expires
       FROM users u
       LEFT JOIN subscriptions s ON s.user_id = u.id AND s.status = 'active'
         AND s.expires_at > NOW()
       LEFT JOIN subscription_plans sp ON sp.id = s.plan_id
       WHERE u.id = $1`,
      [userId]
    );

    if (result.rows.length === 0) throw new AppError('Utilisateur introuvable.', 404);
    return result.rows[0];
  },
};
