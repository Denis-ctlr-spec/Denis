import { db } from '../config/database';
import { AppError } from '../middleware/errorHandler';
import crypto from 'crypto';

// ── Types ─────────────────────────────────────────────────

export interface CreateMatchInput {
  competitionId: string;
  seasonId?: string;
  homeTeamId: string;
  awayTeamId: string;
  scheduledAt: string;
  matchday?: number;
  isFree?: boolean;
  isFeatured?: boolean;
  thumbnailUrl?: string;
}

export interface UpdateScoreInput {
  homeScore: number;
  awayScore: number;
  minute?: number;
}

export interface AddEventInput {
  type: string;
  minute: number;
  extraTime?: number;
  playerName?: string;
  teamId?: string;
  description?: string;
}

// ── Service Matchs ────────────────────────────────────────

export const matchService = {

  /** Liste des matchs (public) avec filtres */
  async listMatches(opts: {
    status?: string;
    competitionId?: string;
    seasonId?: string;
    limit?: number;
    offset?: number;
    featured?: boolean;
  }) {
    const conditions: string[] = [];
    const params: any[] = [];
    let i = 1;

    if (opts.status) { conditions.push(`m.status = $${i++}`); params.push(opts.status); }
    if (opts.competitionId) { conditions.push(`m.competition_id = $${i++}`); params.push(opts.competitionId); }
    if (opts.seasonId) { conditions.push(`m.season_id = $${i++}`); params.push(opts.seasonId); }
    if (opts.featured) { conditions.push(`m.is_featured = TRUE`); }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const limit = Math.min(opts.limit || 20, 100);
    const offset = opts.offset || 0;

    const sql = `
      SELECT
        m.id, m.scheduled_at, m.status, m.home_score, m.away_score,
        m.minute, m.is_free, m.is_featured, m.thumbnail_url,
        m.started_at, m.ended_at, m.matchday,
        ht.id AS home_id, ht.name AS home_name, ht.short_name AS home_short, ht.logo_url AS home_logo,
        at.id AS away_id, at.name AS away_name, at.short_name AS away_short, at.logo_url AS away_logo,
        c.id AS comp_id, c.name AS comp_name, c.logo_url AS comp_logo,
        s.name AS season_name
      FROM matches m
      JOIN teams ht ON ht.id = m.home_team_id
      JOIN teams at ON at.id = m.away_team_id
      JOIN competitions c ON c.id = m.competition_id
      LEFT JOIN seasons s ON s.id = m.season_id
      ${where}
      ORDER BY
        CASE m.status WHEN 'live' THEN 0 WHEN 'scheduled' THEN 1 ELSE 2 END,
        m.scheduled_at ASC
      LIMIT $${i++} OFFSET $${i++}
    `;
    params.push(limit, offset);

    const countSql = `SELECT COUNT(*) FROM matches m ${where}`;
    const [rows, countResult] = await Promise.all([
      db.query(sql, params),
      db.query(countSql, params.slice(0, -2)),
    ]);

    return {
      matches: rows.rows.map(formatMatch),
      total: parseInt(countResult.rows[0].count, 10),
      limit,
      offset,
    };
  },

  /** Détail d'un match */
  async getMatch(id: string) {
    const result = await db.query(`
      SELECT
        m.*,
        ht.id AS home_id, ht.name AS home_name, ht.short_name AS home_short,
        ht.logo_url AS home_logo, ht.city AS home_city,
        at.id AS away_id, at.name AS away_name, at.short_name AS away_short,
        at.logo_url AS away_logo, at.city AS away_city,
        c.id AS comp_id, c.name AS comp_name, c.logo_url AS comp_logo, c.format AS comp_format,
        s.name AS season_name, s.year_start, s.year_end
      FROM matches m
      JOIN teams ht ON ht.id = m.home_team_id
      JOIN teams at ON at.id = m.away_team_id
      JOIN competitions c ON c.id = m.competition_id
      LEFT JOIN seasons s ON s.id = m.season_id
      WHERE m.id = $1
    `, [id]);

    if (!result.rows.length) throw new AppError('Match introuvable.', 404);

    const match = result.rows[0];

    // Événements du match
    const eventsResult = await db.query(`
      SELECT me.*, t.name AS team_name, t.logo_url AS team_logo
      FROM match_events me
      LEFT JOIN teams t ON t.id = me.team_id
      WHERE me.match_id = $1
      ORDER BY me.minute ASC, me.created_at ASC
    `, [id]);

    return { ...formatMatch(match), events: eventsResult.rows };
  },

  /** Créer un match */
  async createMatch(data: CreateMatchInput): Promise<string> {
    const streamKey = `match_${crypto.randomBytes(8).toString('hex')}`;

    const result = await db.query(`
      INSERT INTO matches
        (competition_id, season_id, home_team_id, away_team_id, scheduled_at,
         matchday, is_free, is_featured, thumbnail_url, stream_key)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
      RETURNING id
    `, [
      data.competitionId,
      data.seasonId || null,
      data.homeTeamId,
      data.awayTeamId,
      data.scheduledAt,
      data.matchday || null,
      data.isFree ?? false,
      data.isFeatured ?? false,
      data.thumbnailUrl || null,
      streamKey,
    ]);

    return result.rows[0].id;
  },

  /** Mettre à jour un match */
  async updateMatch(id: string, data: Partial<CreateMatchInput & { status: string }>) {
    const fields: string[] = [];
    const params: any[] = [];
    let i = 1;

    const allowed = ['competition_id','season_id','home_team_id','away_team_id',
      'scheduled_at','matchday','is_free','is_featured','thumbnail_url','status'];
    const map: Record<string, string> = {
      competitionId: 'competition_id', seasonId: 'season_id',
      homeTeamId: 'home_team_id', awayTeamId: 'away_team_id',
      scheduledAt: 'scheduled_at', isFree: 'is_free', isFeatured: 'is_featured',
      thumbnailUrl: 'thumbnail_url',
    };

    for (const [key, val] of Object.entries(data)) {
      const col = map[key] || key;
      if (allowed.includes(col) && val !== undefined) {
        fields.push(`${col} = $${i++}`);
        params.push(val);
      }
    }

    if (!fields.length) return;
    params.push(id);
    await db.query(`UPDATE matches SET ${fields.join(',')} WHERE id = $${i}`, params);
  },

  /** Démarrer le direct */
  async startLive(matchId: string): Promise<void> {
    await db.query(`
      UPDATE matches
      SET status = 'live', started_at = NOW(), minute = 0
      WHERE id = $1 AND status = 'scheduled'
    `, [matchId]);
  },

  /** Arrêter le direct */
  async stopLive(matchId: string): Promise<void> {
    await db.query(`
      UPDATE matches
      SET status = 'finished', ended_at = NOW()
      WHERE id = $1 AND status = 'live'
    `, [matchId]);
  },

  /** Mettre à jour le score */
  async updateScore(matchId: string, data: UpdateScoreInput): Promise<void> {
    await db.query(`
      UPDATE matches
      SET home_score = $1, away_score = $2, minute = $3
      WHERE id = $4
    `, [data.homeScore, data.awayScore, data.minute || null, matchId]);
  },

  /** Ajouter un événement */
  async addEvent(matchId: string, data: AddEventInput) {
    const result = await db.query(`
      INSERT INTO match_events (match_id, type, minute, extra_time, player_name, team_id, description)
      VALUES ($1,$2,$3,$4,$5,$6,$7)
      RETURNING *
    `, [matchId, data.type, data.minute, data.extraTime||null, data.playerName||null, data.teamId||null, data.description||null]);
    return result.rows[0];
  },

  /** Supprimer un événement */
  async deleteEvent(eventId: string): Promise<void> {
    await db.query('DELETE FROM match_events WHERE id = $1', [eventId]);
  },

  /** Prochains matchs */
  async getUpcoming(limit = 5) {
    const result = await db.query(`
      SELECT m.id, m.scheduled_at, m.status, m.is_free, m.thumbnail_url,
        ht.name AS home_name, ht.logo_url AS home_logo,
        at.name AS away_name, at.logo_url AS away_logo,
        c.name AS comp_name
      FROM matches m
      JOIN teams ht ON ht.id = m.home_team_id
      JOIN teams at ON at.id = m.away_team_id
      JOIN competitions c ON c.id = m.competition_id
      WHERE m.status = 'scheduled' AND m.scheduled_at > NOW()
      ORDER BY m.scheduled_at ASC
      LIMIT $1
    `, [limit]);
    return result.rows;
  },

  /** Replays disponibles */
  async getReplays(limit = 12, offset = 0) {
    const result = await db.query(`
      SELECT m.id, m.scheduled_at, m.ended_at, m.home_score, m.away_score,
        m.thumbnail_url, m.replay_url, m.is_free,
        ht.name AS home_name, ht.logo_url AS home_logo,
        at.name AS away_name, at.logo_url AS away_logo,
        c.name AS comp_name
      FROM matches m
      JOIN teams ht ON ht.id = m.home_team_id
      JOIN teams at ON at.id = m.away_team_id
      JOIN competitions c ON c.id = m.competition_id
      WHERE m.status = 'finished' AND m.replay_url IS NOT NULL
      ORDER BY m.ended_at DESC
      LIMIT $1 OFFSET $2
    `, [limit, offset]);
    return result.rows;
  },

  /** Générer une nouvelle stream key pour un match */
  async regenerateStreamKey(matchId: string): Promise<string> {
    const key = `match_${crypto.randomBytes(8).toString('hex')}`;
    await db.query('UPDATE matches SET stream_key = $1 WHERE id = $2', [key, matchId]);
    return key;
  },

  /** Mettre à jour l'URL replay */
  async setReplayUrl(matchId: string, replayUrl: string): Promise<void> {
    await db.query('UPDATE matches SET replay_url = $1 WHERE id = $2', [replayUrl, matchId]);
  },
};

// ── Helper format ─────────────────────────────────────────

function formatMatch(row: any) {
  return {
    id: row.id,
    scheduledAt: row.scheduled_at,
    status: row.status,
    score: { home: row.home_score, away: row.away_score },
    minute: row.minute,
    isFree: row.is_free,
    isFeatured: row.is_featured,
    thumbnailUrl: row.thumbnail_url,
    matchday: row.matchday,
    startedAt: row.started_at,
    endedAt: row.ended_at,
    streamKey: row.stream_key,
    hlsUrl: row.hls_url,
    replayUrl: row.replay_url,
    homeTeam: {
      id: row.home_id,
      name: row.home_name,
      shortName: row.home_short,
      logo: row.home_logo,
      city: row.home_city,
    },
    awayTeam: {
      id: row.away_id,
      name: row.away_name,
      shortName: row.away_short,
      logo: row.away_logo,
      city: row.away_city,
    },
    competition: {
      id: row.comp_id,
      name: row.comp_name,
      logo: row.comp_logo,
      format: row.comp_format,
    },
    season: row.season_name ? {
      name: row.season_name,
      yearStart: row.year_start,
      yearEnd: row.year_end,
    } : null,
  };
}
