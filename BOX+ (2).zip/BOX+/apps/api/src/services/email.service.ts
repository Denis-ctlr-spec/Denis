import nodemailer from 'nodemailer';
import { config } from '../config';
import { logger } from '../utils/logger';

const transporter = nodemailer.createTransport({
  host: config.email.host,
  port: config.email.port,
  secure: config.email.port === 465,
  auth: {
    user: config.email.user,
    pass: config.email.pass,
  },
});

// ── Templates HTML ────────────────────────────────────────

function baseTemplate(content: string): string {
  return `
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>BOX+</title>
  <style>
    body { margin:0; padding:0; background:#0A0A0A; font-family:'Segoe UI',Arial,sans-serif; color:#fff; }
    .container { max-width:580px; margin:0 auto; padding:40px 20px; }
    .logo { text-align:center; margin-bottom:32px; }
    .logo span { font-size:28px; font-weight:900; color:#FF5A1F; letter-spacing:2px; }
    .logo span em { color:#fff; font-style:normal; }
    .card { background:#141414; border-radius:12px; padding:32px; border:1px solid #2a2a2a; }
    .btn { display:inline-block; background:#FF5A1F; color:#fff; text-decoration:none;
           padding:14px 32px; border-radius:8px; font-weight:700; font-size:16px; margin:24px 0; }
    .footer { text-align:center; color:#666; font-size:12px; margin-top:24px; }
    h1 { font-size:22px; margin:0 0 16px; }
    p { color:#ccc; line-height:1.6; margin:8px 0; }
    .divider { border:none; border-top:1px solid #2a2a2a; margin:24px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="logo"><span>BOX<em>+</em></span></div>
    <div class="card">${content}</div>
    <div class="footer">
      <p>© ${new Date().getFullYear()} BOX+ — Football en streaming</p>
      <p>Lomé, Togo · support@boxplus.tg</p>
    </div>
  </div>
</body>
</html>`;
}

// ── Service email ─────────────────────────────────────────

export const emailService = {
  async sendVerificationEmail(to: string, name: string, verifyUrl: string) {
    const html = baseTemplate(`
      <h1>Bienvenue sur BOX+, ${name} ! 🎉</h1>
      <p>Merci de vous être inscrit. Confirmez votre adresse email pour accéder à tous les matchs.</p>
      <div style="text-align:center">
        <a class="btn" href="${verifyUrl}">Confirmer mon email</a>
      </div>
      <hr class="divider"/>
      <p style="font-size:13px;color:#666">Ce lien expire dans 24 heures. Si vous n'avez pas créé de compte, ignorez cet email.</p>
    `);

    await transporter.sendMail({
      from: config.email.from,
      to,
      subject: '✅ Confirmez votre compte BOX+',
      html,
    });
    logger.info(`Email de vérification envoyé à ${to}`);
  },

  async sendPasswordReset(to: string, name: string, resetUrl: string) {
    const html = baseTemplate(`
      <h1>Réinitialisation de mot de passe</h1>
      <p>Bonjour ${name},</p>
      <p>Vous avez demandé à réinitialiser votre mot de passe. Cliquez sur le bouton ci-dessous :</p>
      <div style="text-align:center">
        <a class="btn" href="${resetUrl}">Réinitialiser mon mot de passe</a>
      </div>
      <hr class="divider"/>
      <p style="font-size:13px;color:#666">Ce lien expire dans 1 heure. Si vous n'avez pas fait cette demande, ignorez cet email.</p>
    `);

    await transporter.sendMail({
      from: config.email.from,
      to,
      subject: '🔐 Réinitialisation de votre mot de passe BOX+',
      html,
    });
    logger.info(`Email de reset envoyé à ${to}`);
  },

  async sendSubscriptionConfirmation(
    to: string,
    name: string,
    planName: string,
    expiresAt: Date
  ) {
    const html = baseTemplate(`
      <h1>Abonnement activé ! ⚽</h1>
      <p>Bonjour ${name},</p>
      <p>Votre <strong style="color:#FF5A1F">${planName}</strong> est maintenant actif.</p>
      <p>Votre accès est valide jusqu'au <strong>${expiresAt.toLocaleDateString('fr-FR', {
        weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
      })}</strong>.</p>
      <div style="text-align:center">
        <a class="btn" href="${config.server.webUrl}">Regarder les matchs</a>
      </div>
    `);

    await transporter.sendMail({
      from: config.email.from,
      to,
      subject: '⚽ Votre abonnement BOX+ est actif',
      html,
    });
  },

  async sendRenewalReminder(to: string, name: string, planName: string, daysLeft: number) {
    const html = baseTemplate(`
      <h1>Votre abonnement expire bientôt ⏰</h1>
      <p>Bonjour ${name},</p>
      <p>Votre <strong style="color:#FF5A1F">${planName}</strong> expire dans <strong>${daysLeft} jour${daysLeft > 1 ? 's' : ''}</strong>.</p>
      <p>Renouvelez maintenant pour ne manquer aucun match !</p>
      <div style="text-align:center">
        <a class="btn" href="${config.server.webUrl}/abonnement">Renouveler mon abonnement</a>
      </div>
    `);

    await transporter.sendMail({
      from: config.email.from,
      to,
      subject: `⏰ Plus que ${daysLeft} jour${daysLeft > 1 ? 's' : ''} sur votre BOX+`,
      html,
    });
  },
};
