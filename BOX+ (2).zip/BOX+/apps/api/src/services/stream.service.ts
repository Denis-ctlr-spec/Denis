import crypto from 'crypto';
import { db } from '../config/database';
import { redis, setWatchSession, countWatchSessions } from '../config/redis';
import { config } from '../config';
import { AppError } from '../middleware/errorHandler';
import { logger } from '../utils/logger';

export interface GenerateStreamTokenOptions {
  userId: string;
  matchId: string;
  deviceFingerprint: string;
  ipAddress?: string;
  userAgent?: string;
}

export const streamService = {

  /**
   * 1. Vérification d'abonnement + génération d'URL HLS sécurisée avec Token HMAC
   */
  async getSecuredStreamUrl(opts: GenerateStreamTokenOptions): Promise<{
    hlsUrl: string;
    expiresIn: number;
    token: string;
    maxDevices: number;
    match: any;
  }> {
    const { userId, matchId, deviceFingerprint, ipAddress, userAgent } = opts;

    // A. Récupérer les informations du match
    const matchRes = await db.query(`
      SELECT m.*, c.name as comp_name
      FROM matches m
      JOIN competitions c ON c.id = m.competition_id
      WHERE m.id = $1
    `, [matchId]);

    if (!matchRes.rows.length) {
      throw new AppError('Match introuvable.', 404);
    }
    const match = matchRes.rows[0];

    // B. Si le match n'est pas gratuit, vérifier l'abonnement actif ou pass match
    let maxAllowedDevices = 1;
    if (!match.is_free) {
      const subRes = await db.query(`
        SELECT s.*, p.slug as plan_slug, p.features
        FROM subscriptions s
        JOIN subscription_plans p ON p.id = s.plan_id
        WHERE s.user_id = $1
          AND s.status = 'active'
          AND s.expires_at > NOW()
          AND (
            s.match_id IS NULL OR s.match_id = $2
          )
        ORDER BY s.expires_at DESC
        LIMIT 1
      `, [userId, matchId]);

      if (!subRes.rows.length) {
        throw new AppError(
          'Abonnement requis. Veuillez souscrire à un Pass Match ou Mensuel pour visionner ce contenu.',
          403
        );
      }

      const activeSub = subRes.rows[0];
      if (activeSub.plan_slug === 'saison') {
        maxAllowedDevices = 3;
      } else if (activeSub.plan_slug === 'mensuel') {
        maxAllowedDevices = 2;
      } else {
        maxAllowedDevices = 1; // Pass 1 match
      }
    }

    // C. Anti-partage de compte : Vérifier la limite d'appareils simultanés
    const activeSessionsCount = await countWatchSessions(userId, matchId);
    const existingKey = `watch:${userId}:${matchId}:${deviceFingerprint}`;
    const alreadyWatchingThisDevice = (await redis.exists(existingKey)) === 1;

    if (!alreadyWatchingThisDevice && activeSessionsCount >= maxAllowedDevices) {
      throw new AppError(
        `Limite d'écrans atteinte (${maxAllowedDevices} appareil${maxAllowedDevices > 1 ? 's' : ''} simultané${maxAllowedDevices > 1 ? 's' : ''}). Fermez la session sur votre autre appareil.`,
        429
      );
    }

    // D. Enregistrer le ping de cette session (TTL 60 secondes avec heartbeat périodique du player)
    await setWatchSession(userId, matchId, deviceFingerprint, 60);

    // E. Génération du Token signé HMAC-SHA256 à durée limitée (1h)
    const expiresIn = config.stream.tokenExpires || 3600;
    const expiresAtTimestamp = Math.floor(Date.now() / 1000) + expiresIn;
    const expiresAtDate = new Date(Date.now() + expiresIn * 1000);

    const streamName = match.stream_key || `match_${match.id}`;
    const rawPayload = `${userId}:${matchId}:${streamName}:${deviceFingerprint}:${expiresAtTimestamp}`;
    
    const signature = crypto
      .createHmac('sha256', config.stream.tokenSecret)
      .update(rawPayload)
      .digest('hex');

    const signedToken = `${expiresAtTimestamp}.${signature}`;

    // F. Persister le token en base pour audit et traçabilité
    await db.query(`
      INSERT INTO stream_tokens (user_id, match_id, token, device_fingerprint, ip_address, expires_at)
      VALUES ($1, $2, $3, $4, $5::inet, $6)
    `, [userId, matchId, signedToken, deviceFingerprint, ipAddress || null, expiresAtDate]);

    // G. Enregistrer dans la table watch_sessions
    await db.query(`
      INSERT INTO watch_sessions (user_id, match_id, device_fingerprint, ip_address, user_agent, is_active)
      VALUES ($1, $2, $3, $4::inet, $5, TRUE)
    `, [userId, matchId, deviceFingerprint, ipAddress || null, userAgent || null]);

    // H. Construire la Master Playlist HLS sécurisée
    const hlsUrl = `/hls/live/${streamName}/master.m3u8?token=${signedToken}&dev=${encodeURIComponent(deviceFingerprint)}`;

    return {
      hlsUrl,
      expiresIn,
      token: signedToken,
      maxDevices: maxAllowedDevices,
      match: {
        id: match.id,
        status: match.status,
        homeScore: match.home_score,
        awayScore: match.away_score,
        isFree: match.is_free,
      },
    };
  },

  /**
   * 2. Validation du Token par Nginx / SRS pour chaque segment vidéo .ts et playlist .m3u8
   */
  async validateStreamToken(opts: {
    token: string;
    deviceFingerprint: string;
    streamName: string;
    ipAddress?: string;
  }): Promise<{ valid: boolean; reason?: string }> {
    const { token, deviceFingerprint, streamName } = opts;

    if (!token || !token.includes('.')) {
      return { valid: false, reason: 'Format de token invalide' };
    }

    const [expStr, signature] = token.split('.');
    const expiresAtTimestamp = parseInt(expStr, 10);

    // Vérifier l'expiration temporelle
    if (Date.now() / 1000 > expiresAtTimestamp) {
      return { valid: false, reason: 'Token de visionnage expiré' };
    }

    // Retrouver en BDD
    const tokenRes = await db.query(`
      SELECT st.*, u.is_active as user_active
      FROM stream_tokens st
      JOIN users u ON u.id = st.user_id
      WHERE st.token = $1 AND st.is_revoked = FALSE
    `, [token]);

    if (!tokenRes.rows.length) {
      return { valid: false, reason: 'Token inconnu ou révoqué' };
    }

    const record = tokenRes.rows[0];
    if (!record.user_active) {
      return { valid: false, reason: 'Compte utilisateur suspendu' };
    }

    // Vérifier l'empreinte de l'appareil (anti-partage de lien entre personnes différentes)
    if (record.device_fingerprint !== deviceFingerprint) {
      return { valid: false, reason: 'Accès refusé : Ce lien est verrouillé sur un autre appareil' };
    }

    // Vérifier l'intégrité de la signature HMAC
    const expectedPayload = `${record.user_id}:${record.match_id}:${streamName}:${deviceFingerprint}:${expiresAtTimestamp}`;
    const expectedSig = crypto
      .createHmac('sha256', config.stream.tokenSecret)
      .update(expectedPayload)
      .digest('hex');

    if (signature !== expectedSig) {
      return { valid: false, reason: 'Signature HMAC invalide' };
    }

    return { valid: true };
  },

  /**
   * 3. Heartbeat régulier envoyé par le player du spectateur (toutes les 30s)
   */
  async pingWatchSession(userId: string, matchId: string, deviceFingerprint: string) {
    await setWatchSession(userId, matchId, deviceFingerprint, 60);
    await db.query(`
      UPDATE watch_sessions
      SET last_ping = NOW(), is_active = TRUE
      WHERE user_id = $1 AND match_id = $2 AND device_fingerprint = $3
    `, [userId, matchId, deviceFingerprint]);
  },

  /**
   * 4. Fermeture de session (quand l'utilisateur quitte la page)
   */
  async closeWatchSession(userId: string, matchId: string, deviceFingerprint: string) {
    await redis.del(`watch:${userId}:${matchId}:${deviceFingerprint}`);
    await db.query(`
      UPDATE watch_sessions
      SET is_active = FALSE
      WHERE user_id = $1 AND match_id = $2 AND device_fingerprint = $3
    `, [userId, matchId, deviceFingerprint]);
  },

  /**
   * 5. Webhook SRS : Authentification de la source RTMP (OBS / vMix)
   */
  async authenticateRtmpPublish(streamKey: string): Promise<boolean> {
    const res = await db.query(
      'SELECT id, status FROM matches WHERE stream_key = $1',
      [streamKey]
    );

    if (!res.rows.length) {
      logger.warn(`Échec authentification RTMP : Clé invalide "${streamKey}"`);
      return false;
    }

    const match = res.rows[0];
    logger.info(`Source OBS autorisée pour le match ID ${match.id} (Clé: ${streamKey})`);

    // Passer automatiquement le match en 'live' s'il était 'scheduled'
    if (match.status === 'scheduled') {
      await db.query(`
        UPDATE matches
        SET status = 'live', started_at = NOW(), minute = 0
        WHERE id = $1
      `, [match.id]);
    }

    return true;
  },

  /**
   * 6. Webhook SRS : Fin de flux RTMP (OBS déconnecté)
   */
  async onRtmpUnpublish(streamKey: string) {
    logger.info(`Flux OBS terminé pour la clé : ${streamKey}`);
    
    // Mettre à jour l'URL du replay si un fichier MP4 a été généré
    const replayPath = `/media/replays/live/${streamKey}/replay.mp4`;
    await db.query(`
      UPDATE matches
      SET replay_url = $1
      WHERE stream_key = $2 AND replay_url IS NULL
    `, [replayPath, streamKey]);
  },
};
