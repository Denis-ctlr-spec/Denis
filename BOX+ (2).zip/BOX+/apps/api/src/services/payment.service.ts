import axios from 'axios';
import crypto from 'crypto';
import { db } from '../config/database';
import { config } from '../config';
import { AppError } from '../middleware/errorHandler';
import { emailService } from './email.service';
import { logger } from '../utils/logger';

const FEDAPAY_API_URL = config.fedapay.env === 'live'
  ? 'https://api.fedapay.com/v1'
  : 'https://sandbox-api.fedapay.com/v1';

export interface InitializePaymentInput {
  userId: string;
  planId: string;
  paymentMethod: 'tmoney' | 'flooz' | 'card';
  phoneNumber?: string;
  matchId?: string; // Obligatoire si pass-match
  promoCode?: string;
}

export const paymentService = {

  /**
   * 1. Initialiser une transaction Mobile Money (T-Money / Flooz) via FedaPay
   */
  async initializePayment(input: InitializePaymentInput) {
    const { userId, planId, paymentMethod, phoneNumber, matchId, promoCode } = input;

    // Récupérer le plan et l'utilisateur
    const [userRes, planRes] = await Promise.all([
      db.query('SELECT id, email, full_name, phone FROM users WHERE id = $1', [userId]),
      db.query('SELECT * FROM subscription_plans WHERE id = $1 AND is_active = TRUE', [planId]),
    ]);

    if (!userRes.rows.length) throw new AppError('Utilisateur introuvable', 404);
    if (!planRes.rows.length) throw new AppError('Plan d\'abonnement introuvable ou inactif', 404);

    const user = userRes.rows[0];
    const plan = planRes.rows[0];

    // Vérifier si code promo valide
    let finalAmount = parseFloat(plan.price);
    let discountApplied = 0;

    if (promoCode) {
      const promoRes = await db.query(`
        SELECT * FROM promo_codes
        WHERE code = $1 AND is_active = TRUE
          AND (valid_until IS NULL OR valid_until > NOW())
          AND (max_uses IS NULL OR current_uses < max_uses)
      `, [promoCode.toUpperCase()]);

      if (promoRes.rows.length > 0) {
        const promo = promoRes.rows[0];
        if (promo.discount_type === 'percentage') {
          discountApplied = (finalAmount * parseFloat(promo.discount_value)) / 100;
        } else {
          discountApplied = parseFloat(promo.discount_value);
        }
        finalAmount = Math.max(0, finalAmount - discountApplied);
      }
    }

    // Créer la souscription en statut 'pending'
    const subRes = await db.query(`
      INSERT INTO subscriptions (user_id, plan_id, status, match_id, promo_code, discount_applied)
      VALUES ($1, $2, 'pending', $3, $4, $5)
      RETURNING id
    `, [userId, plan.id, matchId || null, promoCode || null, discountApplied]);
    const subscriptionId = subRes.rows[0].id;

    // Créer le paiement localement
    const paymentRes = await db.query(`
      INSERT INTO payments (user_id, subscription_id, plan_id, amount, currency, status, payment_method, phone_number)
      VALUES ($1, $2, $3, $4, 'XOF', 'pending', $5, $6)
      RETURNING id
    `, [userId, subscriptionId, plan.id, finalAmount, paymentMethod, phoneNumber || user.phone]);
    const paymentId = paymentRes.rows[0].id;

    // Définir le mode de paiement pour l'API FedaPay
    // Pour le Togo : T-Money (togocel) ou Flooz (moov)
    let fedaMode = 'mtn_open';
    if (paymentMethod === 'tmoney') fedaMode = 'togocel';
    if (paymentMethod === 'flooz') fedaMode = 'moov';

    let fedapayTxId = '';
    let checkoutUrl = '';

    // Appel à l'API REST FedaPay (Sandbox ou Live)
    if (config.fedapay.secretKey && !config.fedapay.secretKey.includes('CHANGE_ME')) {
      try {
        const response = await axios.post(
          `${FEDAPAY_API_URL}/transactions`,
          {
            description: `Abonnement BOX+ : ${plan.name}`,
            amount: Math.round(finalAmount),
            currency: { iso: 'XOF' },
            callback_url: `${config.server.webUrl}/abonnement/confirmation?payment_id=${paymentId}`,
            customer: {
              firstname: user.full_name.split(' ')[0] || 'Client',
              lastname: user.full_name.split(' ').slice(1).join(' ') || 'BOX+',
              email: user.email,
              phone_number: {
                number: phoneNumber || user.phone || '90000000',
                country: 'tg',
              },
            },
          },
          {
            headers: {
              Authorization: `Bearer ${config.fedapay.secretKey}`,
              'Content-Type': 'application/json',
            },
          }
        );

        const tx = response.data['v1/transaction'] || response.data;
        fedapayTxId = tx.id.toString();

        // Générer le token de paiement
        const tokenRes = await axios.post(
          `${FEDAPAY_API_URL}/transactions/${fedapayTxId}/token`,
          {},
          {
            headers: { Authorization: `Bearer ${config.fedapay.secretKey}` },
          }
        );

        checkoutUrl = tokenRes.data.url;
      } catch (err: any) {
        logger.error('Erreur API FedaPay', err.response?.data || err.message);
        // Fallback simulation en dev si clés manquantes ou sandbox timeout
      }
    }

    // Si pas de clé ou sandbox simulation :
    if (!checkoutUrl) {
      fedapayTxId = `sim_${crypto.randomBytes(6).toString('hex')}`;
      checkoutUrl = `${config.server.webUrl}/abonnement/confirmation?payment_id=${paymentId}&demo=true`;
    }

    // Mettre à jour l'enregistrement de paiement avec l'ID FedaPay
    await db.query(`
      UPDATE payments
      SET fedapay_transaction_id = $1
      WHERE id = $2
    `, [fedapayTxId, paymentId]);

    return {
      paymentId,
      subscriptionId,
      amount: finalAmount,
      planName: plan.name,
      checkoutUrl,
      fedapayTxId,
      isDemo: checkoutUrl.includes('demo=true'),
    };
  },

  /**
   * 2. Traitement du Webhook FedaPay (Signature HMAC-SHA256)
   */
  async handleWebhook(rawBody: string, signature: string | undefined, payload: any) {
    // Vérifier la signature si secret configuré
    if (config.fedapay.webhookSecret && signature) {
      const hmac = crypto
        .createHmac('sha256', config.fedapay.webhookSecret)
        .update(rawBody)
        .digest('hex');

      if (hmac !== signature) {
        throw new AppError('Signature de webhook FedaPay invalide.', 401);
      }
    }

    const eventName = payload.name || payload.event;
    const entity = payload.entity || payload;
    const fedapayTxId = entity.id?.toString();

    logger.info(`Webhook FedaPay reçu : Événement ${eventName} pour transaction ${fedapayTxId}`);

    if (!fedapayTxId) return;

    // Événement de transaction approuvée
    if (eventName === 'transaction.approved' || entity.status === 'approved') {
      await this.activateSubscriptionFromPayment(fedapayTxId, entity);
    } else if (eventName === 'transaction.canceled' || entity.status === 'canceled') {
      await db.query(`
        UPDATE payments SET status = 'cancelled', webhook_payload = $1 WHERE fedapay_transaction_id = $2
      `, [payload, fedapayTxId]);
    } else if (eventName === 'transaction.declined' || entity.status === 'declined') {
      await db.query(`
        UPDATE payments SET status = 'declined', failure_reason = 'Refus opérateur Mobile Money', webhook_payload = $1
        WHERE fedapay_transaction_id = $2
      `, [payload, fedapayTxId]);
    }
  },

  /**
   * 3. Activation automatique de l'abonnement
   */
  async activateSubscriptionFromPayment(fedapayTxId: string, webhookPayload?: any) {
    const payRes = await db.query(`
      SELECT p.*, s.id as sub_id, s.user_id, s.plan_id, s.match_id, s.promo_code,
             sp.duration_days, sp.name as plan_name,
             u.email, u.full_name
      FROM payments p
      JOIN subscriptions s ON s.id = p.subscription_id
      JOIN subscription_plans sp ON sp.id = s.plan_id
      JOIN users u ON u.id = s.user_id
      WHERE p.fedapay_transaction_id = $1
    `, [fedapayTxId]);

    if (!payRes.rows.length) {
      logger.warn(`Transaction introuvable pour activation : ${fedapayTxId}`);
      return;
    }

    const data = payRes.rows[0];

    // Calcul des dates de début et d'expiration
    const startsAt = new Date();
    const expiresAt = new Date(startsAt.getTime() + data.duration_days * 24 * 60 * 60 * 1000);

    await db.transaction(async (client) => {
      // 1. Marquer le paiement comme approuvé
      await client.query(`
        UPDATE payments
        SET status = 'approved', paid_at = NOW(), webhook_payload = $1
        WHERE id = $2
      `, [webhookPayload || null, data.id]);

      // 2. Activer la souscription
      await client.query(`
        UPDATE subscriptions
        SET status = 'active', starts_at = $1, expires_at = $2
        WHERE id = $3
      `, [startsAt, expiresAt, data.sub_id]);

      // 3. Incrémenter le code promo si utilisé
      if (data.promo_code) {
        await client.query(`
          UPDATE promo_codes
          SET current_uses = current_uses + 1
          WHERE code = $1
        `, [data.promo_code]);
      }

      // 4. Programmer le rappel de renouvellement à J-3 (scheduled_notifications)
      const reminderDate = new Date(expiresAt.getTime() - 3 * 24 * 60 * 60 * 1000);
      if (reminderDate > new Date()) {
        await client.query(`
          INSERT INTO scheduled_notifications (user_id, subscription_id, type, scheduled_at)
          VALUES ($1, $2, 'renewal_reminder', $3)
        `, [data.user_id, data.sub_id, reminderDate]);
      }
    });

    logger.info(`Abonnement ${data.plan_name} activé pour ${data.email} jusqu'au ${expiresAt.toISOString()}`);

    // Envoyer l'email de confirmation
    try {
      await emailService.sendSubscriptionConfirmation(data.email, data.full_name, data.plan_name, expiresAt);
    } catch (err) {
      logger.warn('Échec envoi email confirmation abonnement', err);
    }
  },

  /**
   * 4. Statut d'un paiement pour le spectateur (polling de confirmation)
   */
  async getPaymentStatus(paymentId: string) {
    const res = await db.query(`
      SELECT p.id, p.amount, p.currency, p.status, p.paid_at, p.payment_method,
             sp.name as plan_name, s.starts_at, s.expires_at, s.status as sub_status
      FROM payments p
      JOIN subscription_plans sp ON sp.id = p.plan_id
      LEFT JOIN subscriptions s ON s.id = p.subscription_id
      WHERE p.id = $1
    `, [paymentId]);

    if (!res.rows.length) throw new AppError('Paiement introuvable', 404);
    return res.rows[0];
  },

  /**
   * 5. Simulation Sandbox (pour tests immédiats sans carte ni USSD réel)
   */
  async simulateSandboxApproval(paymentId: string) {
    const payRes = await db.query('SELECT fedapay_transaction_id FROM payments WHERE id = $1', [paymentId]);
    if (!payRes.rows.length) throw new AppError('Paiement introuvable', 404);

    const txId = payRes.rows[0].fedapay_transaction_id;
    await this.activateSubscriptionFromPayment(txId, { simulated: true });
  },

  /**
   * 6. Historique des factures et abonnements d'un utilisateur
   */
  async getUserBillingHistory(userId: string) {
    const [subsRes, paysRes] = await Promise.all([
      db.query(`
        SELECT s.*, sp.name as plan_name, sp.price, sp.duration_days,
               m.id as match_id, ht.name as home_name, at.name as away_name
        FROM subscriptions s
        JOIN subscription_plans sp ON sp.id = s.plan_id
        LEFT JOIN matches m ON m.id = s.match_id
        LEFT JOIN teams ht ON ht.id = m.home_team_id
        LEFT JOIN teams at ON at.id = m.away_team_id
        WHERE s.user_id = $1
        ORDER BY s.created_at DESC
      `, [userId]),
      db.query(`
        SELECT p.*, sp.name as plan_name
        FROM payments p
        JOIN subscription_plans sp ON sp.id = p.plan_id
        WHERE p.user_id = $1
        ORDER BY p.created_at DESC
      `, [userId]),
    ]);

    return {
      subscriptions: subsRes.rows,
      payments: paysRes.rows,
    };
  },
};
