import { db } from '../config/database';

export const adminService = {

  /** Dashboard : métriques globales */
  async getDashboardStats() {
    const [revenue, subscribers, liveViewers, payments] = await Promise.all([
      db.query(`
        SELECT
          COALESCE(SUM(amount), 0) AS total_revenue,
          COALESCE(SUM(CASE WHEN DATE_TRUNC('month', paid_at) = DATE_TRUNC('month', NOW()) THEN amount ELSE 0 END), 0) AS month_revenue,
          COALESCE(SUM(CASE WHEN DATE_TRUNC('month', paid_at) = DATE_TRUNC('month', NOW() - INTERVAL '1 month') THEN amount ELSE 0 END), 0) AS prev_month_revenue
        FROM payments WHERE status = 'approved'
      `),
      db.query(`
        SELECT
          COUNT(*) AS total_users,
          COUNT(*) FILTER (WHERE created_at > NOW() - INTERVAL '30 days') AS new_this_month,
          (SELECT COUNT(DISTINCT user_id) FROM subscriptions WHERE status = 'active' AND expires_at > NOW()) AS active_subscribers
        FROM users WHERE role = 'spectator'
      `),
      db.query(`
        SELECT COUNT(*) AS live_viewers
        FROM watch_sessions
        WHERE is_active = TRUE AND last_ping > NOW() - INTERVAL '90 seconds'
      `),
      db.query(`
        SELECT status, COUNT(*) AS count, SUM(amount) AS total
        FROM payments
        WHERE created_at > NOW() - INTERVAL '30 days'
        GROUP BY status
      `),
    ]);

    const rev = revenue.rows[0];
    const sub = subscribers.rows[0];
    const live = liveViewers.rows[0];
    const monthGrowth = rev.prev_month_revenue > 0
      ? ((rev.month_revenue - rev.prev_month_revenue) / rev.prev_month_revenue * 100).toFixed(1)
      : null;

    return {
      revenue: {
        total: parseFloat(rev.total_revenue),
        thisMonth: parseFloat(rev.month_revenue),
        prevMonth: parseFloat(rev.prev_month_revenue),
        growthPercent: monthGrowth,
      },
      users: {
        total: parseInt(sub.total_users),
        newThisMonth: parseInt(sub.new_this_month),
        activeSubscribers: parseInt(sub.active_subscribers),
      },
      liveViewers: parseInt(live.live_viewers),
      recentPayments: payments.rows,
    };
  },

  /** Revenus par jour (30 derniers jours) */
  async getRevenueChart() {
    const result = await db.query(`
      SELECT
        DATE_TRUNC('day', paid_at)::date AS day,
        SUM(amount) AS revenue,
        COUNT(*) AS transactions
      FROM payments
      WHERE status = 'approved' AND paid_at > NOW() - INTERVAL '30 days'
      GROUP BY 1 ORDER BY 1
    `);
    return result.rows;
  },

  /** Liste des utilisateurs (admin) */
  async listUsers(opts: { search?: string; role?: string; limit?: number; offset?: number }) {
    const conditions: string[] = [];
    const params: any[] = [];
    let i = 1;

    if (opts.search) {
      conditions.push(`(u.email ILIKE $${i} OR u.full_name ILIKE $${i} OR u.phone ILIKE $${i})`);
      params.push(`%${opts.search}%`); i++;
    }
    if (opts.role) { conditions.push(`u.role = $${i++}`); params.push(opts.role); }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const limit = Math.min(opts.limit || 20, 100);
    const offset = opts.offset || 0;

    const result = await db.query(`
      SELECT u.id, u.email, u.phone, u.full_name, u.role, u.is_active,
        u.email_verified, u.last_login_at, u.created_at,
        s.status AS sub_status, sp.name AS sub_plan, s.expires_at AS sub_expires
      FROM users u
      LEFT JOIN subscriptions s ON s.user_id = u.id AND s.status = 'active' AND s.expires_at > NOW()
      LEFT JOIN subscription_plans sp ON sp.id = s.plan_id
      ${where}
      ORDER BY u.created_at DESC
      LIMIT $${i++} OFFSET $${i++}
    `, [...params, limit, offset]);

    const count = await db.query(`SELECT COUNT(*) FROM users u ${where}`, params);
    return { users: result.rows, total: parseInt(count.rows[0].count), limit, offset };
  },

  /** Changer le rôle d'un utilisateur */
  async setUserRole(userId: string, role: string): Promise<void> {
    await db.query('UPDATE users SET role = $1 WHERE id = $2', [role, userId]);
  },

  /** Activer / désactiver un compte */
  async setUserActive(userId: string, isActive: boolean): Promise<void> {
    await db.query('UPDATE users SET is_active = $1 WHERE id = $2', [isActive, userId]);
  },

  /** Plans d'abonnement */
  async listPlans() {
    const result = await db.query('SELECT * FROM subscription_plans ORDER BY sort_order ASC');
    return result.rows;
  },

  async updatePlan(id: string, data: { price?: number; isActive?: boolean; name?: string }) {
    const fields: string[] = [];
    const params: any[] = [id];
    let i = 2;
    if (data.price !== undefined) { fields.push(`price = $${i++}`); params.push(data.price); }
    if (data.isActive !== undefined) { fields.push(`is_active = $${i++}`); params.push(data.isActive); }
    if (data.name !== undefined) { fields.push(`name = $${i++}`); params.push(data.name); }
    if (fields.length) {
      await db.query(`UPDATE subscription_plans SET ${fields.join(', ')} WHERE id = $1`, params);
    }
  },

  /** Codes promo */
  async listPromoCodes() {
    const result = await db.query('SELECT * FROM promo_codes ORDER BY created_at DESC');
    return result.rows;
  },

  async createPromoCode(data: any): Promise<string> {
    const result = await db.query(`
      INSERT INTO promo_codes (code, discount_type, discount_value, max_uses, valid_from, valid_until)
      VALUES ($1,$2,$3,$4,$5,$6) RETURNING id
    `, [data.code.toUpperCase(), data.discountType, data.discountValue,
        data.maxUses||null, data.validFrom||new Date(), data.validUntil||null]);
    return result.rows[0].id;
  },

  /** Paiements récents */
  async listPayments(opts: { status?: string; limit?: number; offset?: number }) {
    const cond = opts.status ? 'WHERE p.status = $1' : '';
    const params: any[] = opts.status ? [opts.status] : [];
    const i = params.length + 1;
    const result = await db.query(`
      SELECT p.*, u.email, u.full_name, sp.name AS plan_name
      FROM payments p
      JOIN users u ON u.id = p.user_id
      JOIN subscription_plans sp ON sp.id = p.plan_id
      ${cond}
      ORDER BY p.created_at DESC
      LIMIT $${i} OFFSET $${i+1}
    `, [...params, opts.limit||20, opts.offset||0]);
    return result.rows;
  },

  /** Abonnements actifs */
  async listSubscriptions(opts: { status?: string; limit?: number; offset?: number }) {
    const result = await db.query(`
      SELECT s.*, u.email, u.full_name, sp.name AS plan_name
      FROM subscriptions s
      JOIN users u ON u.id = s.user_id
      JOIN subscription_plans sp ON sp.id = s.plan_id
      ${opts.status ? `WHERE s.status = '${opts.status}'` : ''}
      ORDER BY s.created_at DESC
      LIMIT $1 OFFSET $2
    `, [opts.limit||20, opts.offset||0]);
    return result.rows;
  },
};
