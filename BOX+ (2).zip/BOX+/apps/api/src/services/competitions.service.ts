import { db } from '../config/database';
import { AppError } from '../middleware/errorHandler';

export const competitionService = {

  async listCompetitions(activeOnly = true) {
    const result = await db.query(`
      SELECT c.*, s.name AS season_name,
        COUNT(DISTINCT t.id) AS team_count,
        COUNT(DISTINCT m.id) AS match_count
      FROM competitions c
      LEFT JOIN seasons s ON s.id = c.season_id
      LEFT JOIN teams t ON t.competition_id = c.id AND t.is_active = TRUE
      LEFT JOIN matches m ON m.competition_id = c.id
      ${activeOnly ? 'WHERE c.is_active = TRUE' : ''}
      GROUP BY c.id, s.name
      ORDER BY c.sort_order ASC, c.name ASC
    `);
    return result.rows;
  },

  async getCompetition(idOrSlug: string) {
    const result = await db.query(`
      SELECT c.*, s.name AS season_name, s.year_start, s.year_end
      FROM competitions c
      LEFT JOIN seasons s ON s.id = c.season_id
      WHERE c.id = $1 OR c.slug = $1
    `, [idOrSlug]);
    if (!result.rows.length) throw new AppError('Compétition introuvable.', 404);
    return result.rows[0];
  },

  async createCompetition(data: any): Promise<string> {
    const result = await db.query(`
      INSERT INTO competitions (name, slug, description, logo_url, banner_url, country, region, format, season_id, sort_order)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id
    `, [data.name, data.slug, data.description||null, data.logoUrl||null, data.bannerUrl||null,
        data.country||'Togo', data.region||null, data.format||'league', data.seasonId||null, data.sortOrder||0]);
    return result.rows[0].id;
  },

  async updateCompetition(id: string, data: any) {
    const fields = Object.entries({
      name: data.name, slug: data.slug, description: data.description,
      logo_url: data.logoUrl, is_active: data.isActive, sort_order: data.sortOrder,
    }).filter(([_, v]) => v !== undefined);
    if (!fields.length) return;
    const sets = fields.map(([k], i) => `${k} = $${i+2}`).join(', ');
    await db.query(`UPDATE competitions SET ${sets} WHERE id = $1`,
      [id, ...fields.map(([_, v]) => v)]);
  },

  /** Classement d'une compétition */
  async getStandings(competitionId: string, seasonId?: string) {
    let query = `
      SELECT s.*, t.name AS team_name, t.short_name, t.logo_url
      FROM standings s
      JOIN teams t ON t.id = s.team_id
      WHERE s.competition_id = $1
    `;
    const params: any[] = [competitionId];

    if (seasonId) {
      query += ` AND s.season_id = $2`;
      params.push(seasonId);
    } else {
      query += ` AND s.season_id = (SELECT id FROM seasons WHERE is_current = TRUE LIMIT 1)`;
    }

    query += ` ORDER BY s.points DESC, s.goal_difference DESC, s.goals_for DESC`;
    const result = await db.query(query, params);
    return result.rows;
  },

  /** Recalculer le classement depuis les matchs terminés */
  async recalculateStandings(competitionId: string, seasonId: string): Promise<void> {
    await db.transaction(async (client) => {
      // Reset
      await client.query(
        'DELETE FROM standings WHERE competition_id = $1 AND season_id = $2',
        [competitionId, seasonId]
      );

      // Insérer toutes les équipes
      await client.query(`
        INSERT INTO standings (competition_id, season_id, team_id)
        SELECT DISTINCT $1, $2, home_team_id FROM matches WHERE competition_id = $1 AND season_id = $2
        UNION
        SELECT DISTINCT $1, $2, away_team_id FROM matches WHERE competition_id = $1 AND season_id = $2
        ON CONFLICT DO NOTHING
      `, [competitionId, seasonId]);

      // Résultats domicile
      await client.query(`
        UPDATE standings st SET
          played = played + sub.cnt,
          won    = won + sub.won,
          drawn  = drawn + sub.drawn,
          lost   = lost + sub.lost,
          goals_for = goals_for + sub.gf,
          goals_against = goals_against + sub.ga,
          points = points + sub.pts
        FROM (
          SELECT home_team_id AS team_id,
            COUNT(*) AS cnt,
            SUM(CASE WHEN home_score > away_score THEN 1 ELSE 0 END) AS won,
            SUM(CASE WHEN home_score = away_score THEN 1 ELSE 0 END) AS drawn,
            SUM(CASE WHEN home_score < away_score THEN 1 ELSE 0 END) AS lost,
            SUM(home_score) AS gf, SUM(away_score) AS ga,
            SUM(CASE WHEN home_score > away_score THEN 3 WHEN home_score = away_score THEN 1 ELSE 0 END) AS pts
          FROM matches
          WHERE competition_id = $1 AND season_id = $2 AND status = 'finished'
          GROUP BY home_team_id
        ) sub
        WHERE st.team_id = sub.team_id AND st.competition_id = $1 AND st.season_id = $2
      `, [competitionId, seasonId]);

      // Résultats extérieur
      await client.query(`
        UPDATE standings st SET
          played = played + sub.cnt,
          won    = won + sub.won,
          drawn  = drawn + sub.drawn,
          lost   = lost + sub.lost,
          goals_for = goals_for + sub.gf,
          goals_against = goals_against + sub.ga,
          points = points + sub.pts
        FROM (
          SELECT away_team_id AS team_id,
            COUNT(*) AS cnt,
            SUM(CASE WHEN away_score > home_score THEN 1 ELSE 0 END) AS won,
            SUM(CASE WHEN away_score = home_score THEN 1 ELSE 0 END) AS drawn,
            SUM(CASE WHEN away_score < home_score THEN 1 ELSE 0 END) AS lost,
            SUM(away_score) AS gf, SUM(home_score) AS ga,
            SUM(CASE WHEN away_score > home_score THEN 3 WHEN away_score = home_score THEN 1 ELSE 0 END) AS pts
          FROM matches
          WHERE competition_id = $1 AND season_id = $2 AND status = 'finished'
          GROUP BY away_team_id
        ) sub
        WHERE st.team_id = sub.team_id AND st.competition_id = $1 AND st.season_id = $2
      `, [competitionId, seasonId]);
    });
  },
};

export const teamService = {

  async listTeams(competitionId?: string) {
    const result = await db.query(`
      SELECT t.*, c.name AS comp_name
      FROM teams t
      LEFT JOIN competitions c ON c.id = t.competition_id
      ${competitionId ? 'WHERE t.competition_id = $1 AND t.is_active = TRUE' : 'WHERE t.is_active = TRUE'}
      ORDER BY t.name ASC
    `, competitionId ? [competitionId] : []);
    return result.rows;
  },

  async getTeam(id: string) {
    const [teamRes, matchesRes] = await Promise.all([
      db.query(`
        SELECT t.*, c.name AS comp_name, c.id AS comp_id
        FROM teams t LEFT JOIN competitions c ON c.id = t.competition_id
        WHERE t.id = $1
      `, [id]),
      db.query(`
        SELECT m.id, m.scheduled_at, m.status, m.home_score, m.away_score,
          ht.name AS home_name, ht.logo_url AS home_logo,
          at.name AS away_name, at.logo_url AS away_logo,
          c.name AS comp_name
        FROM matches m
        JOIN teams ht ON ht.id = m.home_team_id
        JOIN teams at ON at.id = m.away_team_id
        JOIN competitions c ON c.id = m.competition_id
        WHERE (m.home_team_id = $1 OR m.away_team_id = $1)
          AND m.scheduled_at > NOW() - INTERVAL '60 days'
        ORDER BY m.scheduled_at DESC
        LIMIT 10
      `, [id]),
    ]);

    if (!teamRes.rows.length) throw new AppError('Équipe introuvable.', 404);
    return { ...teamRes.rows[0], recentMatches: matchesRes.rows };
  },

  async createTeam(data: any): Promise<string> {
    const result = await db.query(`
      INSERT INTO teams (name, short_name, logo_url, city, stadium, founded_year, description, competition_id)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id
    `, [data.name, data.shortName||null, data.logoUrl||null, data.city||null,
        data.stadium||null, data.foundedYear||null, data.description||null, data.competitionId||null]);
    return result.rows[0].id;
  },

  async updateTeam(id: string, data: any) {
    const map: Record<string,string> = {
      name:'name', shortName:'short_name', logoUrl:'logo_url', city:'city',
      stadium:'stadium', foundedYear:'founded_year', competitionId:'competition_id', isActive:'is_active'
    };
    const fields = Object.entries(data)
      .filter(([k, v]) => map[k] !== undefined && v !== undefined)
      .map(([k, v]) => ({ col: map[k], val: v }));
    if (!fields.length) return;
    const sets = fields.map((f, i) => `${f.col} = $${i+2}`).join(', ');
    await db.query(`UPDATE teams SET ${sets} WHERE id = $1`, [id, ...fields.map(f => f.val)]);
  },
};

export const seasonService = {
  async list() {
    const result = await db.query('SELECT * FROM seasons ORDER BY year_start DESC');
    return result.rows;
  },
  async create(data: { name: string; yearStart: number; yearEnd: number; isCurrent?: boolean }) {
    if (data.isCurrent) {
      await db.query('UPDATE seasons SET is_current = FALSE WHERE is_current = TRUE');
    }
    const result = await db.query(
      'INSERT INTO seasons (name, year_start, year_end, is_current) VALUES ($1,$2,$3,$4) RETURNING id',
      [data.name, data.yearStart, data.yearEnd, data.isCurrent ?? false]
    );
    return result.rows[0].id;
  },
};
