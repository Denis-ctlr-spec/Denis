'use client';

import { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';
import { api } from '@/lib/api';
import { useAuthStore } from '@/lib/auth.store';
import { 
  Play, Pause, Volume2, VolumeX, Maximize, 
  Settings, AlertCircle, RefreshCw, Radio 
} from 'lucide-react';

interface SecuredPlayerProps {
  matchId: string;
  isFree?: boolean;
  onUnauthorized?: () => void;
}

export function SecuredPlayer({ matchId, isFree = false, onUnauthorized }: SecuredPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<Hls | null>(null);

  const { user } = useAuthStore();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // États de contrôle du player
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [qualities, setQualities] = useState<{ id: number; label: string; height: number }[]>([]);
  const [currentQuality, setCurrentQuality] = useState<number>(-1); // -1 = Auto
  const [showControls, setShowControls] = useState(true);
  const [deviceFingerprint, setDeviceFingerprint] = useState<string>('');

  // Générer ou récupérer une empreinte d'appareil stable (localStorage)
  useEffect(() => {
    let fp = localStorage.getItem('boxplus_fp');
    if (!fp) {
      fp = 'dev_' + Math.random().toString(36).substring(2, 12) + '_' + Date.now().toString(36);
      localStorage.setItem('boxplus_fp', fp);
    }
    setDeviceFingerprint(fp);
  }, []);

  // Initialisation du flux sécurisé avec token HMAC
  useEffect(() => {
    if (!matchId || !deviceFingerprint) return;

    let heartbeatTimer: NodeJS.Timeout;

    const initStream = async () => {
      setLoading(true);
      setError(null);

      try {
        // Demande d'accès et de token sécurisé
        const res = await api.post('/stream/access', {
          matchId,
          deviceFingerprint,
        });

        const { hlsUrl } = res.data;

        // Configuration de Hls.js
        if (Hls.isSupported() && videoRef.current) {
          if (hlsRef.current) {
            hlsRef.current.destroy();
          }

          const hls = new Hls({
            enableWorker: true,
            lowLatencyMode: true,
            backBufferLength: 60,
            liveSyncDuration: 3,
            liveMaxLatencyDuration: 10,
          });

          hlsRef.current = hls;
          hls.loadSource(hlsUrl);
          hls.attachMedia(videoRef.current);

          hls.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
            setLoading(false);
            // Récupérer les niveaux de qualité disponibles (ex: 360p, 720p, 1080p)
            const levels = data.levels.map((lvl, index) => ({
              id: index,
              label: `${lvl.height}p`,
              height: lvl.height,
            }));
            setQualities(levels);
            videoRef.current?.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
          });

          hls.on(Hls.Events.ERROR, (event, data) => {
            if (data.fatal) {
              switch (data.type) {
                case Hls.ErrorTypes.NETWORK_ERROR:
                  if (data.response?.code === 403) {
                    setError('Accès au flux révoqué : session expirée ou ouverte ailleurs.');
                    if (onUnauthorized) onUnauthorized();
                  } else {
                    hls.startLoad();
                  }
                  break;
                case Hls.ErrorTypes.MEDIA_ERROR:
                  hls.recoverMediaError();
                  break;
                default:
                  hls.destroy();
                  setError('Impossible de lire le flux de diffusion.');
                  break;
              }
            }
          });

          // Heartbeat toutes les 25 secondes
          heartbeatTimer = setInterval(() => {
            api.post('/stream/ping', { matchId, deviceFingerprint }).catch(() => {});
          }, 25000);

        } else if (videoRef.current?.canPlayType('application/vnd.apple.mpegurl')) {
          // Safari iOS natif
          videoRef.current.src = hlsUrl;
          videoRef.current.addEventListener('loadedmetadata', () => {
            setLoading(false);
            videoRef.current?.play();
            setIsPlaying(true);
          });
        }
      } catch (err: any) {
        setLoading(false);
        const msg = err.response?.data?.error || 'Erreur d\'accès au flux vidéo.';
        setError(msg);
        if (err.response?.status === 403 && onUnauthorized) {
          onUnauthorized();
        }
      }
    };

    initStream();

    return () => {
      if (heartbeatTimer) clearInterval(heartbeatTimer);
      if (hlsRef.current) hlsRef.current.destroy();
      // Quitter la session
      api.post('/stream/leave', { matchId, deviceFingerprint }).catch(() => {});
    };
  }, [matchId, deviceFingerprint]);

  // Contrôles
  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const changeQuality = (levelIndex: number) => {
    if (!hlsRef.current) return;
    hlsRef.current.currentLevel = levelIndex; // -1 pour Auto
    setCurrentQuality(levelIndex);
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={() => setShowControls(true)}
      onMouseLeave={() => setShowControls(false)}
      className="relative aspect-video bg-black rounded-2xl overflow-hidden border border-brand-gray group select-none flex items-center justify-center"
    >
      {/* Lecteur Vidéo */}
      <video
        ref={videoRef}
        playsInline
        className="w-full h-full object-contain cursor-pointer"
        onClick={togglePlay}
      />

      {/* FILIGRANE DYNAMIQUE ANTI-LEAK (Numéro ou Email du compte) */}
      {user && (
        <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-sm border border-brand-gray/80 px-2.5 py-1 rounded text-[10px] text-gray-400 font-mono pointer-events-none tracking-wider">
          BOX+ TG • {user.phone || user.email}
        </div>
      )}

      {/* Indicateur DIRECT */}
      <div className="absolute top-4 left-4 flex items-center gap-2 bg-red-600/90 text-white text-[11px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full shadow-lg pointer-events-none">
        <span className="w-2 h-2 rounded-full bg-white live-dot"></span>
        DIRECT
      </div>

      {/* SPINNER DE CHARGEMENT */}
      {loading && (
        <div className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center gap-3">
          <div className="w-10 h-10 border-4 border-brand-orange border-t-transparent rounded-full animate-spin"></div>
          <span className="text-xs text-brand-gray-light font-medium">Chargement du direct optimisé...</span>
        </div>
      )}

      {/* ERREUR D'ABONNEMENT OU STREAMING */}
      {error && (
        <div className="absolute inset-0 bg-black/90 p-6 flex flex-col items-center justify-center text-center space-y-4">
          <AlertCircle className="w-12 h-12 text-brand-orange" />
          <h4 className="text-lg font-bold text-white max-w-md">{error}</h4>
          <button
            onClick={() => window.location.reload()}
            className="inline-flex items-center gap-2 bg-brand-orange hover:bg-brand-orange-dark text-white font-bold text-xs px-5 py-2.5 rounded-xl transition-all"
          >
            <RefreshCw size={14} /> Réessayer
          </button>
        </div>
      )}

      {/* BARRE DE CONTRÔLES EN BAS */}
      {!loading && !error && (
        <div
          className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/70 to-transparent p-4 transition-opacity duration-300 flex items-center justify-between gap-4 ${
            showControls ? 'opacity-100' : 'opacity-0'
          }`}
        >
          {/* Gauche : Play & Volume */}
          <div className="flex items-center gap-3">
            <button
              onClick={togglePlay}
              className="text-white hover:text-brand-orange transition-colors"
            >
              {isPlaying ? <Pause size={20} /> : <Play size={20} fill="currentColor" />}
            </button>

            <button
              onClick={toggleMute}
              className="text-white hover:text-brand-orange transition-colors"
            >
              {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
            </button>
          </div>

          {/* Droite : Qualité adaptative & Plein écran */}
          <div className="flex items-center gap-3 text-xs">
            {/* Sélecteur de qualité */}
            {qualities.length > 0 && (
              <div className="flex items-center gap-1.5 bg-black/60 border border-brand-gray rounded-lg px-2 py-1">
                <Settings size={13} className="text-brand-orange" />
                <select
                  value={currentQuality}
                  onChange={(e) => changeQuality(parseInt(e.target.value))}
                  className="bg-transparent text-white text-xs focus:outline-none cursor-pointer"
                >
                  <option value={-1} className="bg-brand-black-2">Auto (Adaptatif)</option>
                  {qualities.map((q) => (
                    <option key={q.id} value={q.id} className="bg-brand-black-2">
                      {q.label}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <button
              onClick={toggleFullscreen}
              className="text-white hover:text-brand-orange transition-colors"
            >
              <Maximize size={18} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
