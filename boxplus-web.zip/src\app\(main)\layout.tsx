import { Navbar } from '@/components/layout/Navbar';

export default function MainLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-brand-black">
      <Navbar />
      <main className="pb-20 md:pb-0">
        {children}
      </main>
      <footer className="hidden md:block border-t border-brand-gray mt-16">
        <div className="max-w-7xl mx-auto px-6 py-8 text-center text-brand-gray-text text-sm">
          <p>© {new Date().getFullYear()} BOX+ — Football en streaming · Lomé, Togo</p>
          <div className="flex justify-center gap-6 mt-3">
            <a href="/cgu" className="hover:text-white transition-colors">CGU</a>
            <a href="/confidentialite" className="hover:text-white transition-colors">Confidentialité</a>
            <a href="mailto:support@boxplus.tg" className="hover:text-white transition-colors">Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
