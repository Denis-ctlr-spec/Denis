'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Mail, ArrowLeft } from 'lucide-react';
import { authApi } from '@/lib/api';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';

const schema = z.object({
  email: z.string().email('Email invalide'),
});

export default function ForgotPasswordPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [serverError, setServerError] = useState('');

  const { register, handleSubmit, getValues, formState: { errors } } = useForm({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: { email: string }) => {
    setServerError('');
    setIsLoading(true);
    try {
      await authApi.forgotPassword(data.email);
      setSent(true);
    } catch {
      setServerError('Une erreur est survenue. Réessayez.');
    } finally {
      setIsLoading(false);
    }
  };

  if (sent) {
    return (
      <div className="text-center animate-fade-in">
        <div className="w-16 h-16 bg-brand-orange/10 border border-brand-orange/30 rounded-full flex items-center justify-center mx-auto mb-6">
          <Mail className="text-brand-orange" size={28} />
        </div>
        <h2 className="text-2xl font-bold mb-3">Email envoyé !</h2>
        <p className="text-brand-gray-text mb-2 leading-relaxed">
          Si un compte est associé à{' '}
          <span className="text-white font-medium">{getValues('email')}</span>,
          vous recevrez un lien de réinitialisation.
        </p>
        <p className="text-sm text-brand-gray-text mb-8">
          Vérifiez aussi vos spams.
        </p>
        <Link href="/login">
          <Button variant="secondary" fullWidth>
            <ArrowLeft size={16} />
            Retour à la connexion
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <>
      <div className="mb-8">
        <Link href="/login" className="inline-flex items-center gap-2 text-brand-gray-text hover:text-white text-sm mb-6 transition-colors">
          <ArrowLeft size={16} />
          Retour
        </Link>
        <h1 className="text-3xl font-bold font-display">Mot de passe oublié</h1>
        <p className="text-brand-gray-text mt-2">
          Entrez votre email pour recevoir un lien de réinitialisation.
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
        <Input
          label="Adresse email"
          type="email"
          placeholder="vous@exemple.com"
          icon={<Mail size={16} />}
          error={errors.email?.message}
          autoComplete="email"
          {...register('email')}
        />

        {serverError && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-sm text-red-400">
            {serverError}
          </div>
        )}

        <Button type="submit" fullWidth size="lg" loading={isLoading}>
          {isLoading ? 'Envoi en cours...' : 'Envoyer le lien'}
        </Button>
      </form>
    </>
  );
}
