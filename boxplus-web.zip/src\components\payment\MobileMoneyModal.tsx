'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import { 
  Smartphone, ShieldCheck, X, CheckCircle, 
  CreditCard, AlertCircle, Loader2 
} from 'lucide-react';
import { formatPrice } from '@/lib/utils';
import { useAuthStore } from '@/lib/auth.store';

interface MobileMoneyModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: any;
}

export function MobileMoneyModal({ isOpen, onClose, plan }: MobileMoneyModalProps) {
  const router = useRouter();
  const { user } = useAuthStore();

  const [paymentMethod, setPaymentMethod] = useState<'tmoney' | 'flooz' | 'card'>('tmoney');
  const [phoneNumber, setPhoneNumber] = useState(user?.phone || '');
  const [promoCode, setPromoCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen || !plan) return null;

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (paymentMethod !== 'card' && !phoneNumber) {
      setError('Veuillez renseigner votre numéro de téléphone Mobile Money.');
      return;
    }

    setLoading(true);
    try {
      const res = await api.post('/payments/checkout', {
        planId: plan.id,
        paymentMethod,
        phoneNumber,
        promoCode: promoCode || undefined,
      });

      const { paymentId, checkoutUrl, isDemo } = res.data;

      if (isDemo) {
        // Redirection vers confirmation simulation sandbox
        router.push(`/abonnement/confirmation?payment_id=${paymentId}&demo=true`);
      } else if (checkoutUrl) {
        // Redirection vers passerelle officielle FedaPay
        window.location.href = checkoutUrl;
      }
    } catch (err: any) {
      setError(err.response?.data?.error || 'Erreur lors de l\'initialisation du paiement.');
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-brand-black-2 border border-brand-gray rounded-3xl max-w-md w-full overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        
        {/* Entête */}
        <div className="p-6 border-b border-brand-gray flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-brand-orange/15 text-brand-orange flex items-center justify-center">
              <Smartphone size={18} />
            </div>
            <div>
              <h3 className="font-bold font-display text-base text-white">Règlement Sécurisé</h3>
              <p className="text-[11px] text-brand-gray-text">Agrégation FedaPay Togo</p>
            </div>
          </div>

          <button onClick={onClose} className="text-brand-gray-text hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Détail de la commande */}
        <div className="p-6 space-y-5">
          <div className="bg-brand-black-3 border border-brand-gray/80 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <span className="text-xs text-brand-gray-text block">Formule sélectionnée :</span>
              <span className="font-bold text-white text-base">{plan.name}</span>
            </div>
            <div className="text-right">
              <span className="text-lg font-black font-display text-brand-orange block">
                {formatPrice(parseFloat(plan.price))}
              </span>
              <span className="text-[10px] text-emerald-400 font-semibold">TTC • XOF</span>
            </div>
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/30 text-red-400 p-3 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle size={14} className="shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleCheckout} className="space-y-4">
            
            {/* Choix de l'opérateur */}
            <div>
              <label className="block text-xs font-semibold text-brand-gray-text mb-2">
                Sélectionnez votre moyen de paiement :
              </label>

              <div className="grid grid-cols-2 gap-2.5">
                {/* T-Money (Togocom) */}
                <label className={`border rounded-2xl p-3 flex items-center gap-3 cursor-pointer transition-all ${
                  paymentMethod === 'tmoney'
                    ? 'border-brand-orange bg-brand-orange/10'
                    : 'border-brand-gray bg-brand-black-3 hover:border-brand-gray/80'
                }`}>
                  <input
                    type="radio"
                    name="method"
                    value="tmoney"
                    checked={paymentMethod === 'tmoney'}
                    onChange={() => setPaymentMethod('tmoney')}
                    className="accent-brand-orange"
                  />
                  <div>
                    <span className="block text-xs font-bold text-white">T-Money</span>
                    <span className="text-[10px] text-yellow-400 font-semibold">Togocom (*145#)</span>
                  </div>
                </label>

                {/* Flooz (Moov Africa) */}
                <label className={`border rounded-2xl p-3 flex items-center gap-3 cursor-pointer transition-all ${
                  paymentMethod === 'flooz'
                    ? 'border-brand-orange bg-brand-orange/10'
                    : 'border-brand-gray bg-brand-black-3 hover:border-brand-gray/80'
                }`}>
                  <input
                    type="radio"
                    name="method"
                    value="flooz"
                    checked={paymentMethod === 'flooz'}
                    onChange={() => setPaymentMethod('flooz')}
                    className="accent-brand-orange"
                  />
                  <div>
                    <span className="block text-xs font-bold text-white">Flooz</span>
                    <span className="text-[10px] text-blue-400 font-semibold">Moov (*155#)</span>
                  </div>
                </label>
              </div>
            </div>

            {/* Numéro de téléphone Mobile Money */}
            <div>
              <label className="block text-xs font-semibold text-brand-gray-text mb-1.5">
                Numéro Mobile Money (Togo) :
              </label>
              <input
                type="tel"
                required
                placeholder="+228 90 12 34 56"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-4 py-3 text-sm text-white placeholder-brand-gray-text focus:outline-none focus:border-brand-orange"
              />
              <span className="text-[10px] text-brand-gray-text mt-1 block">
                Un message push USSD s'affichera sur votre écran de téléphone pour valider avec votre code PIN secret.
              </span>
            </div>

            {/* Code Promo */}
            <div>
              <label className="block text-xs font-semibold text-brand-gray-text mb-1">
                Code Promo / Réduction (optionnel) :
              </label>
              <input
                type="text"
                placeholder="Ex: TOGOFOOT20"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-4 py-2 text-xs text-white uppercase focus:outline-none focus:border-brand-orange"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-brand-orange hover:bg-brand-orange-dark disabled:opacity-50 text-white font-bold text-sm py-3.5 rounded-xl shadow-lg shadow-brand-orange/20 transition-all flex items-center justify-center gap-2 mt-4"
            >
              {loading ? (
                <>
                  <Loader2 size={16} className="animate-spin" />
                  <span>Initialisation FedaPay...</span>
                </>
              ) : (
                <>
                  <ShieldCheck size={16} />
                  <span>Confirmer et Payer {formatPrice(parseFloat(plan.price))}</span>
                </>
              )}
            </button>
          </form>
        </div>

      </div>
    </div>
  );
}
