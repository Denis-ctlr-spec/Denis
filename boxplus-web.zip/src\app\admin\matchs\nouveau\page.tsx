'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import Link from 'next/link';
import { ArrowLeft, Calendar, Save } from 'lucide-react';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';

export default function NewMatchPage() {
  const router = useRouter();
  const [competitions, setCompetitions] = useState<any[]>([]);
  const [teams, setTeams] = useState<any[]>([]);
  const [seasons, setSeasons] = useState<any[]>([]);

  const [competitionId, setCompetitionId] = useState('');
  const [seasonId, setSeasonId] = useState('');
  const [homeTeamId, setHomeTeamId] = useState('');
  const [awayTeamId, setAwayTeamId] = useState('');
  const [scheduledAt, setScheduledAt] = useState('');
  const [matchday, setMatchday] = useState('1');
  const [isFree, setIsFree] = useState(false);
  const [isFeatured, setIsFeatured] = useState(false);
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([
      api.get('/competitions'),
      api.get('/teams'),
      api.get('/admin/seasons'),
    ]).then(([compRes, teamRes, seasonRes]) => {
      setCompetitions(compRes.data.competitions || []);
      setTeams(teamRes.data.teams || []);
      setSeasons(seasonRes.data.seasons || []);

      if (compRes.data.competitions?.length > 0) {
        setCompetitionId(compRes.data.competitions[0].id);
      }
      if (seasonRes.data.seasons?.length > 0) {
        setSeasonId(seasonRes.data.seasons[0].id);
      }
      if (teamRes.data.teams?.length > 1) {
        setHomeTeamId(teamRes.data.teams[0].id);
        setAwayTeamId(teamRes.data.teams[1].id);
      }
    });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (homeTeamId === awayTeamId) {
      setError('L\'équipe domicile et l\'équipe extérieure doivent être différentes.');
      return;
    }

    if (!scheduledAt) {
      setError('Veuillez renseigner la date et l\'heure du match.');
      return;
    }

    setLoading(true);
    try {
      await api.post('/admin/matches', {
        competitionId,
        seasonId: seasonId || undefined,
        homeTeamId,
        awayTeamId,
        scheduledAt: new Date(scheduledAt).toISOString(),
        matchday: parseInt(matchday) || 1,
        isFree,
        isFeatured,
      });
      router.push('/admin/direct');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Erreur lors de la création du match.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Link
        href="/admin"
        className="inline-flex items-center gap-2 text-sm text-brand-gray-text hover:text-white"
      >
        <ArrowLeft size={16} /> Retour à la console
      </Link>

      <div className="bg-brand-black-2 border border-brand-gray rounded-2xl p-6 md:p-8 space-y-6">
        <div>
          <h1 className="text-2xl font-black font-display">Programmer un Nouveau Match</h1>
          <p className="text-xs text-brand-gray-text mt-1">
            Une clé de stream RTMP unique sera automatiquement générée pour la diffusion OBS.
          </p>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 text-red-400 p-4 rounded-xl text-xs">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Compétition & Saison */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-brand-gray-text mb-1">Compétition :</label>
              <select
                value={competitionId}
                onChange={(e) => setCompetitionId(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-brand-orange"
              >
                {competitions.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-brand-gray-text mb-1">Saison :</label>
              <select
                value={seasonId}
                onChange={(e) => setSeasonId(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-brand-orange"
              >
                {seasons.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Équipes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-brand-gray-text mb-1">Équipe Domicile :</label>
              <select
                value={homeTeamId}
                onChange={(e) => setHomeTeamId(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-brand-orange"
              >
                {teams.map((t) => (
                  <option key={t.id} value={t.id}>{t.name} ({t.city || 'Togo'})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-brand-gray-text mb-1">Équipe Extérieure :</label>
              <select
                value={awayTeamId}
                onChange={(e) => setAwayTeamId(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-brand-orange"
              >
                {teams.map((t) => (
                  <option key={t.id} value={t.id}>{t.name} ({t.city || 'Togo'})</option>
                ))}
              </select>
            </div>
          </div>

          {/* Date & Journée */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-brand-gray-text mb-1">Date et Heure du coup d'envoi :</label>
              <input
                type="datetime-local"
                required
                value={scheduledAt}
                onChange={(e) => setScheduledAt(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-brand-orange"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-brand-gray-text mb-1">Journée de championnat :</label>
              <input
                type="number"
                min="1"
                value={matchday}
                onChange={(e) => setMatchday(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-brand-orange"
              />
            </div>
          </div>

          {/* Options gratuites / à la une */}
          <div className="flex flex-col gap-2 pt-2">
            <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
              <input
                type="checkbox"
                checked={isFree}
                onChange={(e) => setIsFree(e.target.checked)}
                className="rounded border-brand-gray text-brand-orange accent-brand-orange w-4 h-4"
              />
              <span>Match Gratuit (accessible sans abonnement)</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
              <input
                type="checkbox"
                checked={isFeatured}
                onChange={(e) => setIsFeatured(e.target.checked)}
                className="rounded border-brand-gray text-brand-orange accent-brand-orange w-4 h-4"
              />
              <span>Mettre à la une sur la page d'accueil (Hero)</span>
            </label>
          </div>

          <Button type="submit" fullWidth size="lg" loading={loading} className="mt-4">
            <Save size={16} /> Créer le match et générer la clé
          </Button>
        </form>
      </div>
    </div>
  );
}
