'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Eye, EyeOff, Mail, Lock } from 'lucide-react';
import { useAuthStore } from '@/lib/auth.store';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';

const loginSchema = z.object({
  email: z.string().email('Email invalide'),
  password: z.string().min(1, 'Mot de passe requis'),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function LoginPage() {
  const router = useRouter();
  const { login, isLoading } = useAuthStore();
  const [showPassword, setShowPassword] = useState(false);
  const [serverError, setServerError] = useState('');

  const { register, handleSubmit, formState: { errors } } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data: LoginForm) => {
    setServerError('');
    try {
      await login(data.email, data.password);
      router.replace('/');
    } catch (err: any) {
      setServerError(err.response?.data?.error || 'Une erreur est survenue. Réessayez.');
    }
  };

  return (
    <>
      <div className="mb-8">
        <h1 className="text-3xl font-bold font-display">Connexion</h1>
        <p className="text-brand-gray-text mt-2">
          Pas encore de compte ?{' '}
          <Link href="/register" className="text-brand-orange hover:text-brand-orange-light font-medium">
            Inscrivez-vous gratuitement
          </Link>
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
        <Input
          label="Adresse email"
          type="email"
          placeholder="vous@exemple.com"
          icon={<Mail size={16} />}
          error={errors.email?.message}
          autoComplete="email"
          {...register('email')}
        />

        <Input
          label="Mot de passe"
          type={showPassword ? 'text' : 'password'}
          placeholder="••••••••"
          icon={<Lock size={16} />}
          error={errors.password?.message}
          autoComplete="current-password"
          rightElement={
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="text-brand-gray-text hover:text-white transition-colors"
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          }
          {...register('password')}
        />

        <div className="flex justify-end">
          <Link href="/forgot-password" className="text-sm text-brand-gray-text hover:text-white transition-colors">
            Mot de passe oublié ?
          </Link>
        </div>

        {serverError && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-sm text-red-400">
            {serverError}
          </div>
        )}

        <Button type="submit" fullWidth size="lg" loading={isLoading}>
          {isLoading ? 'Connexion en cours...' : 'Se connecter'}
        </Button>
      </form>

      {/* Séparateur */}
      <div className="relative my-6">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-brand-gray" />
        </div>
        <div className="relative flex justify-center text-xs">
          <span className="px-3 bg-brand-black text-brand-gray-text">ou</span>
        </div>
      </div>

      <p className="text-center text-xs text-brand-gray-text leading-relaxed">
        En vous connectant, vous acceptez nos{' '}
        <Link href="/cgu" className="text-brand-orange hover:underline">CGU</Link>{' '}
        et notre{' '}
        <Link href="/confidentialite" className="text-brand-orange hover:underline">Politique de confidentialité</Link>.
      </p>
    </>
  );
}
