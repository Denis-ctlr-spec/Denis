'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import { 
  Play, Square, RefreshCw, Copy, Check, Radio, 
  Send, AlertCircle, Plus, Trash2 
} from 'lucide-react';

export default function AdminLiveControlPage() {
  const [matches, setMatches] = useState<any[]>([]);
  const [selectedMatch, setSelectedMatch] = useState<any>(null);
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  
  // Scores & Chrono
  const [homeScore, setHomeScore] = useState(0);
  const [awayScore, setAwayScore] = useState(0);
  const [minute, setMinute] = useState(0);

  // Nouvel événement
  const [eventType, setEventType] = useState('goal');
  const [eventPlayer, setEventPlayer] = useState('');
  const [eventTeamId, setEventTeamId] = useState('');
  const [eventMinute, setEventMinute] = useState(0);

  const [loading, setLoading] = useState(true);
  const [actionMsg, setActionMsg] = useState('');

  const loadMatches = () => {
    setLoading(true);
    api.get('/matches?limit=20')
      .then(res => {
        const list = res.data.matches || [];
        setMatches(list);
        if (list.length > 0 && !selectedMatch) {
          const liveOrFirst = list.find((m: any) => m.status === 'live') || list[0];
          selectMatch(liveOrFirst);
        }
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadMatches();
  }, []);

  const selectMatch = (m: any) => {
    setSelectedMatch(m);
    setHomeScore(m.score?.home ?? 0);
    setAwayScore(m.score?.away ?? 0);
    setMinute(m.minute ?? 0);
    setEventMinute(m.minute ?? 0);
    setEventTeamId(m.homeTeam?.id || '');
  };

  const handleStartLive = async () => {
    if (!selectedMatch) return;
    try {
      await api.post(`/admin/matches/${selectedMatch.id}/start-live`);
      setActionMsg('Direct lancé avec succès sur le serveur HLS !');
      loadMatches();
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur au démarrage du direct');
    }
  };

  const handleStopLive = async () => {
    if (!selectedMatch) return;
    if (!confirm('Arrêter le direct et archiver le match en replay ?')) return;
    try {
      await api.post(`/admin/matches/${selectedMatch.id}/stop-live`);
      setActionMsg('Direct arrêté. Enregistrement sauvegardé.');
      loadMatches();
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur à l\'arrêt du direct');
    }
  };

  const handleUpdateScore = async () => {
    if (!selectedMatch) return;
    try {
      await api.patch(`/admin/matches/${selectedMatch.id}/score`, {
        homeScore,
        awayScore,
        minute,
      });
      setActionMsg('Score et chrono synchronisés en direct avec les spectateurs !');
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur mise à jour score');
    }
  };

  const handleAddEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMatch) return;
    try {
      await api.post(`/admin/matches/${selectedMatch.id}/events`, {
        type: eventType,
        minute: eventMinute,
        playerName: eventPlayer,
        teamId: eventTeamId,
      });
      setEventPlayer('');
      setActionMsg('Événement diffusé sur les écrans spectateurs !');
      // Recharger le match
      const updated = await api.get(`/matches/${selectedMatch.id}`);
      setSelectedMatch(updated.data.match);
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur ajout événement');
    }
  };

  const rtmpUrl = 'rtmp://live.boxplus.tg:1935/live';

  return (
    <div className="space-y-8 max-w-7xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-brand-gray pb-6">
        <div>
          <span className="text-xs font-bold text-brand-orange uppercase tracking-wider">
            Régie de Direct & Ingestion OBS
          </span>
          <h1 className="text-3xl font-black font-display text-white">Console Opérateur</h1>
        </div>

        {/* Sélecteur de match */}
        <div className="flex items-center gap-3">
          <label className="text-xs text-brand-gray-text font-bold uppercase">Sélectionner un match :</label>
          <select
            value={selectedMatch?.id || ''}
            onChange={(e) => {
              const m = matches.find(item => item.id === e.target.value);
              if (m) selectMatch(m);
            }}
            className="bg-brand-black-3 border border-brand-gray text-white text-xs rounded-xl px-4 py-2.5"
          >
            {matches.map((m) => (
              <option key={m.id} value={m.id}>
                {m.status === 'live' ? '🔴 LIVE : ' : ''}
                {m.homeTeam?.shortName || m.homeTeam?.name} vs {m.awayTeam?.shortName || m.awayTeam?.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {actionMsg && (
        <div className="bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 p-4 rounded-xl text-sm flex items-center justify-between">
          <span>{actionMsg}</span>
          <button onClick={() => setActionMsg('')} className="text-xs hover:underline">Fermer</button>
        </div>
      )}

      {selectedMatch ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* COLONNE GAUCHE : CLÉS DE FLUX OBS & CONTRÔLE STREAM */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-brand-black-2 border border-brand-gray rounded-2xl p-6 space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-brand-gray-text flex items-center gap-2">
                <Radio size={16} className="text-brand-orange" />
                1. Configuration OBS / vMix
              </h3>

              {/* URL Ingestion RTMP */}
              <div className="space-y-1">
                <label className="text-xs text-brand-gray-text">URL du serveur RTMP :</label>
                <div className="flex items-center bg-brand-black-3 border border-brand-gray rounded-xl px-3 py-2 text-xs font-mono">
                  <span className="truncate flex-1 text-gray-300">{rtmpUrl}</span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(rtmpUrl);
                      setCopiedUrl(true);
                      setTimeout(() => setCopiedUrl(false), 2000);
                    }}
                    className="text-brand-orange hover:text-white ml-2 flex items-center gap-1"
                  >
                    {copiedUrl ? <Check size={14} /> : <Copy size={14} />}
                  </button>
                </div>
              </div>

              {/* Clé de stream */}
              <div className="space-y-1">
                <label className="text-xs text-brand-gray-text">Clé de stream du match :</label>
                <div className="flex items-center bg-brand-black-3 border border-brand-gray rounded-xl px-3 py-2 text-xs font-mono">
                  <span className="truncate flex-1 text-gray-300">
                    {selectedMatch.streamKey || 'Non générée'}
                  </span>
                  <button
                    onClick={() => {
                      if (selectedMatch.streamKey) {
                        navigator.clipboard.writeText(selectedMatch.streamKey);
                        setCopiedKey(true);
                        setTimeout(() => setCopiedKey(false), 2000);
                      }
                    }}
                    className="text-brand-orange hover:text-white ml-2 flex items-center gap-1"
                  >
                    {copiedKey ? <Check size={14} /> : <Copy size={14} />}
                  </button>
                </div>
              </div>

              {/* Statut du match et boutons d'action */}
              <div className="pt-4 border-t border-brand-gray/60 flex flex-col gap-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-brand-gray-text">Statut de la diffusion :</span>
                  <span className={`font-bold px-2.5 py-0.5 rounded uppercase ${
                    selectedMatch.status === 'live'
                      ? 'bg-red-600 text-white'
                      : selectedMatch.status === 'finished'
                      ? 'bg-brand-gray text-gray-400'
                      : 'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {selectedMatch.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    onClick={handleStartLive}
                    disabled={selectedMatch.status === 'live'}
                    className="bg-red-600 hover:bg-red-700 disabled:opacity-40 text-white font-bold text-xs py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
                  >
                    <Play size={14} fill="currentColor" /> Démarrer le Direct
                  </button>
                  <button
                    onClick={handleStopLive}
                    disabled={selectedMatch.status !== 'live'}
                    className="bg-brand-black-3 hover:bg-brand-gray disabled:opacity-40 border border-brand-gray text-white font-bold text-xs py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
                  >
                    <Square size={14} /> Clôturer & Archiver
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* COLONNE DROITE : CONTRÔLE SCORE, CHRONO & ÉVÉNEMENTS */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Pupitre des Scores */}
            <div className="bg-brand-black-2 border border-brand-gray rounded-2xl p-6 space-y-6">
              <h3 className="text-sm font-bold uppercase tracking-wider text-brand-gray-text">
                2. Pupitre Score & Chronomètre (Temps Réel)
              </h3>

              <div className="grid grid-cols-3 items-center gap-4 py-2">
                {/* Home */}
                <div className="text-center space-y-2">
                  <span className="block font-bold text-sm truncate">
                    {selectedMatch.homeTeam?.name}
                  </span>
                  <div className="flex items-center justify-center gap-2">
                    <button
                      onClick={() => setHomeScore(Math.max(0, homeScore - 1))}
                      className="w-9 h-9 rounded-xl bg-brand-black-3 border border-brand-gray font-bold text-base hover:bg-brand-gray"
                    >
                      -
                    </button>
                    <span className="text-4xl font-black font-display w-10 text-center">
                      {homeScore}
                    </span>
                    <button
                      onClick={() => setHomeScore(homeScore + 1)}
                      className="w-9 h-9 rounded-xl bg-brand-orange text-white font-bold text-base hover:bg-brand-orange-dark"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Minute & Séparateur */}
                <div className="text-center space-y-2">
                  <label className="text-xs text-brand-gray-text block">Minute de jeu :</label>
                  <input
                    type="number"
                    min="0"
                    max="130"
                    value={minute}
                    onChange={(e) => setMinute(parseInt(e.target.value) || 0)}
                    className="w-16 bg-brand-black-3 border border-brand-gray rounded-lg px-2 py-1 text-center font-bold text-base text-white mx-auto focus:outline-none focus:border-brand-orange"
                  />
                  <span className="text-xs text-brand-orange font-bold block">Chrono direct</span>
                </div>

                {/* Away */}
                <div className="text-center space-y-2">
                  <span className="block font-bold text-sm truncate">
                    {selectedMatch.awayTeam?.name}
                  </span>
                  <div className="flex items-center justify-center gap-2">
                    <button
                      onClick={() => setAwayScore(Math.max(0, awayScore - 1))}
                      className="w-9 h-9 rounded-xl bg-brand-black-3 border border-brand-gray font-bold text-base hover:bg-brand-gray"
                    >
                      -
                    </button>
                    <span className="text-4xl font-black font-display w-10 text-center">
                      {awayScore}
                    </span>
                    <button
                      onClick={() => setAwayScore(awayScore + 1)}
                      className="w-9 h-9 rounded-xl bg-brand-orange text-white font-bold text-base hover:bg-brand-orange-dark"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>

              <button
                onClick={handleUpdateScore}
                className="w-full bg-brand-orange hover:bg-brand-orange-dark text-white font-bold text-sm py-3 rounded-xl transition-all shadow-lg shadow-brand-orange/20"
              >
                Diffuser le score aux spectateurs (WebSocket)
              </button>
            </div>

            {/* Ajout d'événements */}
            <div className="bg-brand-black-2 border border-brand-gray rounded-2xl p-6 space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-brand-gray-text">
                3. Ajouter un événement officiel
              </h3>

              <form onSubmit={handleAddEvent} className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
                <div>
                  <label className="block text-xs text-brand-gray-text mb-1">Type :</label>
                  <select
                    value={eventType}
                    onChange={(e) => setEventType(e.target.value)}
                    className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="goal">⚽ But</option>
                    <option value="yellow_card">🟨 Carton Jaune</option>
                    <option value="red_card">🟥 Carton Rouge</option>
                    <option value="substitution">🔄 Remplacement</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-brand-gray-text mb-1">Équipe :</label>
                  <select
                    value={eventTeamId}
                    onChange={(e) => setEventTeamId(e.target.value)}
                    className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value={selectedMatch.homeTeam?.id}>{selectedMatch.homeTeam?.name}</option>
                    <option value={selectedMatch.awayTeam?.id}>{selectedMatch.awayTeam?.name}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-brand-gray-text mb-1">Joueur :</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: K. Mensah"
                    value={eventPlayer}
                    onChange={(e) => setEventPlayer(e.target.value)}
                    className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <button
                  type="submit"
                  className="bg-brand-black-3 hover:bg-brand-gray border border-brand-gray text-white font-bold text-xs py-2.5 rounded-xl transition-colors"
                >
                  Ajouter l'événement
                </button>
              </form>
            </div>

          </div>

        </div>
      ) : (
        <div className="p-12 text-center text-brand-gray-text">Aucun match programmé.</div>
      )}
    </div>
  );
}
