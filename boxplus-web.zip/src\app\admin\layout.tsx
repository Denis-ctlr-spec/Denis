'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useAuthStore } from '@/lib/auth.store';
import { 
  LayoutDashboard, Radio, Calendar, Trophy, Users, 
  CreditCard, Tag, ArrowLeft, LogOut, ShieldAlert
} from 'lucide-react';
import { cn } from '@/lib/utils';

const adminNav = [
  { href: '/admin',              label: 'Vue Globale',       icon: LayoutDashboard },
  { href: '/admin/direct',       label: 'Régie & Directs',   icon: Radio },
  { href: '/admin/matchs',       label: 'Matchs & Saisons',  icon: Calendar },
  { href: '/admin/competitions', label: 'Compétitions',     icon: Trophy },
  { href: '/admin/equipes',      label: 'Équipes & Clubs',   icon: ShieldAlert },
  { href: '/admin/utilisateurs', label: 'Utilisateurs',      icon: Users },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, isAuthenticated } = useAuthStore();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  return (
    <div className="min-h-screen bg-brand-black text-white flex flex-col md:flex-row">
      {/* SIDEBAR ADMIN */}
      <aside className="w-full md:w-64 bg-brand-black-2 border-r border-brand-gray flex flex-col shrink-0">
        <div className="p-6 border-b border-brand-gray flex items-center justify-between">
          <Link href="/" className="flex items-center gap-1.5">
            <span className="text-2xl font-black font-display tracking-wider">
              BOX<span className="text-brand-orange">+</span>
            </span>
            <span className="text-[10px] bg-brand-orange text-white font-bold px-1.5 py-0.5 rounded ml-1">
              ADMIN
            </span>
          </Link>
        </div>

        <nav className="p-4 space-y-1.5 flex-1">
          <div className="text-[11px] font-bold uppercase tracking-wider text-brand-gray-text px-3 py-2">
            Gestion & Diffusion
          </div>
          {adminNav.map(({ href, label, icon: Icon }) => {
            const isActive = pathname === href;
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  'flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-colors',
                  isActive
                    ? 'bg-brand-orange text-white'
                    : 'text-brand-gray-text hover:text-white hover:bg-brand-black-3'
                )}
              >
                <Icon size={18} />
                <span>{label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Footer Sidebar */}
        <div className="p-4 border-t border-brand-gray space-y-2">
          <Link
            href="/"
            className="flex items-center gap-2 text-xs text-brand-gray-text hover:text-white px-3 py-2 rounded-lg transition-colors"
          >
            <ArrowLeft size={16} /> Retour au site spectateur
          </Link>
        </div>
      </aside>

      {/* CONTENU PRINCIPAL */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header Admin */}
        <header className="h-16 bg-brand-black-2 border-b border-brand-gray px-6 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-xs text-brand-gray-text">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>Serveur API & SRS Node connecté</span>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <span className="block text-xs font-bold text-white">{user?.fullName || 'Administrateur'}</span>
              <span className="block text-[10px] text-brand-orange uppercase font-semibold">{user?.role || 'Admin'}</span>
            </div>
            <div className="w-9 h-9 rounded-full bg-brand-orange/20 border border-brand-orange/40 flex items-center justify-center text-brand-orange font-bold text-sm">
              A
            </div>
          </div>
        </header>

        <main className="flex-1 p-6 md:p-8 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
