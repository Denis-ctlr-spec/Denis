'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import Cookies from 'js-cookie';
import { authApi } from '@/lib/api';

interface User {
  id: string;
  email: string;
  fullName: string;
  role: string;
  emailVerified: boolean;
  subStatus?: string;
  subPlan?: string;
  subExpires?: string;
}

interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  fetchMe: () => Promise<void>;
  clearAuth: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isLoading: false,
      isAuthenticated: false,

      login: async (email, password) => {
        set({ isLoading: true });
        try {
          const { data } = await authApi.login({ email, password });
          Cookies.set('access_token', data.accessToken, {
            expires: 1 / 96, // 15 minutes
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'Lax',
          });
          set({ user: data.user, isAuthenticated: true, isLoading: false });
        } catch (err) {
          set({ isLoading: false });
          throw err;
        }
      },

      logout: async () => {
        try {
          await authApi.logout();
        } finally {
          Cookies.remove('access_token');
          set({ user: null, isAuthenticated: false });
        }
      },

      fetchMe: async () => {
        try {
          const { data } = await authApi.me();
          set({ user: data.user, isAuthenticated: true });
        } catch {
          Cookies.remove('access_token');
          set({ user: null, isAuthenticated: false });
        }
      },

      clearAuth: () => {
        Cookies.remove('access_token');
        set({ user: null, isAuthenticated: false });
      },
    }),
    {
      name: 'boxplus-auth',
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
);

/** Hook : vérifie si l'utilisateur a un abonnement actif */
export function useHasActiveSubscription() {
  const user = useAuthStore((s) => s.user);
  if (!user?.subStatus) return false;
  if (user.subStatus !== 'active') return false;
  if (!user.subExpires) return false;
  return new Date(user.subExpires) > new Date();
}
