'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import Link from 'next/link';
import { Shield, MapPin, Calendar, Trophy, ArrowLeft } from 'lucide-react';
import { MatchCard } from '@/components/match/MatchCard';

export default function TeamDetailPage() {
  const params = useParams();
  const router = useRouter();
  const teamId = params.id as string;

  const [team, setTeam] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!teamId) return;
    api.get(`/teams/${teamId}`)
      .then(res => setTeam(res.data.team))
      .catch(() => setTeam(null))
      .finally(() => setLoading(false));
  }, [teamId]);

  if (loading) {
    return (
      <div className="min-h-[50vh] flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-brand-orange border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!team) {
    return (
      <div className="max-w-xl mx-auto py-16 text-center space-y-4">
        <Shield className="w-16 h-16 text-brand-gray-text mx-auto opacity-30" />
        <h2 className="text-xl font-bold">Équipe introuvable</h2>
        <button
          onClick={() => router.push('/classements')}
          className="text-sm text-brand-orange hover:underline font-semibold"
        >
          Retour aux classements
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      <button
        onClick={() => router.back()}
        className="inline-flex items-center gap-2 text-sm text-brand-gray-text hover:text-white"
      >
        <ArrowLeft size={16} /> Retour
      </button>

      {/* Profil Équipe */}
      <div className="bg-brand-black-2 border border-brand-gray rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-center md:items-start gap-6 shadow-xl">
        {team.logo_url ? (
          <img
            src={team.logo_url}
            alt={team.name}
            className="w-24 h-24 md:w-32 md:h-32 object-contain bg-brand-black-3 p-3 rounded-2xl border border-brand-gray"
          />
        ) : (
          <div className="w-24 h-24 md:w-32 md:h-32 rounded-2xl bg-brand-black-3 border border-brand-gray flex items-center justify-center text-3xl font-black text-brand-orange">
            {team.short_name?.[0] || team.name[0]}
          </div>
        )}

        <div className="space-y-3 text-center md:text-left flex-1">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-2">
            <span className="text-xs bg-brand-orange/20 text-brand-orange font-bold px-2.5 py-0.5 rounded-full">
              {team.comp_name || 'Championnat National'}
            </span>
            {team.founded_year && (
              <span className="text-xs text-brand-gray-text bg-brand-black-3 px-2 py-0.5 rounded border border-brand-gray">
                Fondé en {team.founded_year}
              </span>
            )}
          </div>

          <h1 className="text-3xl md:text-4xl font-black font-display text-white">{team.name}</h1>

          <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-xs text-brand-gray-light">
            {team.city && (
              <span className="flex items-center gap-1.5">
                <MapPin size={14} className="text-brand-orange" />
                {team.city} (Togo)
              </span>
            )}
            {team.stadium && (
              <span className="flex items-center gap-1.5">
                <Shield size={14} className="text-brand-orange" />
                Stade : {team.stadium}
              </span>
            )}
          </div>

          {team.description && (
            <p className="text-xs text-brand-gray-text leading-relaxed max-w-2xl pt-1">
              {team.description}
            </p>
          )}
        </div>
      </div>

      {/* Matchs récents */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold font-display flex items-center gap-2">
          <Calendar className="text-brand-orange" size={20} />
          Matchs récents & à venir
        </h2>

        {!team.recentMatches || team.recentMatches.length === 0 ? (
          <div className="p-8 text-center text-brand-gray-text bg-brand-black-2 border border-brand-gray rounded-xl">
            Aucun match programmé récemment pour cette équipe.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {team.recentMatches.map((m: any) => (
              <MatchCard key={m.id} match={m} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
