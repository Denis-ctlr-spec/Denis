import Link from 'next/link';
import type { Metadata } from 'next';

export const metadata: Metadata = { title: 'Authentification' };

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-brand-black flex">
      {/* ── Panneau gauche (illust.) — masqué sur mobile ── */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-brand-black-2">
        {/* Pattern de fond */}
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage: 'radial-gradient(circle at 20% 50%, #FF5A1F 0%, transparent 60%)' }} />
        <div className="absolute inset-0"
          style={{ backgroundImage: 'linear-gradient(135deg, #0A0A0A 0%, #1E1E1E 100%)' }} />

        {/* Grille déco */}
        <div className="absolute inset-0 opacity-5"
          style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '60px 60px' }} />

        <div className="relative z-10 flex flex-col justify-between p-12 w-full">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <span className="text-3xl font-black font-display tracking-wider">
              BOX<span className="text-brand-orange">+</span>
            </span>
          </Link>

          {/* Slogan central */}
          <div>
            <div className="inline-flex items-center gap-2 bg-brand-orange/10 border border-brand-orange/30 rounded-full px-4 py-2 mb-6">
              <span className="w-2 h-2 rounded-full bg-brand-orange live-dot" />
              <span className="text-brand-orange text-sm font-medium">Direct maintenant</span>
            </div>
            <h1 className="text-5xl font-black font-display leading-tight mb-6">
              Le football<br />togolais<br />
              <span className="gradient-text">en streaming</span>
            </h1>
            <p className="text-brand-gray-text text-lg leading-relaxed max-w-md">
              Compétitions locales, matchs amateurs, directs et replays. 
              Suivez votre équipe où que vous soyez au Togo.
            </p>
          </div>

          {/* Stats */}
          <div className="flex gap-8">
            {[
              { label: 'Matchs par saison', value: '200+' },
              { label: 'Abonnés', value: '5 000+' },
              { label: 'Compétitions', value: '12' },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="text-2xl font-bold text-white">{stat.value}</div>
                <div className="text-sm text-brand-gray-text">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Panneau droit (formulaire) ── */}
      <div className="flex-1 flex flex-col justify-center items-center px-6 py-12 lg:px-12">
        {/* Logo mobile */}
        <div className="lg:hidden mb-8">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-3xl font-black font-display tracking-wider">
              BOX<span className="text-brand-orange">+</span>
            </span>
          </Link>
        </div>
        <div className="w-full max-w-md animate-slide-up">
          {children}
        </div>
      </div>
    </div>
  );
}
