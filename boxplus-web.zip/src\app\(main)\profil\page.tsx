'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import { useAuthStore } from '@/lib/auth.store';
import Link from 'next/link';
import { 
  User, Shield, CreditCard, Clock, Calendar, 
  CheckCircle, ArrowRight, LogOut, FileText 
} from 'lucide-react';
import { formatDate, formatPrice } from '@/lib/utils';

export default function ProfilPage() {
  const router = useRouter();
  const { user, isAuthenticated, logout } = useAuthStore();

  const [history, setHistory] = useState<{ subscriptions: any[]; payments: any[] }>({
    subscriptions: [],
    payments: [],
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }

    api.get('/payments/history')
      .then(res => setHistory(res.data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [isAuthenticated]);

  if (!isAuthenticated || !user) return null;

  const activeSub = history.subscriptions.find(
    s => s.status === 'active' && new Date(s.expires_at) > new Date()
  );

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      
      {/* Header profil */}
      <div className="bg-brand-black-2 border border-brand-gray rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="flex items-center gap-4 text-center sm:text-left">
          <div className="w-16 h-16 rounded-2xl bg-brand-orange/20 border border-brand-orange/40 text-brand-orange flex items-center justify-center font-black text-2xl font-display">
            {user.fullName?.[0] || 'U'}
          </div>
          <div>
            <h1 className="text-2xl font-black font-display text-white">{user.fullName}</h1>
            <p className="text-xs text-brand-gray-text mt-0.5">{user.email}</p>
          </div>
        </div>

        <button
          onClick={() => {
            logout();
            router.push('/');
          }}
          className="inline-flex items-center gap-2 text-xs text-red-400 hover:text-red-300 bg-red-500/10 border border-red-500/20 px-4 py-2 rounded-xl transition-colors"
        >
          <LogOut size={14} /> Déconnexion
        </button>
      </div>

      {/* État de l'abonnement en cours */}
      <div className="bg-brand-black-2 border border-brand-gray rounded-3xl p-6 sm:p-8 space-y-4">
        <h2 className="text-lg font-bold font-display flex items-center gap-2">
          <Shield className="text-brand-orange" size={20} />
          Abonnement & Droits d'Accès
        </h2>

        {activeSub ? (
          <div className="bg-brand-black-3 border border-emerald-500/30 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <h3 className="font-bold text-base text-white">{activeSub.plan_name}</h3>
              </div>
              <p className="text-xs text-brand-gray-text">
                Valide jusqu'au{' '}
                <strong className="text-white">
                  {formatDate(activeSub.expires_at, { day: 'numeric', month: 'long', year: 'numeric' })}
                </strong>
              </p>
            </div>

            <Link
              href="/"
              className="bg-brand-orange hover:bg-brand-orange-dark text-white font-bold text-xs px-5 py-2.5 rounded-xl transition-colors self-start sm:self-auto"
            >
              Regarder les matchs
            </Link>
          </div>
        ) : (
          <div className="bg-brand-black-3 border border-brand-gray rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h3 className="font-bold text-base text-white">Aucun abonnement actif</h3>
              <p className="text-xs text-brand-gray-text">
                Prenez un pass à partir de 500 FCFA pour débloquer les directs et replays.
              </p>
            </div>

            <Link
              href="/abonnement"
              className="bg-brand-orange hover:bg-brand-orange-dark text-white font-bold text-xs px-5 py-2.5 rounded-xl transition-colors self-start sm:self-auto"
            >
              Voir les offres
            </Link>
          </div>
        )}
      </div>

      {/* Historique des paiements & reçus */}
      <div className="bg-brand-black-2 border border-brand-gray rounded-3xl p-6 sm:p-8 space-y-4">
        <h2 className="text-lg font-bold font-display flex items-center gap-2">
          <CreditCard className="text-brand-orange" size={20} />
          Historique des Paiements Mobile Money
        </h2>

        {history.payments.length === 0 ? (
          <p className="text-xs text-brand-gray-text py-4">Aucune transaction enregistrée.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-brand-black-3 text-brand-gray-text uppercase border-b border-brand-gray">
                <tr>
                  <th className="py-3 px-4 font-bold">Formule</th>
                  <th className="py-3 px-4 font-bold">Montant</th>
                  <th className="py-3 px-3 text-center font-bold">Moyen</th>
                  <th className="py-3 px-3 text-center font-bold">Statut</th>
                  <th className="py-3 px-4 text-right font-bold">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-gray/40">
                {history.payments.map((p) => (
                  <tr key={p.id} className="hover:bg-brand-black-3/50 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-white">{p.plan_name}</td>
                    <td className="py-3.5 px-4 font-black font-display text-white">
                      {formatPrice(parseFloat(p.amount))}
                    </td>
                    <td className="py-3.5 px-3 text-center uppercase text-brand-gray-light font-semibold">
                      {p.payment_method || 'Mobile Money'}
                    </td>
                    <td className="py-3.5 px-3 text-center">
                      <span className={`px-2.5 py-0.5 rounded font-bold uppercase text-[10px] ${
                        p.status === 'approved'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-yellow-500/10 text-yellow-400'
                      }`}>
                        {p.status === 'approved' ? 'Payé' : p.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right text-brand-gray-text">
                      {formatDate(p.created_at, { day: 'numeric', month: 'short', year: 'numeric' })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
}
