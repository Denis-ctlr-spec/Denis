'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import Link from 'next/link';
import { Trophy, RefreshCw, Plus, Check } from 'lucide-react';
import { Button } from '@/components/ui/Button';

export default function AdminCompetitionsPage() {
  const [competitions, setCompetitions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');
  
  // Nouvelle compétition form
  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [country, setCountry] = useState('Togo');
  const [format, setFormat] = useState('league');

  const loadCompetitions = () => {
    setLoading(true);
    api.get('/admin/competitions')
      .then(res => setCompetitions(res.data.competitions || []))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadCompetitions();
  }, []);

  const handleRecalculate = async (compId: string) => {
    try {
      await api.post(`/admin/standings/${compId}/recalculate`);
      setMsg('Classement recalculé avec succès à partir des résultats des matchs !');
      setTimeout(() => setMsg(''), 4000);
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur recalcul classement');
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.post('/admin/competitions', {
        name,
        slug: slug.toLowerCase().replace(/\s+/g, '-'),
        country,
        format,
      });
      setName('');
      setSlug('');
      setMsg('Compétition créée !');
      loadCompetitions();
      setTimeout(() => setMsg(''), 3000);
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur création compétition');
    }
  };

  return (
    <div className="space-y-8 max-w-6xl">
      <div>
        <h1 className="text-3xl font-black font-display">Gestion des Compétitions</h1>
        <p className="text-brand-gray-text text-sm mt-1">
          Ligues, championnats locaux et déclenchement du recalcul des points.
        </p>
      </div>

      {msg && (
        <div className="bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 p-4 rounded-xl text-xs flex items-center gap-2">
          <Check size={16} /> {msg}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Liste des compétitions */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="font-bold text-sm uppercase text-brand-gray-text tracking-wider">
            Compétitions enregistrées
          </h3>

          <div className="space-y-3">
            {competitions.map((c) => (
              <div
                key={c.id}
                className="bg-brand-black-2 border border-brand-gray rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div>
                  <h4 className="font-bold text-base text-white">{c.name}</h4>
                  <p className="text-xs text-brand-gray-text mt-0.5">
                    {c.country} • Format : {c.format === 'league' ? 'Championnat (Points)' : 'Coupe'}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleRecalculate(c.id)}
                    className="bg-brand-black-3 hover:bg-brand-gray border border-brand-gray text-white text-xs font-bold px-3 py-2 rounded-xl flex items-center gap-1.5 transition-colors"
                  >
                    <RefreshCw size={12} /> Recalculer le classement
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Formulaire ajout rapide */}
        <div className="bg-brand-black-2 border border-brand-gray rounded-2xl p-6 space-y-4 h-fit">
          <h3 className="font-bold text-sm uppercase text-brand-gray-text tracking-wider">
            Ajouter une compétition
          </h3>

          <form onSubmit={handleCreate} className="space-y-3">
            <div>
              <label className="block text-xs text-brand-gray-text mb-1">Nom :</label>
              <input
                type="text"
                required
                placeholder="Ex: D1 Lonato"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setSlug(e.target.value.toLowerCase().replace(/\s+/g, '-'));
                }}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-brand-gray-text mb-1">Slug URL :</label>
              <input
                type="text"
                required
                placeholder="d1-lonato"
                value={slug}
                onChange={(e) => setSlug(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-brand-gray-text mb-1">Pays :</label>
              <input
                type="text"
                required
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <Button type="submit" fullWidth size="sm" className="mt-2">
              <Plus size={14} /> Enregistrer la compétition
            </Button>
          </form>
        </div>

      </div>
    </div>
  );
}
