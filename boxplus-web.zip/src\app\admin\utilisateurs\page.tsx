'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import { Users, Shield, CheckCircle, XCircle } from 'lucide-react';
import { formatDate } from '@/lib/utils';

export default function AdminUsersPage() {
  const [users, setUsers] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const loadUsers = (query = '') => {
    setLoading(true);
    api.get(`/admin/users?search=${encodeURIComponent(query)}&limit=50`)
      .then(res => {
        setUsers(res.data.users || []);
        setTotal(res.data.total || 0);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleRoleChange = async (userId: string, newRole: string) => {
    try {
      await api.patch(`/admin/users/${userId}/role`, { role: newRole });
      setUsers(users.map(u => u.id === userId ? { ...u, role: newRole } : u));
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur mise à jour rôle');
    }
  };

  const handleToggleActive = async (userId: string, currentStatus: boolean) => {
    try {
      await api.patch(`/admin/users/${userId}/active`, { isActive: !currentStatus });
      setUsers(users.map(u => u.id === userId ? { ...u, is_active: !currentStatus } : u));
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur statut compte');
    }
  };

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black font-display">Utilisateurs & Abonnés</h1>
          <p className="text-brand-gray-text text-sm mt-1">
            {total} spectateurs inscrits sur BOX+.
          </p>
        </div>

        <input
          type="search"
          placeholder="Rechercher par nom, email, tél..."
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            loadUsers(e.target.value);
          }}
          className="bg-brand-black-2 border border-brand-gray text-white text-xs rounded-xl px-4 py-2.5 w-72 focus:outline-none focus:border-brand-orange"
        />
      </div>

      <div className="bg-brand-black-2 border border-brand-gray rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-brand-black-3 text-brand-gray-text uppercase border-b border-brand-gray">
              <tr>
                <th className="py-3.5 px-4 font-bold">Utilisateur</th>
                <th className="py-3.5 px-4 font-bold">Contact</th>
                <th className="py-3.5 px-3 text-center font-bold">Abonnement Actuel</th>
                <th className="py-3.5 px-3 text-center font-bold">Rôle Système</th>
                <th className="py-3.5 px-3 text-center font-bold">Statut</th>
                <th className="py-3.5 px-4 text-right font-bold">Inscrit le</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-brand-gray/40">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-brand-black-3/50 transition-colors">
                  <td className="py-3.5 px-4">
                    <span className="font-bold text-white block text-sm">{u.full_name}</span>
                    <span className="text-brand-gray-text text-[11px]">{u.email}</span>
                  </td>

                  <td className="py-3.5 px-4 text-brand-gray-light">
                    {u.phone || 'Non renseigné'}
                  </td>

                  <td className="py-3.5 px-3 text-center">
                    {u.sub_status === 'active' ? (
                      <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2.5 py-1 rounded font-bold">
                        {u.sub_plan || 'Actif'}
                      </span>
                    ) : (
                      <span className="text-brand-gray-text">Aucun</span>
                    )}
                  </td>

                  <td className="py-3.5 px-3 text-center">
                    <select
                      value={u.role}
                      onChange={(e) => handleRoleChange(u.id, e.target.value)}
                      className="bg-brand-black-3 border border-brand-gray rounded px-2 py-1 text-white font-medium focus:outline-none"
                    >
                      <option value="spectator">Spectateur</option>
                      <option value="operator">Opérateur direct</option>
                      <option value="moderator">Modérateur</option>
                      <option value="admin">Administrateur</option>
                    </select>
                  </td>

                  <td className="py-3.5 px-3 text-center">
                    <button
                      onClick={() => handleToggleActive(u.id, u.is_active)}
                      className={`text-xs px-2.5 py-1 rounded font-bold ${
                        u.is_active
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-red-500/10 text-red-400 border border-red-500/30'
                      }`}
                    >
                      {u.is_active ? 'Actif' : 'Bloqué'}
                    </button>
                  </td>

                  <td className="py-3.5 px-4 text-right text-brand-gray-text">
                    {formatDate(u.created_at, { day: 'numeric', month: 'short', year: 'numeric' })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
