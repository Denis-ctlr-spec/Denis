'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import Link from 'next/link';
import { PlaySquare, Calendar, ChevronRight, Play } from 'lucide-react';
import { formatDate } from '@/lib/utils';
import { MatchCard } from '@/components/match/MatchCard';

export default function ReplaysPage() {
  const [replays, setReplays] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/matches/replays?limit=24')
      .then(res => setReplays(res.data.matches || []))
      .catch(() => setReplays([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Entête */}
      <div className="border-b border-brand-gray pb-6">
        <div className="flex items-center gap-2 text-brand-orange text-sm font-semibold mb-1">
          <PlaySquare size={18} />
          <span>VOD & Rediffusions</span>
        </div>
        <h1 className="text-3xl font-black font-display text-white">Replays & Résumés Complets</h1>
        <p className="text-brand-gray-text text-sm mt-1">
          Revivez tous les matchs du football amateur et local togolais à la demande.
        </p>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-brand-black-2 border border-brand-gray rounded-xl h-56 animate-pulse" />
          ))}
        </div>
      ) : replays.length === 0 ? (
        <div className="text-center py-20 bg-brand-black-2 border border-brand-gray rounded-2xl p-8">
          <PlaySquare className="w-16 h-16 text-brand-gray-text mx-auto mb-4 opacity-40" />
          <h3 className="text-xl font-bold">Aucun replay disponible pour l'instant</h3>
          <p className="text-brand-gray-text text-sm mt-1 max-w-md mx-auto">
            Les rediffusions et résumés apparaissent automatiquement une fois les diffusions en direct terminées.
          </p>
          <Link
            href="/matchs"
            className="inline-flex items-center gap-2 bg-brand-orange hover:bg-brand-orange-dark text-white font-bold text-sm px-5 py-2.5 rounded-xl mt-6 transition-colors"
          >
            Consulter les matchs en direct
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {replays.map((match) => (
            <div key={match.id} className="relative group">
              <MatchCard match={match} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
