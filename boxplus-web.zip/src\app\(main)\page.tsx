import { api } from '@/lib/api';
import Link from 'next/link';
import { MatchCard } from '@/components/match/MatchCard';
import { formatDate } from '@/lib/utils';
import { Calendar, Trophy, Play, ChevronRight } from 'lucide-react';

async function getData() {
  try {
    const [featured, upcoming, replays, competitions] = await Promise.all([
      api.get('/matches?status=live&limit=1').catch(() => ({ data: { matches: [] } })),
      api.get('/matches/upcoming?limit=6'),
      api.get('/matches/replays?limit=6'),
      api.get('/competitions'),
    ]);
    return {
      liveMatch: featured.data.matches?.[0] || null,
      upcoming: upcoming.data.matches || [],
      replays: replays.data.matches || [],
      competitions: competitions.data.competitions || [],
    };
  } catch {
    return { liveMatch: null, upcoming: [], replays: [], competitions: [] };
  }
}

export default async function HomePage() {
  const { liveMatch, upcoming, replays, competitions } = await getData();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-12">

      {/* ── Hero : Match en direct ── */}
      {liveMatch ? (
        <section>
          <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-red-950/40 to-brand-black-2 border border-red-800/30">
            <div className="absolute top-4 left-4 flex items-center gap-2 z-10">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 live-dot" />
              <span className="text-red-400 font-bold text-sm tracking-wider">EN DIRECT</span>
            </div>
            <div className="p-8 md:p-12">
              <p className="text-brand-gray-text text-sm mb-2">{liveMatch.competition.name}</p>
              <div className="flex items-center justify-center gap-8 my-8">
                <div className="text-center">
                  <p className="text-2xl md:text-4xl font-black">{liveMatch.homeTeam.name}</p>
                </div>
                <div className="text-center">
                  <div className="text-5xl md:text-7xl font-black font-display">
                    {liveMatch.score.home}
                    <span className="text-brand-gray mx-3">–</span>
                    {liveMatch.score.away}
                  </div>
                  {liveMatch.minute && (
                    <p className="text-red-400 font-bold mt-2">{liveMatch.minute}'</p>
                  )}
                </div>
                <div className="text-center">
                  <p className="text-2xl md:text-4xl font-black">{liveMatch.awayTeam.name}</p>
                </div>
              </div>
              <div className="text-center">
                <Link
                  href={`/matchs/${liveMatch.id}`}
                  className="inline-flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-8 rounded-xl text-lg transition-colors"
                >
                  <Play size={20} fill="currentColor" />
                  Regarder le match
                </Link>
              </div>
            </div>
          </div>
        </section>
      ) : (
        /* Hero statique si pas de live */
        <section className="relative rounded-2xl overflow-hidden bg-brand-black-2 border border-brand-gray py-16 text-center">
          <div className="absolute inset-0 opacity-5"
            style={{ backgroundImage: 'radial-gradient(circle at 50% 0%, #FF5A1F, transparent 70%)' }} />
          <h1 className="text-4xl md:text-6xl font-black font-display mb-4">
            Le football togolais<br />
            <span className="gradient-text">en streaming</span>
          </h1>
          <p className="text-brand-gray-text text-lg mb-8 max-w-lg mx-auto">
            Directs, replays, classements — suivez vos équipes favorites.
          </p>
          <Link href="/abonnement"
            className="inline-flex items-center gap-2 bg-brand-orange hover:bg-brand-orange-dark text-white font-bold py-4 px-8 rounded-xl text-lg transition-colors">
            Commencer maintenant →
          </Link>
        </section>
      )}

      {/* ── Prochains matchs ── */}
      {upcoming.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold font-display flex items-center gap-2">
              <Calendar className="text-brand-orange" size={22} />
              Prochains matchs
            </h2>
            <Link href="/matchs" className="text-sm text-brand-orange hover:underline flex items-center gap-1">
              Voir tout <ChevronRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {upcoming.map((m: any) => <MatchCard key={m.id} match={m} />)}
          </div>
        </section>
      )}

      {/* ── Compétitions ── */}
      {competitions.length > 0 && (
        <section>
          <h2 className="text-2xl font-bold font-display flex items-center gap-2 mb-6">
            <Trophy className="text-brand-orange" size={22} />
            Compétitions
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {competitions.slice(0, 8).map((c: any) => (
              <Link key={c.id} href={`/classements?comp=${c.id}`}
                className="bg-brand-black-2 border border-brand-gray rounded-xl p-4 text-center hover:border-brand-orange/50 transition-all group">
                {c.logo_url ? (
                  <img src={c.logo_url} alt={c.name} className="w-12 h-12 object-contain mx-auto mb-3" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-brand-gray mx-auto mb-3 flex items-center justify-center text-xl">
                    ⚽
                  </div>
                )}
                <p className="text-sm font-semibold group-hover:text-brand-orange transition-colors">{c.name}</p>
                <p className="text-xs text-brand-gray-text mt-1">{c.region || c.country}</p>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* ── Replays récents ── */}
      {replays.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold font-display flex items-center gap-2">
              <Play className="text-brand-orange" size={22} />
              Replays récents
            </h2>
            <Link href="/replays" className="text-sm text-brand-orange hover:underline flex items-center gap-1">
              Voir tout <ChevronRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {replays.map((m: any) => <MatchCard key={m.id} match={m} />)}
          </div>
        </section>
      )}

      {/* ── CTA Abonnement ── */}
      <section className="bg-gradient-to-r from-brand-orange/10 to-brand-orange/5 border border-brand-orange/20 rounded-2xl p-8 text-center">
        <h2 className="text-3xl font-black font-display mb-3">Accédez à tous les matchs</h2>
        <p className="text-brand-gray-text mb-6 max-w-md mx-auto">
          À partir de 500 FCFA le match ou 2 500 FCFA/mois. Paiement Mobile Money (T-Money, Flooz).
        </p>
        <Link href="/abonnement"
          className="inline-flex items-center gap-2 bg-brand-orange hover:bg-brand-orange-dark text-white font-bold py-3 px-8 rounded-xl transition-colors">
          Voir les offres
        </Link>
      </section>
    </div>
  );
}
