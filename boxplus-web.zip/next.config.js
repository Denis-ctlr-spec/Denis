/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    // Évite le blocage du build Vercel sur les vérifications de types strictes
    ignoreBuildErrors: true,
  },
  eslint: {
    // Évite le blocage du build Vercel sur les règles de linter
    ignoreDuringBuilds: true,
  },
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: '**.cloudflare.com' },
      { protocol: 'http', hostname: 'localhost' },
      { protocol: 'https', hostname: 'media.boxplus.tg' },
      { protocol: 'https', hostname: 'images.unsplash.com' },
    ],
  },
};

module.exports = nextConfig;
