import Link from 'next/link';
import { formatDate, formatTime } from '@/lib/utils';
import { cn } from '@/lib/utils';

interface Match {
  id: string;
  scheduledAt: string;
  status: string;
  score: { home: number; away: number };
  minute?: number;
  isFree: boolean;
  thumbnailUrl?: string;
  homeTeam: { name: string; shortName?: string; logo?: string };
  awayTeam: { name: string; shortName?: string; logo?: string };
  competition: { name: string; logo?: string };
}

interface MatchCardProps {
  match: Match;
  size?: 'sm' | 'md' | 'lg';
}

const STATUS_LABELS: Record<string, { label: string; class: string }> = {
  live:      { label: 'EN DIRECT', class: 'bg-red-600 text-white animate-pulse' },
  scheduled: { label: 'À VENIR',   class: 'bg-brand-black-3 text-brand-gray-text border border-brand-gray' },
  finished:  { label: 'TERMINÉ',   class: 'bg-brand-black-3 text-brand-gray-text' },
  cancelled: { label: 'ANNULÉ',    class: 'bg-red-900/50 text-red-400' },
  postponed: { label: 'REPORTÉ',   class: 'bg-yellow-900/50 text-yellow-400' },
};

export function MatchCard({ match, size = 'md' }: MatchCardProps) {
  const statusInfo = STATUS_LABELS[match.status] || STATUS_LABELS.scheduled;
  const isLive = match.status === 'live';
  const isFinished = match.status === 'finished';

  return (
    <Link href={`/matchs/${match.id}`}>
      <div className={cn(
        'bg-brand-black-2 border border-brand-gray rounded-xl overflow-hidden',
        'hover:border-brand-orange/50 hover:bg-brand-black-3 transition-all duration-200',
        'cursor-pointer group',
        size === 'lg' && 'shadow-lg',
      )}>
        {/* Compétition */}
        <div className="flex items-center justify-between px-4 py-2 border-b border-brand-gray/50">
          <span className="text-xs text-brand-gray-text font-medium">{match.competition.name}</span>
          <div className="flex items-center gap-2">
            {match.isFree && (
              <span className="text-xs bg-green-600/20 text-green-400 border border-green-600/30 px-1.5 py-0.5 rounded">
                Gratuit
              </span>
            )}
            <span className={cn('text-xs px-2 py-0.5 rounded font-bold tracking-wide', statusInfo.class)}>
              {isLive && match.minute ? `${match.minute}'` : statusInfo.label}
            </span>
          </div>
        </div>

        {/* Score / Équipes */}
        <div className="px-4 py-4">
          <div className="flex items-center justify-between gap-3">
            {/* Équipe domicile */}
            <div className="flex-1 flex flex-col items-center gap-2">
              {match.homeTeam.logo ? (
                <img src={match.homeTeam.logo} alt={match.homeTeam.name}
                  className="w-10 h-10 object-contain" />
              ) : (
                <div className="w-10 h-10 rounded-full bg-brand-gray flex items-center justify-center text-sm font-bold">
                  {match.homeTeam.shortName?.[0] || match.homeTeam.name[0]}
                </div>
              )}
              <span className="text-sm font-semibold text-center leading-tight">
                {match.homeTeam.shortName || match.homeTeam.name}
              </span>
            </div>

            {/* Score central */}
            <div className="flex flex-col items-center gap-1 min-w-[80px]">
              {isFinished || isLive ? (
                <div className="text-3xl font-black font-display tracking-widest">
                  {match.score.home}
                  <span className="text-brand-gray-text mx-1">–</span>
                  {match.score.away}
                </div>
              ) : (
                <div className="text-brand-gray-text font-medium">
                  {formatTime(match.scheduledAt)}
                </div>
              )}
              {isLive && (
                <div className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 live-dot" />
                  <span className="text-xs text-red-400 font-medium">LIVE</span>
                </div>
              )}
              {!isLive && !isFinished && (
                <span className="text-xs text-brand-gray-text">
                  {formatDate(match.scheduledAt, { weekday: 'short', month: 'short', day: 'numeric' })}
                </span>
              )}
            </div>

            {/* Équipe extérieure */}
            <div className="flex-1 flex flex-col items-center gap-2">
              {match.awayTeam.logo ? (
                <img src={match.awayTeam.logo} alt={match.awayTeam.name}
                  className="w-10 h-10 object-contain" />
              ) : (
                <div className="w-10 h-10 rounded-full bg-brand-gray flex items-center justify-center text-sm font-bold">
                  {match.awayTeam.shortName?.[0] || match.awayTeam.name[0]}
                </div>
              )}
              <span className="text-sm font-semibold text-center leading-tight">
                {match.awayTeam.shortName || match.awayTeam.name}
              </span>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className={cn(
          'px-4 py-2.5 text-center text-sm font-medium transition-colors',
          isLive
            ? 'bg-red-600/10 text-red-400 group-hover:bg-red-600/20'
            : isFinished
            ? 'bg-brand-orange/5 text-brand-orange group-hover:bg-brand-orange/10'
            : 'text-brand-gray-text group-hover:text-white',
        )}>
          {isLive ? '▶ Regarder en direct' : isFinished ? '▶ Voir le replay' : 'Voir les détails →'}
        </div>
      </div>
    </Link>
  );
}
