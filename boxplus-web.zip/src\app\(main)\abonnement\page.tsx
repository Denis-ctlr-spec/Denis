'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import { useAuthStore } from '@/lib/auth.store';
import { Check, ShieldCheck, Zap, Smartphone, ArrowRight } from 'lucide-react';
import { formatPrice } from '@/lib/utils';
import { MobileMoneyModal } from '@/components/payment/MobileMoneyModal';

export default function AbonnementPage() {
  const router = useRouter();
  const { user, isAuthenticated } = useAuthStore();
  
  const [plans, setPlans] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    api.get('/admin/plans')
      .then(res => setPlans(res.data.plans || []))
      .catch(() => setPlans([]))
      .finally(() => setLoading(false));
  }, []);

  const handleSelectPlan = (plan: any) => {
    if (!isAuthenticated) {
      router.push('/login?redirect=/abonnement');
      return;
    }
    setSelectedPlan(plan);
    setIsModalOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-12">
      {/* Hero Offres */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-2 bg-brand-orange/15 text-brand-orange px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
          <Zap size={14} />
          Accès Direct & Illimité
        </div>
        <h1 className="text-3xl md:text-5xl font-black font-display text-white">
          Vivez le football togolais sans interruption
        </h1>
        <p className="text-brand-gray-text text-sm md:text-base">
          Paiement rapide et sécurisé par <strong className="text-white">T-Money (Togocom)</strong> ou <strong className="text-white">Flooz (Moov Africa)</strong>. Activation immédiate.
        </p>
      </div>

      {/* Grille des Formules */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="bg-brand-black-2 border border-brand-gray rounded-3xl h-96 animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan) => {
            const isPopular = plan.slug === 'mensuel';
            const features = Array.isArray(plan.features) ? plan.features : JSON.parse(plan.features || '[]');

            return (
              <div
                key={plan.id}
                className={`bg-brand-black-2 rounded-3xl p-6 sm:p-8 flex flex-col justify-between relative transition-all duration-300 ${
                  isPopular
                    ? 'border-2 border-brand-orange shadow-2xl shadow-brand-orange/15 scale-100 md:scale-105'
                    : 'border border-brand-gray hover:border-brand-gray/80'
                }`}
              >
                {isPopular && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-brand-orange text-white text-[11px] font-black uppercase tracking-wider px-4 py-1 rounded-full shadow-lg">
                    Recommandé
                  </div>
                )}

                <div className="space-y-6">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-brand-orange">
                      Formule {plan.type}
                    </span>
                    <h3 className="text-2xl font-black font-display text-white mt-1">{plan.name}</h3>
                    <p className="text-xs text-brand-gray-text mt-1">{plan.description}</p>
                  </div>

                  {/* Prix */}
                  <div className="flex items-baseline gap-1 border-b border-brand-gray/60 pb-6">
                    <span className="text-4xl md:text-5xl font-black font-display text-white">
                      {formatPrice(parseFloat(plan.price))}
                    </span>
                    <span className="text-xs text-brand-gray-text font-bold">
                      /{plan.duration_days === 1 ? 'match' : plan.duration_days === 30 ? 'mois' : 'saison'}
                    </span>
                  </div>

                  {/* Caractéristiques */}
                  <ul className="space-y-3 text-xs text-gray-300">
                    {features.map((feat: string, index: number) => (
                      <li key={index} className="flex items-center gap-2.5">
                        <div className="w-4 h-4 rounded-full bg-brand-orange/20 text-brand-orange flex items-center justify-center shrink-0">
                          <Check size={10} strokeWidth={3} />
                        </div>
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  onClick={() => handleSelectPlan(plan)}
                  className={`w-full mt-8 py-3.5 px-4 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                    isPopular
                      ? 'bg-brand-orange hover:bg-brand-orange-dark text-white shadow-lg shadow-brand-orange/25'
                      : 'bg-brand-black-3 hover:bg-brand-gray border border-brand-gray text-white'
                  }`}
                >
                  <span>Souscrire avec Mobile Money</span>
                  <ArrowRight size={16} />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal de checkout */}
      {selectedPlan && (
        <MobileMoneyModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          plan={selectedPlan}
        />
      )}
    </div>
  );
}
