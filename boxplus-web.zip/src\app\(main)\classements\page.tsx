'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import Link from 'next/link';
import { Trophy, ChevronRight, Shield, Award } from 'lucide-react';

interface Standing {
  id: string;
  team_id: string;
  team_name: string;
  short_name?: string;
  logo_url?: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goals_for: number;
  goals_against: number;
  goal_difference: number;
  points: number;
}

interface Competition {
  id: string;
  name: string;
  slug: string;
  country: string;
  logo_url?: string;
}

export default function ClassementsPage() {
  const [competitions, setCompetitions] = useState<Competition[]>([]);
  const [selectedCompId, setSelectedCompId] = useState<string>('');
  const [standings, setStandings] = useState<Standing[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/competitions').then(res => {
      const comps = res.data.competitions || [];
      setCompetitions(comps);
      if (comps.length > 0) {
        setSelectedCompId(comps[0].id);
      }
    });
  }, []);

  useEffect(() => {
    if (!selectedCompId) return;
    setLoading(true);
    api.get(`/competitions/${selectedCompId}/standings`)
      .then(res => {
        setStandings(res.data.standings || []);
      })
      .finally(() => setLoading(false));
  }, [selectedCompId]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-brand-gray pb-6">
        <div>
          <div className="flex items-center gap-2 text-brand-orange text-sm font-semibold mb-1">
            <Trophy size={18} />
            <span>Statistiques & Compétitions</span>
          </div>
          <h1 className="text-3xl font-black font-display text-white">Classements Officiels</h1>
        </div>

        {/* Sélecteur de compétition */}
        <div className="flex items-center gap-3">
          <label className="text-sm text-brand-gray-text font-medium hidden sm:inline">Compétition :</label>
          <select
            value={selectedCompId}
            onChange={(e) => setSelectedCompId(e.target.value)}
            className="bg-brand-black-3 border border-brand-gray text-white text-sm rounded-xl px-4 py-2.5 focus:outline-none focus:border-brand-orange"
          >
            {competitions.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.country})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Tableau du classement */}
      <div className="bg-brand-black-2 border border-brand-gray rounded-2xl overflow-hidden shadow-xl">
        {loading ? (
          <div className="p-12 text-center text-brand-gray-text">
            <div className="w-8 h-8 border-2 border-brand-orange border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            Chargement des classements...
          </div>
        ) : standings.length === 0 ? (
          <div className="p-12 text-center text-brand-gray-text">
            <Shield className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-lg font-semibold">Aucun classement disponible pour cette compétition.</p>
            <p className="text-sm mt-1">Les matchs n'ont pas encore commencé ou les calculs sont en attente.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-brand-black-3 text-brand-gray-text text-xs uppercase tracking-wider border-b border-brand-gray">
                <tr>
                  <th className="py-4 px-4 text-center w-12 font-bold">#</th>
                  <th className="py-4 px-6 font-bold">Club</th>
                  <th className="py-4 px-3 text-center font-semibold">J</th>
                  <th className="py-4 px-3 text-center font-semibold text-emerald-400">G</th>
                  <th className="py-4 px-3 text-center font-semibold text-gray-400">N</th>
                  <th className="py-4 px-3 text-center font-semibold text-red-400">P</th>
                  <th className="py-4 px-3 text-center font-semibold">BP</th>
                  <th className="py-4 px-3 text-center font-semibold">BC</th>
                  <th className="py-4 px-3 text-center font-semibold">Diff</th>
                  <th className="py-4 px-6 text-center font-black text-white bg-brand-black-3/80">PTS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-gray/40">
                {standings.map((team, index) => {
                  const rank = index + 1;
                  const isLeader = rank === 1;
                  const isTopThree = rank <= 3;
                  const isRelegation = rank >= standings.length - 1 && standings.length > 5;

                  return (
                    <tr
                      key={team.id || team.team_id}
                      className="hover:bg-brand-black-3/60 transition-colors group"
                    >
                      <td className="py-4 px-4 text-center font-bold">
                        <span
                          className={`inline-flex items-center justify-center w-6 h-6 rounded-md text-xs font-black ${
                            isLeader
                              ? 'bg-brand-orange text-white'
                              : isTopThree
                              ? 'bg-brand-orange/20 text-brand-orange'
                              : isRelegation
                              ? 'bg-red-500/20 text-red-400'
                              : 'text-brand-gray-text'
                          }`}
                        >
                          {rank}
                        </span>
                      </td>

                      <td className="py-4 px-6">
                        <Link
                          href={`/equipes/${team.team_id}`}
                          className="flex items-center gap-3 font-semibold group-hover:text-brand-orange transition-colors"
                        >
                          {team.logo_url ? (
                            <img
                              src={team.logo_url}
                              alt={team.team_name}
                              className="w-7 h-7 object-contain"
                            />
                          ) : (
                            <div className="w-7 h-7 rounded-lg bg-brand-black-3 border border-brand-gray flex items-center justify-center text-xs font-bold text-brand-gray-light">
                              {team.short_name?.[0] || team.team_name[0]}
                            </div>
                          )}
                          <span>{team.team_name}</span>
                        </Link>
                      </td>

                      <td className="py-4 px-3 text-center text-brand-gray-light">{team.played}</td>
                      <td className="py-4 px-3 text-center text-emerald-400 font-medium">{team.won}</td>
                      <td className="py-4 px-3 text-center text-brand-gray-text">{team.drawn}</td>
                      <td className="py-4 px-3 text-center text-red-400">{team.lost}</td>
                      <td className="py-4 px-3 text-center text-brand-gray-light">{team.goals_for}</td>
                      <td className="py-4 px-3 text-center text-brand-gray-text">{team.goals_against}</td>
                      <td className="py-4 px-3 text-center font-bold">
                        <span
                          className={
                            team.goal_difference > 0
                              ? 'text-emerald-400'
                              : team.goal_difference < 0
                              ? 'text-red-400'
                              : 'text-brand-gray-text'
                          }
                        >
                          {team.goal_difference > 0 ? `+${team.goal_difference}` : team.goal_difference}
                        </span>
                      </td>

                      <td className="py-4 px-6 text-center font-black text-lg text-white bg-brand-black-3/40">
                        {team.points}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Légende */}
        <div className="p-4 bg-brand-black-3/50 border-t border-brand-gray/50 flex flex-wrap items-center gap-6 text-xs text-brand-gray-text">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded bg-brand-orange"></span>
            <span>Qualification Compétition Continentale (CAF)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded bg-brand-orange/20 border border-brand-orange/40"></span>
            <span>Podium national</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded bg-red-500/20 border border-red-500/40"></span>
            <span>Zone de relégation D2</span>
          </div>
        </div>
      </div>
    </div>
  );
}
