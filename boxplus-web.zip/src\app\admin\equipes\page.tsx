'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import { Shield, Plus, Check } from 'lucide-react';
import { Button } from '@/components/ui/Button';

export default function AdminTeamsPage() {
  const [teams, setTeams] = useState<any[]>([]);
  const [competitions, setCompetitions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  // Formulaire nouvelle équipe
  const [name, setName] = useState('');
  const [shortName, setShortName] = useState('');
  const [city, setCity] = useState('');
  const [stadium, setStadium] = useState('');
  const [competitionId, setCompetitionId] = useState('');

  const loadData = () => {
    setLoading(true);
    Promise.all([
      api.get('/teams'),
      api.get('/competitions'),
    ]).then(([tRes, cRes]) => {
      setTeams(tRes.data.teams || []);
      const comps = cRes.data.competitions || [];
      setCompetitions(comps);
      if (comps.length > 0 && !competitionId) {
        setCompetitionId(comps[0].id);
      }
    }).finally(() => setLoading(false));
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.post('/admin/teams', {
        name,
        shortName: shortName.toUpperCase(),
        city,
        stadium,
        competitionId,
      });
      setName('');
      setShortName('');
      setCity('');
      setStadium('');
      setMsg('Équipe créée avec succès !');
      loadData();
      setTimeout(() => setMsg(''), 3000);
    } catch (err: any) {
      alert(err.response?.data?.error || 'Erreur création équipe');
    }
  };

  return (
    <div className="space-y-8 max-w-6xl">
      <div>
        <h1 className="text-3xl font-black font-display">Clubs & Équipes</h1>
        <p className="text-brand-gray-text text-sm mt-1">
          Ajout des clubs régionaux, stades et liaisons aux championnats.
        </p>
      </div>

      {msg && (
        <div className="bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 p-4 rounded-xl text-xs flex items-center gap-2">
          <Check size={16} /> {msg}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Liste des équipes */}
        <div className="lg:col-span-2 space-y-3">
          <h3 className="font-bold text-sm uppercase text-brand-gray-text tracking-wider">
            Équipes enregistrées ({teams.length})
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {teams.map((t) => (
              <div
                key={t.id}
                className="bg-brand-black-2 border border-brand-gray rounded-xl p-4 flex items-center gap-3"
              >
                <div className="w-10 h-10 rounded-lg bg-brand-black-3 border border-brand-gray flex items-center justify-center font-bold text-brand-orange text-sm shrink-0">
                  {t.short_name?.[0] || t.name[0]}
                </div>
                <div className="min-w-0 flex-1">
                  <h4 className="font-bold text-sm truncate">{t.name}</h4>
                  <p className="text-xs text-brand-gray-text truncate">
                    {t.city || 'Togo'} • {t.comp_name || 'Sans ligue'}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Formulaire ajout rapide */}
        <div className="bg-brand-black-2 border border-brand-gray rounded-2xl p-6 space-y-4 h-fit">
          <h3 className="font-bold text-sm uppercase text-brand-gray-text tracking-wider">
            Nouveau club
          </h3>

          <form onSubmit={handleCreate} className="space-y-3">
            <div>
              <label className="block text-xs text-brand-gray-text mb-1">Nom complet :</label>
              <input
                type="text"
                required
                placeholder="Ex: ASKO de Kara"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-brand-gray-text mb-1">Sigle / Abréviation :</label>
              <input
                type="text"
                placeholder="ASKO"
                value={shortName}
                onChange={(e) => setShortName(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-brand-gray-text mb-1">Ville :</label>
              <input
                type="text"
                placeholder="Kara, Lomé..."
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-brand-gray-text mb-1">Stade :</label>
              <input
                type="text"
                placeholder="Stade Municipal..."
                value={stadium}
                onChange={(e) => setStadium(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-brand-gray-text mb-1">Compétition associée :</label>
              <select
                value={competitionId}
                onChange={(e) => setCompetitionId(e.target.value)}
                className="w-full bg-brand-black-3 border border-brand-gray rounded-xl px-3 py-2 text-xs text-white"
              >
                {competitions.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <Button type="submit" fullWidth size="sm" className="mt-2">
              <Plus size={14} /> Ajouter le club
            </Button>
          </form>
        </div>

      </div>
    </div>
  );
}
