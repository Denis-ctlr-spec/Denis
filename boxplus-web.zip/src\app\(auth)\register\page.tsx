'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Eye, EyeOff, Mail, Lock, User, Phone } from 'lucide-react';
import { authApi } from '@/lib/api';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';

const registerSchema = z.object({
  fullName: z.string().min(2, 'Minimum 2 caractères').max(100),
  email: z.string().email('Email invalide'),
  phone: z.string()
    .regex(/^\+?[0-9]{8,15}$/, 'Numéro invalide (ex: +22890123456)')
    .optional()
    .or(z.literal('')),
  password: z
    .string()
    .min(8, 'Minimum 8 caractères')
    .regex(/[A-Z]/, 'Au moins une majuscule')
    .regex(/[a-z]/, 'Au moins une minuscule')
    .regex(/[0-9]/, 'Au moins un chiffre'),
  confirmPassword: z.string(),
}).refine((d) => d.password === d.confirmPassword, {
  message: 'Les mots de passe ne correspondent pas',
  path: ['confirmPassword'],
});

type RegisterForm = z.infer<typeof registerSchema>;

export default function RegisterPage() {
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [serverError, setServerError] = useState('');
  const [success, setSuccess] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
  });

  const onSubmit = async (data: RegisterForm) => {
    setServerError('');
    setIsLoading(true);
    try {
      await authApi.register({
        email: data.email,
        phone: data.phone || undefined,
        password: data.password,
        fullName: data.fullName,
      });
      setSuccess(true);
    } catch (err: any) {
      setServerError(err.response?.data?.error || 'Une erreur est survenue.');
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="text-center animate-fade-in">
        <div className="w-16 h-16 bg-green-500/10 border border-green-500/30 rounded-full flex items-center justify-center mx-auto mb-6">
          <span className="text-3xl">✅</span>
        </div>
        <h2 className="text-2xl font-bold mb-3">Vérifiez vos emails !</h2>
        <p className="text-brand-gray-text mb-8 leading-relaxed">
          Un lien de confirmation a été envoyé à votre adresse email.<br />
          Cliquez sur le lien pour activer votre compte.
        </p>
        <Button variant="secondary" fullWidth onClick={() => router.push('/login')}>
          Retour à la connexion
        </Button>
      </div>
    );
  }

  return (
    <>
      <div className="mb-8">
        <h1 className="text-3xl font-bold font-display">Créer un compte</h1>
        <p className="text-brand-gray-text mt-2">
          Déjà inscrit ?{' '}
          <Link href="/login" className="text-brand-orange hover:text-brand-orange-light font-medium">
            Se connecter
          </Link>
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <Input
          label="Nom complet"
          placeholder="Kofi Mensah"
          icon={<User size={16} />}
          error={errors.fullName?.message}
          autoComplete="name"
          {...register('fullName')}
        />

        <Input
          label="Adresse email"
          type="email"
          placeholder="vous@exemple.com"
          icon={<Mail size={16} />}
          error={errors.email?.message}
          autoComplete="email"
          {...register('email')}
        />

        <Input
          label="Téléphone (optionnel)"
          type="tel"
          placeholder="+228 90 12 34 56"
          icon={<Phone size={16} />}
          error={errors.phone?.message}
          autoComplete="tel"
          {...register('phone')}
        />

        <Input
          label="Mot de passe"
          type={showPassword ? 'text' : 'password'}
          placeholder="Min. 8 caractères"
          icon={<Lock size={16} />}
          error={errors.password?.message}
          autoComplete="new-password"
          rightElement={
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="text-brand-gray-text hover:text-white transition-colors"
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          }
          {...register('password')}
        />

        <Input
          label="Confirmer le mot de passe"
          type={showPassword ? 'text' : 'password'}
          placeholder="••••••••"
          icon={<Lock size={16} />}
          error={errors.confirmPassword?.message}
          autoComplete="new-password"
          {...register('confirmPassword')}
        />

        {serverError && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-sm text-red-400">
            {serverError}
          </div>
        )}

        <Button type="submit" fullWidth size="lg" loading={isLoading} className="mt-2">
          {isLoading ? 'Création en cours...' : 'Créer mon compte'}
        </Button>
      </form>

      <p className="mt-6 text-center text-xs text-brand-gray-text leading-relaxed">
        En créant un compte, vous acceptez nos{' '}
        <Link href="/cgu" className="text-brand-orange hover:underline">CGU</Link>{' '}
        et notre{' '}
        <Link href="/confidentialite" className="text-brand-orange hover:underline">Politique de confidentialité</Link>.
      </p>
    </>
  );
}
