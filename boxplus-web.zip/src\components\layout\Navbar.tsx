'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuthStore } from '@/lib/auth.store';
import { cn } from '@/lib/utils';
import { Home, Calendar, Trophy, PlaySquare, User, LogOut, Settings } from 'lucide-react';
import { Button } from '@/components/ui/Button';

const navLinks = [
  { href: '/',           label: 'Accueil',      icon: Home },
  { href: '/matchs',     label: 'Matchs',        icon: Calendar },
  { href: '/classements',label: 'Classements',   icon: Trophy },
  { href: '/replays',    label: 'Replays',       icon: PlaySquare },
];

export function Navbar() {
  const pathname = usePathname();
  const { user, isAuthenticated, logout } = useAuthStore();

  return (
    <header className="sticky top-0 z-50 bg-brand-black/90 backdrop-blur-md border-b border-brand-gray">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-1 shrink-0">
          <span className="text-2xl font-black font-display tracking-wider">
            BOX<span className="text-brand-orange">+</span>
          </span>
        </Link>

        {/* Nav links — masqués sur mobile */}
        <nav className="hidden md:flex items-center gap-1">
          {navLinks.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className={cn(
                'flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
                pathname === href
                  ? 'bg-brand-orange/10 text-brand-orange'
                  : 'text-brand-gray-text hover:text-white hover:bg-brand-black-3'
              )}
            >
              <Icon size={15} />
              {label}
            </Link>
          ))}
        </nav>

        {/* Droite */}
        <div className="flex items-center gap-2">
          {isAuthenticated && user ? (
            <>
              {user.role === 'admin' && (
                <Link href="/admin">
                  <Button variant="secondary" size="sm">
                    <Settings size={14} />
                    Admin
                  </Button>
                </Link>
              )}
              <Link href="/profil">
                <Button variant="ghost" size="sm">
                  <User size={14} />
                  <span className="hidden sm:inline">{user.fullName?.split(' ')[0]}</span>
                </Button>
              </Link>
              <Button variant="ghost" size="sm" onClick={logout}>
                <LogOut size={14} />
              </Button>
            </>
          ) : (
            <>
              <Link href="/login">
                <Button variant="ghost" size="sm">Connexion</Button>
              </Link>
              <Link href="/register">
                <Button variant="primary" size="sm">S'inscrire</Button>
              </Link>
            </>
          )}
        </div>
      </div>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-brand-black-2 border-t border-brand-gray z-50">
        <div className="flex">
          {navLinks.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className={cn(
                'flex-1 flex flex-col items-center gap-1 py-3 text-xs transition-colors',
                pathname === href ? 'text-brand-orange' : 'text-brand-gray-text'
              )}
            >
              <Icon size={20} />
              {label}
            </Link>
          ))}
          {isAuthenticated ? (
            <Link href="/profil" className={cn(
              'flex-1 flex flex-col items-center gap-1 py-3 text-xs',
              pathname === '/profil' ? 'text-brand-orange' : 'text-brand-gray-text'
            )}>
              <User size={20} />
              Profil
            </Link>
          ) : (
            <Link href="/login" className="flex-1 flex flex-col items-center gap-1 py-3 text-xs text-brand-gray-text">
              <User size={20} />
              Connexion
            </Link>
          )}
        </div>
      </nav>
    </header>
  );
}
