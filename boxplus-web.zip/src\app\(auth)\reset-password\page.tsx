'use client';

import { useState, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Lock, Eye, EyeOff } from 'lucide-react';
import { authApi } from '@/lib/api';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';

const schema = z.object({
  password: z
    .string()
    .min(8, 'Minimum 8 caractères')
    .regex(/[A-Z]/, 'Au moins une majuscule')
    .regex(/[a-z]/, 'Au moins une minuscule')
    .regex(/[0-9]/, 'Au moins un chiffre'),
  confirmPassword: z.string(),
}).refine((d) => d.password === d.confirmPassword, {
  message: 'Les mots de passe ne correspondent pas',
  path: ['confirmPassword'],
});

function ResetForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token');

  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [serverError, setServerError] = useState('');
  const [success, setSuccess] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(schema),
  });

  if (!token) {
    return (
      <div className="text-center">
        <p className="text-red-400 mb-4">Lien invalide ou expiré.</p>
        <Link href="/forgot-password">
          <Button variant="secondary" fullWidth>Demander un nouveau lien</Button>
        </Link>
      </div>
    );
  }

  const onSubmit = async (data: any) => {
    setServerError('');
    setIsLoading(true);
    try {
      await authApi.resetPassword(token, data.password);
      setSuccess(true);
      setTimeout(() => router.push('/login'), 3000);
    } catch (err: any) {
      setServerError(err.response?.data?.error || 'Lien expiré ou invalide.');
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="text-center animate-fade-in">
        <div className="text-5xl mb-4">🎉</div>
        <h2 className="text-2xl font-bold mb-3">Mot de passe réinitialisé !</h2>
        <p className="text-brand-gray-text">Vous allez être redirigé vers la connexion...</p>
      </div>
    );
  }

  return (
    <>
      <div className="mb-8">
        <h1 className="text-3xl font-bold font-display">Nouveau mot de passe</h1>
        <p className="text-brand-gray-text mt-2">Choisissez un mot de passe sécurisé.</p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
        <Input
          label="Nouveau mot de passe"
          type={showPassword ? 'text' : 'password'}
          placeholder="Min. 8 caractères"
          icon={<Lock size={16} />}
          error={errors.password?.message}
          rightElement={
            <button type="button" onClick={() => setShowPassword(!showPassword)}
              className="text-brand-gray-text hover:text-white transition-colors">
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          }
          {...register('password')}
        />
        <Input
          label="Confirmer le mot de passe"
          type={showPassword ? 'text' : 'password'}
          placeholder="••••••••"
          icon={<Lock size={16} />}
          error={errors.confirmPassword?.message}
          {...register('confirmPassword')}
        />
        {serverError && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-sm text-red-400">
            {serverError}
          </div>
        )}
        <Button type="submit" fullWidth size="lg" loading={isLoading}>
          {isLoading ? 'Enregistrement...' : 'Enregistrer le mot de passe'}
        </Button>
      </form>
    </>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={<div className="text-center text-brand-gray-text">Chargement...</div>}>
      <ResetForm />
    </Suspense>
  );
}
