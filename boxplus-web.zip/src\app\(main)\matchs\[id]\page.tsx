'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import Link from 'next/link';
import { 
  Users, Clock, AlertCircle, ArrowLeft 
} from 'lucide-react';
import { formatDate, formatTime } from '@/lib/utils';
import { useAuthStore } from '@/lib/auth.store';
import { SecuredPlayer } from '@/components/player/SecuredPlayer';

interface MatchEvent {
  id: string;
  type: string;
  minute: number;
  player_name?: string;
  team_name?: string;
  description?: string;
}

export default function MatchDetailPage() {
  const params = useParams();
  const router = useRouter();
  const matchId = params.id as string;
  const { user, isAuthenticated } = useAuthStore();

  const [match, setMatch] = useState<any>(null);
  const [events, setEvents] = useState<MatchEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!matchId) return;

    const fetchMatch = () => {
      api.get(`/matches/${matchId}`)
        .then(res => {
          setMatch(res.data.match);
          setEvents(res.data.match.events || []);
        })
        .catch(err => {
          setError(err.response?.data?.error || 'Impossible de charger les données du match.');
        })
        .finally(() => setLoading(false));
    };

    fetchMatch();

    // WebSocket pour scores et événements en temps réel
    const wsUrl = (process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000')
      .replace(/^http/, 'ws') + '/ws';
    
    let ws: WebSocket;
    try {
      ws = new WebSocket(wsUrl);
      ws.onopen = () => {
        ws.send(JSON.stringify({ type: 'subscribe', matchId }));
      };
      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'match_update') {
            setMatch((prev: any) => ({
              ...prev,
              ...(msg.score && { score: msg.score }),
              ...(msg.minute !== undefined && { minute: msg.minute }),
              ...(msg.status && { status: msg.status })
            }));
          } else if (msg.type === 'match_event') {
            setEvents((prev) => [...prev, msg.event]);
          }
        } catch {}
      };
    } catch {}

    return () => {
      if (ws) ws.close();
    };
  }, [matchId]);

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-brand-orange border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (error || !match) {
    return (
      <div className="max-w-2xl mx-auto my-12 p-8 bg-brand-black-2 border border-red-900/50 rounded-2xl text-center space-y-4">
        <AlertCircle className="w-12 h-12 text-red-500 mx-auto" />
        <h2 className="text-xl font-bold">{error || 'Match introuvable'}</h2>
        <button
          onClick={() => router.push('/matchs')}
          className="inline-flex items-center gap-2 bg-brand-black-3 border border-brand-gray px-4 py-2 rounded-xl text-sm"
        >
          <ArrowLeft size={16} /> Retour aux matchs
        </button>
      </div>
    );
  }

  const isLive = match.status === 'live';
  const isFinished = match.status === 'finished';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* Retour navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => router.back()}
          className="inline-flex items-center gap-2 text-sm text-brand-gray-text hover:text-white transition-colors"
        >
          <ArrowLeft size={16} /> Retour au calendrier
        </button>
        <span className="text-xs bg-brand-black-3 border border-brand-gray px-3 py-1 rounded-full text-brand-gray-light">
          {match.competition?.name}
        </span>
      </div>

      {/* ZONE LECTEUR VIDEO HLS PROTÉGÉ */}
      <div className="bg-brand-black-2 border border-brand-gray rounded-2xl overflow-hidden shadow-2xl">
        {isLive || (isFinished && match.replayUrl) ? (
          <SecuredPlayer
            matchId={match.id}
            isFree={match.isFree}
            onUnauthorized={() => router.push('/abonnement')}
          />
        ) : (
          <div className="aspect-video bg-black flex flex-col items-center justify-center p-8 text-center space-y-4">
            <Clock className="w-16 h-16 text-brand-orange mx-auto opacity-70 animate-pulse" />
            <h3 className="text-2xl font-bold font-display">Le direct n'a pas encore commencé</h3>
            <p className="text-sm text-brand-gray-text max-w-md mx-auto">
              Coup d'envoi prévu le {formatDate(match.scheduledAt)} à {formatTime(match.scheduledAt)}.
            </p>
            <div className="pt-2">
              <Link
                href="/abonnement"
                className="inline-flex items-center gap-2 bg-brand-orange text-white text-sm font-bold px-6 py-3 rounded-xl shadow-lg shadow-brand-orange/20"
              >
                Vérifier ou souscrire un abonnement
              </Link>
            </div>
          </div>
        )}

        {/* Pupitre de score sous la vidéo */}
        <div className="p-6 bg-brand-black-3 border-t border-brand-gray flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-6 w-full md:w-auto justify-around md:justify-start">
            {/* Équipe Domicile */}
            <div className="text-center md:text-left flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-brand-black-2 border border-brand-gray flex items-center justify-center font-bold text-lg text-brand-orange">
                {match.homeTeam?.shortName || match.homeTeam?.name?.[0]}
              </div>
              <div>
                <h4 className="font-bold text-base md:text-lg">{match.homeTeam?.name}</h4>
                <span className="text-xs text-brand-gray-text">Domicile</span>
              </div>
            </div>

            {/* Score */}
            <div className="text-center px-4">
              <div className="text-3xl md:text-4xl font-black font-display tracking-widest text-white">
                {match.score?.home ?? 0} : {match.score?.away ?? 0}
              </div>
              {isLive ? (
                <div className="inline-flex items-center gap-1.5 text-red-500 font-bold text-xs uppercase tracking-wider mt-1">
                  <span className="w-2 h-2 rounded-full bg-red-600 live-dot"></span>
                  {match.minute ? `${match.minute}'` : 'En Direct'}
                </div>
              ) : (
                <span className="text-xs text-brand-gray-text uppercase font-semibold">
                  {match.status}
                </span>
              )}
            </div>

            {/* Équipe Extérieure */}
            <div className="text-center md:text-right flex items-center gap-3">
              <div className="order-2 md:order-1">
                <h4 className="font-bold text-base md:text-lg">{match.awayTeam?.name}</h4>
                <span className="text-xs text-brand-gray-text">Extérieur</span>
              </div>
              <div className="order-1 md:order-2 w-12 h-12 rounded-xl bg-brand-black-2 border border-brand-gray flex items-center justify-center font-bold text-lg text-emerald-400">
                {match.awayTeam?.shortName || match.awayTeam?.name?.[0]}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs text-brand-gray-text">
            <span className="bg-brand-black-2 border border-brand-gray px-3 py-1.5 rounded-lg flex items-center gap-1.5">
              <Users size={14} className="text-brand-orange" />
              {match.viewerCount || 0} spectateurs en direct
            </span>
          </div>
        </div>
      </div>

      {/* CHRONOLOGIE DES ÉVÉNEMENTS DU MATCH */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-brand-black-2 border border-brand-gray rounded-2xl p-6 space-y-6">
          <h3 className="text-xl font-bold font-display flex items-center gap-2">
            <span>Moments forts & Événements</span>
          </h3>

          {events.length === 0 ? (
            <div className="text-center py-10 text-brand-gray-text text-sm">
              Aucun événement signalé pour l'instant (buts, cartons, changements).
            </div>
          ) : (
            <div className="space-y-3">
              {events.map((ev) => (
                <div
                  key={ev.id}
                  className="flex items-center gap-4 p-3 bg-brand-black-3 rounded-xl border border-brand-gray/50"
                >
                  <span className="font-black font-display text-brand-orange w-10 text-center">
                    {ev.minute}'
                  </span>
                  <div className="flex-1">
                    <p className="font-semibold text-sm text-white">
                      {ev.type === 'goal' && '⚽ BUT !'}
                      {ev.type === 'yellow_card' && '🟨 Carton Jaune'}
                      {ev.type === 'red_card' && '🟥 Carton Rouge'}
                      {ev.type === 'substitution' && '🔄 Remplacement'}
                      {' '}{ev.player_name || ''}
                    </p>
                    {ev.description && (
                      <p className="text-xs text-brand-gray-text mt-0.5">{ev.description}</p>
                    )}
                  </div>
                  {ev.team_name && (
                    <span className="text-xs font-semibold text-brand-gray-light bg-brand-black-2 px-2 py-1 rounded">
                      {ev.team_name}
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Fiche info du match */}
        <div className="bg-brand-black-2 border border-brand-gray rounded-2xl p-6 space-y-4 h-fit">
          <h3 className="font-bold text-base border-b border-brand-gray pb-3">Informations</h3>
          
          <div className="space-y-3 text-sm">
            <div>
              <span className="block text-xs text-brand-gray-text">Compétition</span>
              <span className="font-medium">{match.competition?.name}</span>
            </div>
            <div>
              <span className="block text-xs text-brand-gray-text">Date & Heure</span>
              <span className="font-medium">
                {formatDate(match.scheduledAt)} à {formatTime(match.scheduledAt)}
              </span>
            </div>
            <div>
              <span className="block text-xs text-brand-gray-text">Stade</span>
              <span className="font-medium">
                {match.homeTeam?.stadium || 'Stade Municipal de Lomé'}
              </span>
            </div>
            <div>
              <span className="block text-xs text-brand-gray-text">Type d'accès</span>
              <span className={`inline-block px-2 py-0.5 rounded text-xs font-bold mt-1 ${
                match.isFree ? 'bg-green-500/20 text-green-400' : 'bg-brand-orange/20 text-brand-orange'
              }`}>
                {match.isFree ? 'Diffusion Gratuite' : 'Abonnement / Pass Match Requis'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
