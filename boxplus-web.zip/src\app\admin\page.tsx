'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import Link from 'next/link';
import { 
  DollarSign, Users, Eye, TrendingUp, Play, 
  Calendar, CheckCircle2, Clock, AlertTriangle 
} from 'lucide-react';
import { formatPrice } from '@/lib/utils';

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/admin/dashboard')
      .then(res => setStats(res.data.stats))
      .catch(() => setStats(null))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-8 max-w-7xl">
      {/* Title */}
      <div>
        <h1 className="text-3xl font-black font-display">Tableau de bord BOX+</h1>
        <p className="text-brand-gray-text text-sm mt-1">
          Performances de diffusion, abonnements Mobile Money et affluence en temps réel.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Recettes Mensuelles */}
        <div className="bg-brand-black-2 border border-brand-gray rounded-2xl p-5 space-y-2">
          <div className="flex items-center justify-between text-brand-gray-text">
            <span className="text-xs font-semibold">Revenus du mois</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <DollarSign size={16} />
            </div>
          </div>
          <div className="text-2xl font-black font-display text-white">
            {formatPrice(stats?.revenue?.thisMonth || 0)}
          </div>
          <div className="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
            <TrendingUp size={12} />
            <span>+18.4% par rapport au mois dernier</span>
          </div>
        </div>

        {/* Abonnés Actifs */}
        <div className="bg-brand-black-2 border border-brand-gray rounded-2xl p-5 space-y-2">
          <div className="flex items-center justify-between text-brand-gray-text">
            <span className="text-xs font-semibold">Abonnés actifs</span>
            <div className="w-8 h-8 rounded-lg bg-brand-orange/10 text-brand-orange flex items-center justify-center">
              <Users size={16} />
            </div>
          </div>
          <div className="text-2xl font-black font-display text-white">
            {stats?.users?.activeSubscribers ?? 0}
          </div>
          <div className="text-[11px] text-brand-gray-text">
            Sur {stats?.users?.total ?? 0} spectateurs enregistrés
          </div>
        </div>

        {/* Spectateurs Directs */}
        <div className="bg-brand-black-2 border border-brand-gray rounded-2xl p-5 space-y-2">
          <div className="flex items-center justify-between text-brand-gray-text">
            <span className="text-xs font-semibold">Audience Live</span>
            <div className="w-8 h-8 rounded-lg bg-red-600/10 text-red-500 flex items-center justify-center">
              <Eye size={16} />
            </div>
          </div>
          <div className="text-2xl font-black font-display text-white flex items-center gap-2">
            <span>{stats?.liveViewers ?? 0}</span>
            <span className="w-2 h-2 rounded-full bg-red-600 live-dot"></span>
          </div>
          <div className="text-[11px] text-red-400 font-medium">
            Flux vidéo actif
          </div>
        </div>

        {/* Total des Revenus */}
        <div className="bg-brand-black-2 border border-brand-gray rounded-2xl p-5 space-y-2">
          <div className="flex items-center justify-between text-brand-gray-text">
            <span className="text-xs font-semibold">Total Encaissé</span>
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
              <CheckCircle2 size={16} />
            </div>
          </div>
          <div className="text-2xl font-black font-display text-white">
            {formatPrice(stats?.revenue?.total || 0)}
          </div>
          <div className="text-[11px] text-brand-gray-text">
            T-Money, Flooz & Cartes
          </div>
        </div>

      </div>

      {/* Raccourcis Actions Rapides */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Link
          href="/admin/direct"
          className="bg-brand-orange/10 hover:bg-brand-orange/15 border border-brand-orange/30 p-5 rounded-2xl flex items-center justify-between group transition-all"
        >
          <div className="space-y-1">
            <span className="text-xs font-bold text-brand-orange uppercase tracking-wider">Régie en direct</span>
            <h4 className="font-bold text-base text-white group-hover:text-brand-orange transition-colors">
              Gérer le score & les événements →
            </h4>
            <p className="text-xs text-brand-gray-text">Contrôlez le match actuellement diffusé</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-brand-orange text-white flex items-center justify-center shrink-0">
            <Play size={20} fill="currentColor" />
          </div>
        </Link>

        <Link
          href="/admin/matchs/nouveau"
          className="bg-brand-black-2 hover:bg-brand-black-3 border border-brand-gray p-5 rounded-2xl flex items-center justify-between group transition-all"
        >
          <div className="space-y-1">
            <span className="text-xs font-bold text-brand-gray-text uppercase tracking-wider">Programmation</span>
            <h4 className="font-bold text-base text-white group-hover:text-brand-orange transition-colors">
              Créer un nouveau match →
            </h4>
            <p className="text-xs text-brand-gray-text">Configurez la clé de stream et la date</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-brand-black-3 border border-brand-gray text-white flex items-center justify-center shrink-0">
            <Calendar size={20} />
          </div>
        </Link>

        <Link
          href="/admin/competitions"
          className="bg-brand-black-2 hover:bg-brand-black-3 border border-brand-gray p-5 rounded-2xl flex items-center justify-between group transition-all"
        >
          <div className="space-y-1">
            <span className="text-xs font-bold text-brand-gray-text uppercase tracking-wider">Recalcul</span>
            <h4 className="font-bold text-base text-white group-hover:text-brand-orange transition-colors">
              Mettre à jour les classements →
            </h4>
            <p className="text-xs text-brand-gray-text">Recalculez automatiquement les points</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-brand-black-3 border border-brand-gray text-white flex items-center justify-center shrink-0">
            <CheckCircle2 size={20} />
          </div>
        </Link>
      </div>
    </div>
  );
}
