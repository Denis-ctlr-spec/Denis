'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import { MatchCard } from '@/components/match/MatchCard';
import { Button } from '@/components/ui/Button';
import { formatDate } from '@/lib/utils';
import { Calendar, Filter } from 'lucide-react';

const STATUS_FILTERS = [
  { value: '', label: 'Tous' },
  { value: 'live', label: '🔴 En direct' },
  { value: 'scheduled', label: '📅 À venir' },
  { value: 'finished', label: '✅ Terminés' },
];

export default function MatchsPage() {
  const [matches, setMatches] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [competitions, setCompetitions] = useState<any[]>([]);
  const [competitionId, setCompetitionId] = useState('');
  const LIMIT = 12;

  useEffect(() => {
    api.get('/competitions').then(r => setCompetitions(r.data.competitions || []));
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (status) params.set('status', status);
    if (competitionId) params.set('competitionId', competitionId);
    params.set('limit', String(LIMIT));
    params.set('offset', String(page * LIMIT));

    api.get(`/matches?${params}`)
      .then(r => {
        setMatches(r.data.matches || []);
        setTotal(r.data.total || 0);
      })
      .finally(() => setLoading(false));
  }, [status, competitionId, page]);

  // Grouper par date
  const grouped = matches.reduce((acc: Record<string, any[]>, m) => {
    const day = new Date(m.scheduledAt).toDateString();
    if (!acc[day]) acc[day] = [];
    acc[day].push(m);
    return acc;
  }, {});

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center gap-3 mb-8">
        <Calendar className="text-brand-orange" size={28} />
        <h1 className="text-3xl font-bold font-display">Calendrier des matchs</h1>
      </div>

      {/* Filtres */}
      <div className="flex flex-wrap gap-3 mb-8">
        {/* Filtre statut */}
        <div className="flex gap-2 flex-wrap">
          {STATUS_FILTERS.map(f => (
            <button
              key={f.value}
              onClick={() => { setStatus(f.value); setPage(0); }}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                status === f.value
                  ? 'bg-brand-orange text-white'
                  : 'bg-brand-black-3 border border-brand-gray text-brand-gray-text hover:text-white'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Filtre compétition */}
        {competitions.length > 0 && (
          <select
            value={competitionId}
            onChange={e => { setCompetitionId(e.target.value); setPage(0); }}
            className="bg-brand-black-3 border border-brand-gray text-sm rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-brand-orange"
          >
            <option value="">Toutes les compétitions</option>
            {competitions.map((c: any) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        )}
      </div>

      {/* Liste des matchs groupés par date */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-brand-black-2 border border-brand-gray rounded-xl h-44 animate-pulse" />
          ))}
        </div>
      ) : matches.length === 0 ? (
        <div className="text-center py-20 text-brand-gray-text">
          <p className="text-6xl mb-4">⚽</p>
          <p className="text-lg">Aucun match trouvé.</p>
        </div>
      ) : (
        <div className="space-y-8">
          {Object.entries(grouped).map(([day, dayMatches]) => (
            <div key={day}>
              <h3 className="text-sm font-semibold text-brand-gray-text uppercase tracking-wider mb-3 flex items-center gap-2">
                <span className="w-4 h-px bg-brand-gray-text" />
                {formatDate(dayMatches[0].scheduledAt, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                <span className="w-4 h-px bg-brand-gray-text" />
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {dayMatches.map((m: any) => <MatchCard key={m.id} match={m} />)}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {total > LIMIT && (
        <div className="flex justify-center gap-4 mt-8">
          <Button variant="secondary" disabled={page === 0} onClick={() => setPage(p => p - 1)}>
            ← Précédent
          </Button>
          <span className="text-brand-gray-text flex items-center text-sm">
            Page {page + 1} / {Math.ceil(total / LIMIT)}
          </span>
          <Button variant="secondary" disabled={(page + 1) * LIMIT >= total} onClick={() => setPage(p => p + 1)}>
            Suivant →
          </Button>
        </div>
      )}
    </div>
  );
}
