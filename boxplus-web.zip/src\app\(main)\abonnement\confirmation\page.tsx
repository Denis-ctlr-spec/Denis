'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import { useAuthStore } from '@/lib/auth.store';
import Link from 'next/link';
import { CheckCircle2, Clock, AlertTriangle, ArrowRight, Play, RefreshCw } from 'lucide-react';
import { formatPrice } from '@/lib/utils';

function ConfirmationContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { fetchMe } = useAuthStore();

  const paymentId = searchParams.get('payment_id');
  const isDemo = searchParams.get('demo') === 'true';

  const [payment, setPayment] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [simulating, setSimulating] = useState(false);

  const checkStatus = () => {
    if (!paymentId) return;
    api.get(`/payments/${paymentId}/status`)
      .then(res => {
        setPayment(res.data.payment);
        if (res.data.payment?.status === 'approved') {
          fetchMe(); // Met à jour le store utilisateur local avec les nouveaux droits
        }
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    checkStatus();
    // Polling toutes les 4 secondes tant que le statut est 'pending'
    const timer = setInterval(() => {
      if (payment?.status === 'pending') {
        checkStatus();
      }
    }, 4000);

    return () => clearInterval(timer);
  }, [paymentId, payment?.status]);

  // Fonction de test / simulation Sandbox FedaPay
  const handleSimulateSandbox = async () => {
    if (!paymentId) return;
    setSimulating(true);
    try {
      await api.post(`/payments/${paymentId}/simulate-sandbox`);
      checkStatus();
    } catch {
      alert('Erreur lors de la simulation sandbox');
    } finally {
      setSimulating(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center gap-3">
        <div className="w-10 h-10 border-4 border-brand-orange border-t-transparent rounded-full animate-spin"></div>
        <p className="text-xs text-brand-gray-text">Vérification de la transaction Mobile Money...</p>
      </div>
    );
  }

  const isApproved = payment?.status === 'approved';

  return (
    <div className="max-w-md mx-auto my-12 bg-brand-black-2 border border-brand-gray rounded-3xl p-6 sm:p-8 text-center space-y-6 shadow-2xl">
      
      {isApproved ? (
        <>
          <div className="w-16 h-16 rounded-full bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400">
            <CheckCircle2 size={36} />
          </div>

          <div className="space-y-2">
            <h1 className="text-2xl font-black font-display text-white">Abonnement Activé ! 🎉</h1>
            <p className="text-xs text-brand-gray-text">
              Votre paiement a été validé avec succès. Votre accès à la formule <strong className="text-white">{payment.plan_name}</strong> est maintenant opérationnel.
            </p>
          </div>

          <div className="bg-brand-black-3 border border-brand-gray rounded-2xl p-4 text-xs space-y-2 text-left">
            <div className="flex justify-between">
              <span className="text-brand-gray-text">Montant réglé :</span>
              <span className="font-bold text-white">{formatPrice(parseFloat(payment.amount))}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-brand-gray-text">Mode de règlement :</span>
              <span className="font-bold text-white uppercase">{payment.payment_method}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-brand-gray-text">Statut :</span>
              <span className="font-bold text-emerald-400 uppercase">Validé</span>
            </div>
          </div>

          <Link
            href="/"
            className="w-full bg-brand-orange hover:bg-brand-orange-dark text-white font-bold text-sm py-3.5 rounded-xl shadow-lg shadow-brand-orange/20 flex items-center justify-center gap-2 transition-all"
          >
            <Play size={16} fill="currentColor" />
            <span>Accéder aux matchs en direct</span>
          </Link>
        </>
      ) : (
        <>
          <div className="w-16 h-16 rounded-full bg-yellow-500/15 border border-yellow-500/30 flex items-center justify-center mx-auto text-yellow-400 animate-pulse">
            <Clock size={36} />
          </div>

          <div className="space-y-2">
            <h1 className="text-2xl font-black font-display text-white">En attente de validation USSD</h1>
            <p className="text-xs text-brand-gray-text">
              Veuillez confirmer l'invite push apparue sur votre téléphone en saisissant votre code PIN secret <strong className="text-white">(T-Money ou Flooz)</strong>.
            </p>
          </div>

          {/* Bouton de test Simulation Sandbox si mode démo */}
          {isDemo && (
            <div className="bg-brand-orange/10 border border-brand-orange/30 p-4 rounded-2xl text-left space-y-3">
              <div className="flex items-center gap-2 text-brand-orange font-bold text-xs uppercase tracking-wider">
                <AlertTriangle size={14} /> Mode Sandbox / Démonstration
              </div>
              <p className="text-[11px] text-brand-gray-text">
                En environnement de test, vous pouvez forcer la validation automatique sans code USSD :
              </p>
              <button
                onClick={handleSimulateSandbox}
                disabled={simulating}
                className="w-full bg-brand-orange hover:bg-brand-orange-dark text-white font-bold text-xs py-2.5 rounded-xl transition-all"
              >
                {simulating ? 'Validation en cours...' : 'Simuler la confirmation opérateur'}
              </button>
            </div>
          )}

          <div className="pt-2">
            <button
              onClick={checkStatus}
              className="text-xs text-brand-gray-text hover:text-white flex items-center justify-center gap-1 mx-auto"
            >
              <RefreshCw size={12} /> Actualiser le statut
            </button>
          </div>
        </>
      )}

    </div>
  );
}

export default function ConfirmationPage() {
  return (
    <Suspense fallback={<div className="p-12 text-center text-xs text-brand-gray-text">Chargement...</div>}>
      <ConfirmationContent />
    </Suspense>
  );
}
