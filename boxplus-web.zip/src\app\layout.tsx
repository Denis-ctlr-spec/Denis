import type { Metadata } from 'next';
import { Inter, Space_Grotesk } from 'next/font/google';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-space-grotesk',
  display: 'swap',
});

export const metadata: Metadata = {
  title: { default: 'BOX+ | Football en streaming', template: '%s | BOX+' },
  description: 'Regardez le football amateur et local du Togo en direct et en replay. Abonnez-vous à BOX+.',
  keywords: ['football', 'streaming', 'Togo', 'Afrique', 'direct', 'replay', 'BOX+'],
  authors: [{ name: 'BOX+' }],
  openGraph: {
    type: 'website',
    locale: 'fr_TG',
    siteName: 'BOX+',
    title: 'BOX+ | Football en streaming',
    description: 'Regardez le football du Togo en direct et en replay.',
  },
  themeColor: '#FF5A1F',
  manifest: '/manifest.json',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className="dark">
      <body className={`${inter.variable} ${spaceGrotesk.variable} font-sans bg-brand-black text-white antialiased`}>
        {children}
      </body>
    </html>
  );
}
